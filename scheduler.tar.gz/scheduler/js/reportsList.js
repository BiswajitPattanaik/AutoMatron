/*
  File : reportList.js
  Purpose : Methods to show, view and mail reports.
  Author : Tuhin Das
*/


function init()
{
  if(successMsg != "")
  { 
    document.getElementById('scsMsg').innerHTML = successMsg;
    successMsg = "";
    $('#scsMsg').fadeIn();
    $('#scsMsg').fadeOut(5000);
  }
  if(errorMsg != "")
  {
    document.getElementById('errMsg').innerHTML = errorMsg;
    errMsg = "";
    $('#errMsg').fadeIn();
    $('#errMsg').fadeOut(5000);
  }
  loadReportsTable(); 

}


//populates tasks info in task table.
function loadReportsTable()
{

  var ih = "<div style='width:90%;height:90%;margin-left:5%;margin-top:2%;' class='panel panel-default'><div class='panel-heading'><h4><a class='btn btn-warning'  href='taskList.jsp?product="+productType+"' title='Back to Tasks'  ><span class='glyphicon glyphicon-menu-left'></span></a>&nbsp; &nbsp; <font style='margin-top:5px;'>Reports</font></h4></div><div class='panel-body' style='max-height: 90%;overflow: auto;'>";
  ih += "<table class='table table-striped table-bordered table-condensed' >";
  // adding headers
  ih += "<thead><tr><th>Report</th><th>Report Time</th><th>File Name</th><th>Format</th><th>Actions</th></tr></thead><tbody>";
  // adding reports
  if(files.length == 0)
  {
     ih += "<tr><td colspan='100%'>No tasks to display.</td></tr>";
  }
  else
  {
   for(var a = 0; a < files.length && a < 200; a++)
   {
     // file name format : Dotcom_Percentile_Daily_Report_12-25-17_02:05:48.xls 

     var filenameTokens = files[a][0].split(".")[0].split("_");
     var date = filenameTokens[filenameTokens.length - 2];
     var time = filenameTokens[filenameTokens.length - 1];
     filenameTokens.pop();
     filenameTokens.pop();
     var report = filenameTokens.join(" ");
     //var reportInfo = JSON.parse(files[a][5]); 
     ih +=  "<tr><td>"+report+"</td><td>"+date+" "+time+"</td><td><a href='../../reports/genreports/"+files[a][0]+"'>"+files[a][0]+"</a></td><td>";
     //if(files[a][3].indexOf('xls') > -1)
        ih += "<img src='../images/xls.png' width = '20px' height = '25px' title='.XLSX' >";
     ih += "</td>";
     //ih += "<td>"+files[a][1]+"</td><td>"+files[a][2]+"</td>";
     
     ih += "<td><a title='View Report'  href='../../reports/genreports/"+files[a][0]+"'  class='btn btn-warning' style='padding : 4px 4px' ><span class='glyphicon glyphicon-open'></span></a>&nbsp; &nbsp;<a title='Mail Report'  onclick=mailFile('"+files[a][0]+"') class='btn btn-info' style='padding : 4px 4px' ><span class='glyphicon glyphicon-envelope'></span></a>&nbsp; &nbsp;<a title='Delete Report'  onclick=deleteFile('"+files[a][0]+"') class='btn btn-danger' style='padding : 4px 4px' ><span class='glyphicon glyphicon-trash'></span></a></td>";

     //ih += "<td><a title='Delete Report'  onclick=deleteFile('"+files[a][6]+"') class='btn btn-danger' style='padding : 4px 4px' ><span class='glyphicon glyphicon-trash'></span></a>&nbsp; &nbsp;<a title='View Report'  href='../customreports/"+files[a][6]+"'  class='btn btn-warning' style='padding : 4px 4px' ><span class='glyphicon glyphicon-open'></span></a>&nbsp; &nbsp;<a title='Mail Report'  onclick=mailFile("+a+") class='btn btn-info' style='padding : 4px 4px' ><span class='glyphicon glyphicon-envelope'></span></a>&nbsp; &nbsp;<a title='File Information'  onclick=fileInfo("+a+") class='btn btn-success' style='padding : 4px 4px' ><span class='glyphicon glyphicon-info-sign'></span></a></tr>";
   }
  }
  ih += "</tbody></table>";
  document.getElementById("parent").innerHTML = ih;
}


function deleteFile(fileName)
{
 var conf = confirm("Are you sure ?");
 if(conf)
   submitJSP("delete",fileName);
}

function fileInfo(id)
{
  var report = JSON.parse(files[id][5]);
  var ih = "<label class='btn btn-default'><b>Report : </b>"+report.name+"</label></br></br>";
      ih += "<label class='btn btn-default'><b>Report Type : </b>"+report.reportType+"</label>&nbsp;&nbsp;";
  document.getElementById('repInfoBody').innerHTML = ih;
  $('#repInfo').fadeIn();
}


function mailFile(id)
{
  var mail = {};
  //var mail = JSON.parse(files[id][4]);
  //var report = JSON.parse(files[id][5]);
  // substituting mail vars if any used in body or subject.
  mail.body = "PFA"; //mail.body.split("$reportname").join(report.name); // report name
  mail.subject = id; //mail.subject.split("$reportname").join(report.name);
  mail.to = ""; 
  /*mail.body = mail.body.split("$sddate").join(files[id][1]); // start time
  mail.subject = mail.subject.split("$sddate").join(files[id][1]);

  mail.body = mail.body.split("$eddate").join(files[id][2].split("\\.")[0]); // end time
  mail.subject = mail.subject.split("$eddate").join(files[id][2].split("\\.")[0]);
  */

  var ih = '<div class="input-group" style="width:96%;" ><span class="input-group-addon" id="basic-addon3">Subject </span><input type="text" placeholder="Enter mail subject." value="'+mail.subject+'" class="form-control" id="subjectid" aria-describedby="basic-addon3"></div></div><div class="input-group" style="width:96%;margin-top:2%;" ><span class="input-group-addon" id="basic-addon3">To </span><input type="text" placeholder="Enter recipients." class="form-control" id="emailtoid" aria-describedby="basic-addon3" value="'+mail.to+'"></div></br><font style="color:grey;font-size:12px;" >Add more than one recipient separated by (;). abc@gmail.com;xyz@gmail.com.... </font><div class="input-group" style="width:96%;" ><span class="input-group-addon" id="basic-addon3"><span class="glyphicon glyphicon-paperclip"></span> </span><input type="text"disabled  id="attach"  value="'+id+'" class="form-control"  aria-describedby="basic-addon3"></div><div class="input-group" style="width:96%;margin-top:2%;" ><span class="input-group-addon" >Body </span><textarea  placeholder="Enter message." class="form-control" id="bodyid" aria-describedby="basic-addon3" >'+mail.body+'</textarea></div></br></br><center><a class="btn btn-success" onclick="sendMail()"  title="Send"><span class="glyphicon glyphicon-send"></span></a>&nbsp;&nbsp;<a onclick=mailFile("'+id+'") class="btn btn-danger" title="Reset"><span class="glyphicon glyphicon-refresh"></span></a></center>';
  document.getElementById('mailInfoBody').innerHTML = ih;
  $('#mailInfo').fadeIn();
}


function hideMailInfo()
{
  $('#mailInfo').fadeOut();
}

function hideReportInfo()
{
  $('#repInfo').fadeOut();
}


function sendMail()
{
   var body = document.getElementById('bodyid').value; 
   var to = document.getElementById('emailtoid').value;
   var attach = document.getElementById('attach').value;
   var subject = document.getElementById('subjectid').value;
   var mail = { "body" : body, "to" : to, "attach" : attach, "subject" : subject };
   submitJSP("mail",JSON.stringify(mail));
}
