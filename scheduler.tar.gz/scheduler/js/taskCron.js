/* File Name : taskCron.js
   Purpose : Used to get reports to be scheduled and related information.
   Author : Tuhin Das */

global.schedule = require('node-schedule');
var pg = require('pg');   // for db connnectivity.
var exec = require('./executeReport.js');  // for report execution.
var sync = require('./executeRsync.js'); // for rsync commands
var dbString = "postgres://netstorm:@localhost/test"; // db url.
var taskTable = "schedulertask";
var reportTable = "reporttable"; 
var clientId = "nikita";
var controller = "";
var tDJson = [];
var isTDRestart = true;
var arrTDEndTime = [];
var prevTDCron="";
var parser = require('cron-parser');
var moment = require('moment');
global.path = "";
(function() { 

var isEnable = function isEnable(taskid,cntrl,clientId)
{
      // connecting db.
      var dbclient = new pg.Client(dbString);
      dbclient.connect(function(err) {
      if(err) {
        exec.schedulerLog('could not connect to postgres',2);
          return false;
      }
      // query for reports
      var query = " select * from " + taskTable + "_" + clientId + "  where taskid = " + taskid + " and  disable = 'enabled'";
      dbclient.query(query, function(err, result)
      {
          dbclient.end();
          if(err)
          {
            exec.schedulerLog("Error in query : " + query,2);
            return false;
          }
          if(result.rows.length > 0) // if task is disabled return false or else return true.
             sync.resourceSync(cntrl);
          else
             exec.schedulerLog("scheduled taskid :" + taskid + " is disabled",2);
      });
  });
}

var isReportEnable = function isReportEnable(taskid,machine,prt,cId,cntrl,protocol)
{
      path = cntrl;
      controller = cntrl;
      clientId = cId;
      //connecting db.
      var dbclient = new pg.Client(dbString);
      dbclient.connect(function(err) {
      if(err) {
        exec.schedulerLog('could not connect to postgres',2);
          return false;
      }
      // query for reports
      var query = " select * from " + taskTable + "_" + clientId + "  where taskid = " + taskid + " and  disable = 'enabled'";
      exec.schedulerLog("the query is "+query,1);
	  exec.schedulerLog("protocol "+protocol,1);
      dbclient.query(query, function(err, result)
      {
          dbclient.end();
          if(err)
          {
            exec.schedulerLog("Error in query : " + query,2);
            return false;
          }
          if(result.rows.length > 0) // if task is disabled return false or else return true.
             getScheduledReports(machine,prt,cId,taskid,cntrl,protocol);
          else
             exec.schedulerLog("scheduled taskid :" + taskid + " is disabled",2);
      });
  });
}

//Method is to schedule previous task fi schedular is stopped
function tdSchPrevTask(machine, prt, cId, controller)
{
  var currTime = (new Date).getTime(); //current time of the system. May be query take time
 
  var dbclient = new pg.Client(dbString);
  dbclient.connect(function(err) {
    if(err)
    {
      return exec.schedulerLog('could not connect to postgres',2);
    }

    // taskid |  taskname  | disable |   datatime | expirytime
    // getting those data record which are enable and task name is TestDesign. using join b/w ncscheduletable and nvreporttable
    var query = "SELECT t1.taskid, t1.taskname, t1.disable, t2.datatime, t1.expirytime, t2.format FROM " + taskTable + "_" + clientId + " t1 INNER JOIN " + reportTable + "_" + clientId + " t2 ON t1.taskid = t2.taskid where t1.taskname='TestDesign' AND t1.disable = 'enabled' AND (CAST(t2.datatime As BigInt) < " + currTime + ") AND ((CAST(t1.expirytime AS BigInt) > " + currTime + ") OR CAST(t1.expirytime As BigInt) = 0 )";
    exec.schedulerLog("Executing BEFORE Query - " + query, 1);

    dbclient.query(query, function(err, result)
    {
      dbclient.end();
      if(err)
      {
        exec.schedulerLog("Error in query : " + query,2);
        return null;
      }

      if(result.rows.length < 1) return;

      //exec.schedulerLog("First time called. Num Rows  = " + result.rows.length, 1);
      result.rows.forEach(function(testObj)
      {
	var endTime = parseInt(testObj.expirytime);
        var startTime = testObj.datatime;

      	var temp = {};
       
	//if test design get ended
        if(endTime > currTime)
     	{
	   var endCronStr = tdEndTimeCron(endTime);//'* * * * * *';
           exec.schedulerLog("First time called. End Crone String = " + endCronStr, 1);
           schedule.scheduleJob(endCronStr,
            function()
            {

              exec.schedulerLog("First time called. Ended schedule started for Row id = " + testObj.taskid, 1);
              isTDEnable(testObj,machine,prt,cId,controller, "onScheduleStart",schedule);
            }
          );
        }
	else
	{ 
	  temp = {"TestName": testObj.format, "Status" : testObj.disable, "Operation" : "Applied"};
          tDJson.push(temp);
	}
      });
      dbclient.end();
      if(tDJson.length > 0)
      {
	//exec.schedulerLog("First time called. Going stop start test = " + JSON.stringify(tDJson), 1);
        exec.executeTest({"jsonObj": tDJson}, machine, prt, cId, controller);
        tDJson = [];
      }
      else
	exec.schedulerLog("First time called. Nothing to schedule = ", 1);
    });
  });

  isTDRestart = false;
}

//Method is to schedule testDesign tasks
function isTDEnable(taskObj, machine, prt, cId, cntrl, calledFor, scheduler)
{
  exec.schedulerLog('**********************************isTDEnable method is calledFor - ' + calledFor, 1);
  var currTime = (new Date).getTime(); //current time of the system. May be query take time

  //if start cron is setted but not job don't know it disabled. disabled task will come.
  if(taskObj.disable == 'disabled')
  {
    exec.schedulerLog('Task Id = ' + taskObj.taskid + 'is disabled', 2);
    return;
  }
  
  var dbclient = new pg.Client(dbString);
  dbclient.connect(function(err) {
  if(err)
  {
    return exec.schedulerLog('could not connect to postgres',2);
  }

  // taskid |  taskname  | disable |   datatime | expirytime
  // getting those data record which are enable and task name is TestDesign. using join b/w ncscheduletable and nvreporttable
    var query = "SELECT t1.taskid, t1.taskname, t1.disable, t2.datatime, t1.expirytime, t2.format FROM " + taskTable + "_" + clientId + " t1 INNER JOIN " + reportTable + "_" + clientId + " t2 ON t1.taskid = t2.taskid where t1.taskname='TestDesign' AND t1.disable = 'enabled' ORDER BY t2.datatime";
  exec.schedulerLog("Executing Query - " + query, 1);
  dbclient.query(query, function(err, result)
  {
    dbclient.end();
    if(err)
    {
      exec.schedulerLog("Error in query : " + query,2);
      return null;
    }

    if(result.rows.length < 1) return;
    result.rows.forEach(function(testObj)
    {
      //end time zero means run forever
      var endTime = currTime - parseInt(testObj.expirytime);
      var startTime = currTime - testObj.datatime;
      var millisec = 5000;
      exec.schedulerLog("Group = " + testObj.format + ", Start = " + testObj.datatime + ", Exp " + parseInt(testObj.expirytime) + ", currTime = : " + currTime + ", startTime = " + startTime + ", endTime = " + endTime, 1);
      //its already scheduled, so we are not adding in json
      if(startTime > millisec && (endTime < 0 || endTime > millisec))
      {
        exec.schedulerLog("its already scheduled, so we are not adding in json . startTime = " + startTime + ", endTime = " + endTime + ", millisec = " + millisec, 1);
        return;
      }
      //schedule not yet
      if(millisec < (0 - startTime))
      {
        exec.schedulerLog("Schdule not yet start.  startTime = " + startTime + ", millisec = " + millisec, 1);
        return;
      }
      var temp = {};
     //exec.schedulerLog("currTime = : " + currTime + ", startTime = " + startTime + ", endTime = " + endTime, 1);
      if(startTime < millisec)
      {
        temp = {"TestName": testObj.format, "Status" : testObj.disable, "Operation" : "Applied"};
        //exec.schedulerLog(", parseInt(testObj.expirytime) = " + parseInt(testObj.expirytime) + ", arrTDEndTime = " + arrTDEndTime, 1);
        var tmpEndTime = parseInt(testObj.expirytime);
        //scheduling end time of the test design
        if(tmpEndTime >  0 && arrTDEndTime.indexOf(tmpEndTime) < 0)
        {
          var endCronStr = tdEndTimeCron(parseInt(testObj.expirytime));//'* * * * * *';
          exec.schedulerLog("bef going to schedule for end Time endCronStr=" + endCronStr, 1);
         scheduler.scheduleJob(endCronStr,
            function()
            {
             exec.schedulerLog("going to schedule for end Time endCronStr=" + endCronStr, 1);
              isTDEnable(testObj,machine,prt,cId,controller, "stopping",scheduler);
            }
          );
	  arrTDEndTime.push(tmpEndTime);
        }
        tDJson.push(temp);
      }
      //if test design get ended
      else if(endTime < millisec)
      {
        //exec.schedulerLog("else if endTime =" + endTime, 1);
        temp = {"TestName": testObj.format, "Status" : testObj.disable, "Operation" : "Stopped"};
        tDJson.push(temp);
      }

    });
    if(tDJson.length > 0)
    {
      exec.schedulerLog(" Going to start stop test  = " + JSON.stringify(tDJson), 1);
      exec.executeTest({"jsonObj": tDJson}, machine, prt, cId, cntrl);
    }
    else
      exec.schedulerLog(" Nothing to schedule  *************************************" , 1);
    tDJson = [];
  });
});

}

function tdEndTimeCron(endTime)
{
  var date = new Date();
  date.setTime(endTime);
  var month = date.getMonth()+1;
  return "0 " + date.getMinutes() + " " + date.getHours() + " " + date.getDate() + " " + month +" *";
}

function Task(name, taskid, scheduleId)
{
  this.taskid = taskid;
  this.scheduleId = scheduleId;
  this.name = name;
}

//This is array of currently scheduled task.
var TaskList = [];
var oldTaskList = [];

var getTaskList = function(machine,prt,cId,fp, updateFlag, condition, protocol)
{
      path = fp;
      controller = fp;
      clientId = cId;
      var cmd = require('child_process').exec; 
      var dbclient = new pg.Client(dbString);
      var task;
      condition = condition || "";
      
      //Note: we will compare new task from the last task list.
      if(updateFlag)
      {
        oldTaskList = TaskList;
      }
       
      dbclient.connect(function(err) {
      if(err) {
        exec.schedulerLog('could not connect to postgres',2);
        return false;
      }
      // query for reports
      var query = " select * from " + taskTable + "_" + cId + " " + condition;
      dbclient.query(query, function(err, result)
      {
          dbclient.end();
          if(err)
          {
            exec.schedulerLog("Error in query : " + query,2);
            return null;
          }

          var scheduleFlag = false;
          // In order to keep scheduler alive in case of no tasks in the table.
          if(result.rows.length == 0)
          {
            exec.schedulerLog("Keep alive check after every 12 hours",1);
            setInterval(function(){getTaskList(machine,prt,cId,fp, updateFlag, condition, protocol);},  12*60*60*1000);
            return;
          }

          result.rows.forEach(function(row) {
          exec.schedulerLog("the taskname is "+row.taskname);
           //case1: update flag is false; when scheduler if already stop and we are starting first time
                   // - schedule task
           //case2: status is null and update flag is true; when scheduler is running and add/update any field
                   // - delete previous defined schedulerid if any and schedule new one
           //case3: status is scheduled and update flag is true;when scheduler is running and add/update any field, then other than updated id
                   // - no need to do anything
           scheduleFlag = false;

           if(!updateFlag)
           {
             exec.schedulerLog("schedule the task for taskid - " + row.taskid, 1);
             scheduleFlag = true;
           }
           else if(updateFlag && row.status == null)
           {
             scheduleFlag = true;
             for(var i =0;i<oldTaskList.length;i++)
             {
               if(oldTaskList[i].taskid == row.taskid)
               {
                 exec.schedulerLog("cancel and reschedule the task for taskid - " + row.taskid, 1);
                 oldTaskList[i].scheduleId.cancel();
                 TaskList.pop(oldTaskList[i]);
                 break;
               }
             }
             oldTaskList = [];
           }
           else
           {
             exec.schedulerLog("Already scheduled task and taskid - " + row.taskid, 1);
           }


           if(scheduleFlag)
           {
              task = new Task(row.taskname, row.taskid, null);
              if(row.taskname == "report")
              {
                task.scheduleId = schedule.scheduleJob(row.cronstring,
                  function()
                  {
                     if(parseInt(row.expirytime) == 0 || parseInt(row.expirytime) > parseInt((new Date).getTime()) )
                     {
                       console.log("node /home/cavisson/"+controller+"/webapps/scheduler/js/taskExecute \'" + row.taskname + "\' " +  row.taskid + " " + machine + " " + prt + " " + cId);
                       cmd("node /home/cavisson/"+controller+"/webapps/scheduler/js/taskExecute \'" + row.taskname + "\' " +  row.taskid + " " + machine + " " + prt + " " + cId + " " + controller, function(error, stdout, stderr) {

                            // command output is in stdout
                            if(error) exec.schedulerLog(error.stack,2);
                       });

                     }
                     else
                       exec.schedulerLog("scheduled taskid :" + row.taskid + " has expired",2);
                  }
               );
              }

              //For Scheduling Run Command
              if(row.taskname.indexOf("Run Command") > -1 )
              {
                 task.scheduleId = schedule.scheduleJob(row.cronstring,
                 function()
                 {
                   if(parseInt(row.expirytime) == 0 || parseInt(row.expirytime) > parseInt((new Date).getTime()) )
                   {
                     isReportEnable(row.taskid,machine,prt,cId,controller,protocol);
                   }
                   else
                     exec.schedulerLog("scheduled taskid :" + row.taskid + " has expired",2);
                   }
                );

              }
	      // For Scheduling Scenario
	      else if(row.taskname.indexOf("Scenario Schedule") > -1 ) {
		task.scheduleId = schedule.scheduleJob(row.cronstring,
                 function()
                 {
                   if(parseInt(row.expirytime) == 0 || parseInt(row.expirytime) > parseInt((new Date).getTime()) )
                   {
                     exec.schedulerLog(row.taskname +" is scheduled",1);
                     isReportEnable(row.taskid,machine,prt,cId,controller,protocol);
                   }
                   else
                     exec.schedulerLog("scheduled taskid :" + row.taskid + " has expired",2);
                   }
                );	
	      }
              //word/html/excel report
              else if(row.taskname.indexOf("Report") > -1)
              {
                task.scheduleId = schedule.scheduleJob(row.cronstring,
                  function()
                  {
                     if(parseInt(row.expirytime) == 0 || parseInt(row.expirytime) > parseInt((new Date).getTime()) )
                     {
					   var cronString = row.cronstring;
					   var prevDate = new Date(parser.parseExpression(cronString).prev().toString());
					   var nxtDate = new Date(parser.parseExpression(cronString).next().toString());
					   
		               exec.schedulerLog("Cron String is matched ===  "+protocol,1)
					   exec.schedulerLog("pre time span value ===  "+prevDate,1)
					   exec.schedulerLog("next time span value ===  "+nxtDate,1)
					   
					   
					   var interval = moment(prevDate).diff();
					   var intervalNxt = moment(nxtDate).diff();
					   
					   exec.schedulerLog("Cron String is matched and intervalPrev is ===  "+interval+",intervalNxt = "+intervalNxt,1)
					   
                       if(interval <= 5000 || intervalNxt >= -5000)
                       isReportEnable(row.taskid,machine,prt,cId,controller,protocol);
                       else
                       exec.schedulerLog("This scheduled task already run for time span "+new Date(parser.parseExpression(cronString).prev().toString()),2);
                     }
                     else
                       exec.schedulerLog("scheduled taskid :" + row.taskid + " has expired",2);
                  }
                );
              }
              else if(row.taskname == "rsync") // for rsync related task
              {
                task.scheduleId = schedule.scheduleJob(row.cronstring,
                  function()
                  {
                       // function for executing rsync command.
                       if(parseInt(row.expirytime) == 0 || parseInt(row.expirytime) > parseInt((new Date).getTime()))
                       {
                        cmd("node /home/cavisson/"+controller+"/webapps/scheduler/js/taskExecute.js rsync " + row.taskid + " " + controller + " " + cId, function(error, stdout, stderr) {
                            // command output is in stdout
                            if(error) exec.schedulerLog(error.stack,2);
                           });
                       }
                       else
                         exec.schedulerLog("scheduled taskid :" + row.taskid + " has expired",2);
                  }
                );
              }
              else if(row.taskname == "TestDesign" || row.taskname.indexOf("TestDesign") > -1)
              {
                exec.schedulerLog("Task Name = " + row.taskname + ", isTDRestart = " + isTDRestart + ",row.cronstring = " + row.cronstring, 1);
                if(isTDRestart)
                  tdSchPrevTask(machine, prt, cId, controller);

                task.scheduleId = schedule.scheduleJob(row.cronstring,
                  function()
                  {
                    //exec.schedulerLog("prevTDCron = " + prevTDCron + ", row.cronstring = " + row.cronstring, 1);
                    if(prevTDCron == "" || prevTDCron != row.cronstring)
                    {
                      prevTDCron = row.cronstring;
                      isTDEnable(row, machine, prt, cId, controller, "start",schedule);
                    }
                  }
                );
              }
              else if(row.taskname == "executeTest")
              { 
                  task.scheduleId = schedule.scheduleJob(row.cronstring,
                  function()
                  {
                    
			
		    if(parseInt(row.expirytime) == 0 || parseInt(new Date(row.expirytime).getTime()) > parseInt((new Date).getTime()) )
                    {
                                        
                          exec.schedulerLog("node /home/cavisson/"+controller+"/webapps/scheduler/js/taskExecute \'" + row.taskname + "\' " +  row.ff1 + " " + machine + " " + prt + " " + cId + " " + controller+ " " + protocol);                                           cmd("node /home/cavisson/"+controller+"/webapps/scheduler/js/taskExecute \'" + row.taskname + "\' " +  row.ff1 + " " + machine + " " + prt + " " + cId + " " + controller + " " + protocol, function(error, stdout, stderr) {
                            
                            // command output is in stdout
                            if(error) exec.schedulerLog(error.stack,2);
                       });
                     
                     }
                     else
                       exec.schedulerLog("scheduled taskid :" + row.taskid + " has Expired",2);
                  }
               );
              }
              /*
               * Handling for other type of tasks.
               */
              else {
                task.scheduleId = schedule.scheduleJob(row.cronstring,
                  function()
                  {
                       if(parseInt(row.expirytime) == 0 || parseInt(row.expirytime) > parseInt((new Date).getTime()))
                       {
                        cmd("node /home/cavisson/"+controller+"/webapps/scheduler/js/taskExecute.js \'" + row.taskname  +"\' "+ row.taskid + " \'" + row.ff2+"\' \'"  + row.ff1 +"\'", function(error, stdout, stderr) {
                            // command output is in stdout
                            if(error) exec.schedulerLog(error.stack,2);
                           });
                       }
                       else
                         exec.schedulerLog("scheduled taskid :" + row.taskid + " has expired",2);
                  }
                );
              }

              updateTaskStatus(row.taskid,"scheduled");
              TaskList.push(task);
           }
          
        });
      });
  });
}
// method to get all the scheduled reports.
var getScheduledReports = function(ipa,porta,clientIda,rid,fp,protocols)
{
       //if(isDeleted(rid)) return;
       ip = ipa;
       port = porta;
       clientId = clientIda;
       controller = fp;
	   protocol = protocols;
      // connecting db.
      var dbclient = new pg.Client(dbString);
      dbclient.connect(function(err) {
      if(err) {
        return exec.schedulerLog('could not connect to postgres',2);
      }
      // query for reports
      var query = " select * from " + reportTable + "_" + clientId + " where taskid = " + rid;
      dbclient.query(query, function(err, result) 
      {
          dbclient.end();
          if(err) 
          {
            exec.schedulerLog("Error in query : " + query,2);
            return null;
          }
          if(result.rows.length < 1) return;
          result.rows.forEach(function(row) {  genReports(row,protocol)  } );
          //genReports(result.rows[0]);
      });
});
}

var days = {
    "sunday" : 0,
    "monday" : 1,
    "tuesday" : 2,
    "wednesday" : 3,
    "thursday" : 4,
    "friday" : 5,
    "saturday" : 6
}

var DAYS = {
    "sun" : 0,
    "mon" : 1,
    "tue" : 2,
    "wed" : 3,
    "thu" : 4,
    "fri" : 5,
    "sat" : 6
}


var ip = "";
var port = "";
var protocol = "";
// for executing all the scheduled reports and generate xls for each.
var genReports = function(info,protocol)
{
     exec.schedulerLog("the reporttype is "+info.reporttype+"   protocol is   "+protocol); 
     if((new Date).getTime() <= info.expiryTime) return;  // if scheduling has expired.
     // processing start time and end time for periodic and one time report scheduled.
     // expecting non zero as  endtime in case of one time scheduled report.
   if((info.reporttype).indexOf("Report") == -1)
   {
     if(info.datatime.split("&")[1] == '0' || info.datatime.split("&")[1] == null || info.datatime.split("&")[1] == undefined)
     {
        var startTime = 0;
        var endTime = 0;
        // for periodically scheduled reports.
        var dta =   info.datatime.split("&")[0].split("$$");/* info.startTime.split("|");*/
        var currentMillis = (new Date()).getTime();
          // handling days only in case of last week.
          if(dta[0].toLowerCase().indexOf("week") > -1)
          {
            var diffChk = 7 * 24 * 60 * 60 * 1000;
            console.log(DAYS[dta[1].toLowerCase()]);
            console.log((new Date()).getDay());
            if(((new Date()).getDay() - DAYS[dta[1].toLowerCase()]) < 0) //for previous week's day  
            {
              endTime = (currentMillis - diffChk) +  ((DAYS[dta[1].toLowerCase()] - (new Date()).getDay()) * 24 * 60 * 60  * 1000);
              startTime = endTime - diffChk;
              console.log(startTime);
              console.log(endTime);
              var tmp = new Date(startTime);
              startTime = (parseInt(tmp.getMonth())+1) +"/"+ tmp.getDate() + "/" + tmp.getFullYear();
              console.log(startTime + " " + dta[2]);
              startTime = (new Date(startTime + " " + dta[2])).getTime();
              endTime  =  startTime + diffChk;  
            }
            else // for this week's day
            {
              endTime = currentMillis +  ((DAYS[dta[1].toLowerCase()] - (new Date()).getDay()) * 24 * 60 * 60  * 1000);
              startTime = endTime - diffChk;
              endTime = currentMillis;
              var tmp = new Date(startTime);
              startTime = (parseInt(tmp.getMonth())+1) +"/"+ tmp.getDate() + "/" + tmp.getFullYear();
              startTime = (new Date(startTime + " " + dta[2])).getTime();
              endTime  =  startTime + diffChk;
            }
          }
          else if(dta[0].toLowerCase().indexOf("month") > -1)
          {
            var tmpMonth = (new Date()).getMonth();
            if(tmpMonth == 0) // if first month of the year.
            {
                startTime = "12/" + (new Date()).getDate() + "/" + parseInt((new Date()).getFullYear())-1;
                endTime = "1/" + parseInt((new Date()).getDate())-1 + "/" + parseInt((new Date()).getFullYear());
            }
            else
            {
                startTime = tmpMonth + "/" + (new Date()).getDate() + "/" + parseInt((new Date()).getFullYear());
                endTime = parseInt(tmpMonth)+1 + "/" + (new Date()).getDate() + "/" + parseInt((new Date()).getFullYear());
            }
            startTime = (new Date(startTime + " " + dta[2])).getTime();
            endTime = (new Date(endTime + " " + dta[2])).getTime();
          } 
          else if(dta[0].toLowerCase().indexOf("year") > -1)
          {
            startTime = parseInt((new Date()).getMonth())+1 + "/" + (new Date()).getDate() + "/" + (parseInt((new Date()).getFullYear())-1);  
            endTime = parseInt((new Date()).getMonth())+1 + "/" + (new Date()).getDate() + "/" + parseInt((new Date()).getFullYear());
            startTime = (new Date(startTime + " " + dta[2])).getTime();
            endTime = (new Date(endTime + " " + dta[2])).getTime();
          }
          else if(dta[0].toLowerCase().indexOf("day") > -1) // in case of last day with specific start time.
          {
            var st = new Date(currentMillis - 24 * 60 * 60 * 1000);
            startTime = parseInt(st.getMonth())+1 + "/" + st.getDate() + "/" + parseInt(st.getFullYear());
            startTime = (new Date(startTime + " " + dta[2])).getTime();
            endTime = parseInt(startTime) + 24 * 60 * 60 * 1000;
          }
          else
          {
            endTime = currentMillis;
            if(dta[0].toLowerCase().indexOf("minutes") > -1)
               startTime = currentMillis - 15 * 60 * 1000;
            else if(dta[0].toLowerCase().indexOf("hour") > -1)
               startTime = currentMillis - parseInt(dta[0].split(" ")[0]) * 60 * 60 * 1000;
            else
               startTime = currentMillis - 24 * 60 * 60 * 1000;
          } 
          exec.initReport(info.taskid,startTime,endTime,info.bucket,"",info.crqobj,ip,port,controller,info.mailobj, info.reporttype,protocol);
        } 
     else
     {
       // for one time scheduled reports.
       exec.initReport(info.taskid,info.datatime.split('&')[0],info.datatime.split('&')[1],info.bucket,"",info.crqobj,ip,port,controller,info.mailobj, info.reporttype,protocol); 
     } 
  }
  else if( info.reporttype.indexOf("Run Command") > -1 )
  {
    exec.schedulerLog("the case of run Comand",1);
    exec.initReport(info.taskid,info.datatime.split('&')[0],info.datatime.split('&')[1],info.bucket,"",info.crqobj,ip,port,controller,info.mailobj, info.reporttype,protocol);
  }
  else if( info.reporttype.indexOf("Scenario Schedule") > -1 ) {
    exec.schedulerLog("the case of Scenario Schedule",1);
    exec.initReport(info.taskid,info.datatime.split('&')[0],info.datatime.split('&')[1],info.bucket,"",info.crqobj,ip,port,controller,info.mailobj, info.reporttype,protocol);
  }
  else
  {
     // for one time scheduled reports.
     exec.initReport(info.taskid,info.datatime.split('&')[0],info.datatime.split('&')[1],info.bucket,"",info.crqobj,ip,port,controller,info.mailobj, info.reporttype,protocol);
  }

}

// function to update status of a task
function updateTaskStatus(taskid,stat)
{
  // connecting db.
      var dbclient = new pg.Client(dbString);
      dbclient.connect(function(err) {
      if(err) {
        return exec.schedulerLog('could not connect to postgres',2);
      }
      // query for reports
      var query = " update " + taskTable + "_" + clientId + " set status='" +stat +"' where taskid = " + taskid;
      dbclient.query(query, function(err, result)
      {
          dbclient.end();
          if(err)
          {
            exec.schedulerLog("Error in query : " + query,2);
            return null;
          }
      });
  });
}

function isDeleted(taskid)
{
      // connecting db.
      var dbclient = new pg.Client(dbString);
      dbclient.connect(function(err) {
      if(err) {
        return exec.schedulerLog('could not connect to postgres',2);
      }
      // query for reports
      var query = " select * from " + taskTable + "_" + clientId + "  where taskid = " + taskid;
      dbclient.query(query, function(err, result)
      {
          dbclient.end();
          if(err)
          {
            exec.schedulerLog("Error in query : " + query,2);
            return false;
          }
          if(result.rows.length > 0)
             return false;
      });
  });
  return true;
}

if(typeof exports != 'undefined')
  {
    if( typeof module !== 'undefined' && module.exports ) {
      exports = module.exports = { "getTaskList" : getTaskList, "isEnable" : isEnable}
   }
   //exports.getTaskList = getTaskList;
   exports = { "getTaskList" : getTaskList, "isEnable" : isEnable};
  }
  else
    global = { "getTaskList" : getTaskList, "isEnable" : isEnable};

  global.getTaskList = getTaskList;
  global.isEnable = isEnable;
  global.isReportEnable = isReportEnable;
}).call(global);   

