/*File Name : executeRsync.js
  Purpose : to execute pull mode rsync command using scheduler.
  Author : Nikita/Tuhin */


fs = require('fs');
var log = require('./executeReport.js');
global.conf = "";
global.temp = "";
global.controller = "";
global.path = "";
(function()
{
var resourceSync = function(cntrl)
{
  log.schedulerLog("Initializing Resource Sync");
  global.controller = cntrl;
  global.path = cntrl;
  fs.readFile('/home/cavisson/'+global.controller + '/webapps/sys/syncConfig.js', 'utf8', function (err,data) {
    if (err) {
      return log.schedulerLog(err);
    }
  global.temp = data;
  syncCommand();
  });
}



var exec = require('child_process').exec;

var syncCommand = function()
{
 
 global.conf = JSON.parse(global.temp);
  // creating command.
 var SyncConf = global.conf;
 // check for pull/push mode.
 
 if(SyncConf.mode != "pull") return;
 execSync(SyncConf,0);
}

function execSync(syncObj,i)
{
   console.log("called" + i);
   //if(!syncObj.confList[i]) return;
   if(i > (syncObj.confList.length - 1)) return;
   if(syncObj.confList[i] == null)
   {
    execSync(syncObj,i+1);
    return;
   }
   var SyncConf = syncObj;
   var tmp = i;
   console.log(SyncConf.protocol);
   if(SyncConf.protocol == 'sync')
    var cmd = "java -cp $NS_WDIR/webapps/netvision/WEB-INF/lib/nvUtil.jar:$NS_WDIR/webapps/netvision/WEB-INF/lib/json_simple-1.1.jar:$NS_WDIR/webapps/netstorm/WEB-INF/lib/java-getopt-1.0.9.jar:. com.cavisson.nv.util.NVSyncUtility -h " +SyncConf.confList[i].domain +  " -u " + SyncConf.confList[i].user + " -p " +SyncConf.confList[i].password +" -s "+ SyncConf.confList[i].module +" -d "+ SyncConf.basePath + "/" + SyncConf.confList[i].directory+ "/" + SyncConf.confList[i].subdirectory + " -m " + SyncConf.protocol + " -o " + SyncConf.confList[i].portnumber  + " -l " + syncObj.confList.length;
   else
    var cmd = "java -cp $NS_WDIR/webapps/netvision/WEB-INF/lib/nvUtil.jar:$NS_WDIR/webapps/netvision/WEB-INF/lib/json_simple-1.1.jar:$NS_WDIR/webapps/netstorm/WEB-INF/lib/java-getopt-1.0.9.jar:. com.cavisson.nv.util.NVSyncUtility -h " +SyncConf.confList[i].domain +  " -u " + SyncConf.confList[i].user + " -p " +SyncConf.confList[i].password +" -s "+ SyncConf.confList[i].sourcepath +" -d "+ SyncConf.basePath + "/" + SyncConf.confList[i].directory+ "/" + SyncConf.confList[i].subdirectory + "/" + " -m " + SyncConf.protocol + " -o " + SyncConf.confList[i].portnumber  + " -l " + syncObj.confList.length;   
 
   setTimeout(function(){ exec(cmd, function(error, stdout, stderr) {
       // command output is in stdout
      console.log(cmd);
       if(error) log.schedulerLog(error.stack,2);
       log.schedulerLog(cmd,1);
       
  }); execSync(syncObj,tmp+1)},10000);
}

 if(typeof exports != 'undefined')
  {
    if( typeof module !== 'undefined' && module.exports ) {
      exports = module.exports = resourceSync;
   }
   exports.resourceSync = resourceSync;
  }
  else
    global.resourceSync = resourceSync;

}).call(global);
  
