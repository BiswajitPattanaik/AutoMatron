/*
  File : taskList.js
  Purpose : Contains method to show and manipulate tasks scheduled.
  Author : Tuhin Das
*/

var productType;

function init(productTypeTemp)
{
   productType = productTypeTemp;
   loadTaskTable(); 
}

//populates tasks info in task table.
function loadTaskTable()
{
  var menus = showMenus();
  var ih;
  var viewAllReportIcon = "<a class='btn btn-warning' style='padding : 4px 4px;float:right;margin-top:2px;margin-right:4px;' href='reportList.jsp' title='View All Reports'>";
  if(productType == "NVSM" || productType == "NDE" || productType == "NS" || productType == "NC")
  {
    $("#menuID").append(menus);
    ih = "<div style='' class='panel panel-default'><div class='panel-heading'><h4>Scheduled Tasks<a class='btn btn-success' style='padding : 4px 4px;float:right;margin-top:2px;' href='taskScheduler.jsp?product="+productType+"' title='Add Task'  ><span class='glyphicon glyphicon-plus'></span></a></h4></div><div class='panel-body' style='max-height: 70%;overflow: auto;'>";
  }
  else
  {
    ih = "<div style='' class='panel panel-default'><div class='panel-heading'><h4>Scheduled Tasks<a class='btn btn-success' style='padding : 4px 4px;float:right;margin-top:2px;' href='taskScheduler.jsp?product="+productType+"' title='Add Task'  ><span class='glyphicon glyphicon-plus'></span></a>"+viewAllReportIcon+"<span class='glyphicon glyphicon-stats'></span></a></h4></div><div class='panel-body' style='max-height: 70%;overflow: auto;'>";
  }
  ih += "<table class='table table-striped table-bordered table-condensed' >";
  // adding headers
  ih += "<thead><tr><th>Task Type</th><th>Description</th><th>Schedule Time</th><th>Schedule Expiry Time</th><th>Status</th><th>Actions</th></tr></thead><tbody>";
  // adding tasks
  if(tasks.length == 0)
  {
     ih += "<tr><td colspan='100%'>No tasks to display.</td></tr>";
  }
  else
  {
   for(var a = 0; a < tasks.length; a++)
   {
     ih +=  "<tr><td>"+tasks[a][2]+"</td><td>"+((tasks[a][7] == "null" || tasks[a][7] == undefined) ? "<center>-</center>" : decodeURI(tasks[a][7])) +"</td><td>"+((tasks[a][4] == "null" || tasks[a][4] == undefined ) ? "<center>-</center>" : tasks[a][4])+"</td><td>"+((tasks[a][3] == "0") ? "Not Set" : tasks[a][3])+"</td><td>"+tasks[a][6]+"</td><td><a title='Delete Task'  onclick=\"deleteTask("+tasks[a][0]+",'"+tasks[a][2]+"')\" class='btn btn-danger' style='padding : 4px 4px' ><span class='glyphicon glyphicon-trash'></span></a>&nbsp; &nbsp;<a title='Update Task'  onclick=updateTask("+a+") class='btn btn-warning' style='padding : 4px 4px;' ><span class='glyphicon glyphicon-pencil'></span></a>";
     if(tasks[a][6] == "disabled")
       ih += "&nbsp; &nbsp;<a title='Enable Task' onclick=disableEnableTask("+tasks[a][0]+",'enabled') class='btn btn-success' style='padding : 4px 4px;' ><span class='glyphicon glyphicon-ok'></span></a>";
     else
       ih += "&nbsp; &nbsp;<a title='Disable Task'  class='btn btn-danger' onclick=disableEnableTask("+tasks[a][0]+",'disabled')  style='padding : 4px 4px;' ><span class='glyphicon glyphicon-remove'></span></a>";
     /*if(tasks[a][2].toLowerCase().indexOf('report')>-1)
       ih += "&nbsp; &nbsp;<a class='btn btn-warning' style='padding : 4px 4px;margin-top:2px;' href='reportList.jsp?tid="+tasks[a][0]+"' title='View Reports'  ><span class='glyphicon glyphicon-stats'></span></a>"; */
 
   }
   ih += "</td></tr>";
   }
  ih += "</tbody></table></div></div>";
  document.getElementById('parent').innerHTML = ih;
}

function deleteTask(id,type)
{
  var chkdel = confirm("Are you sure you want to delete task?");

  if(chkdel == false)
    return;
 
 submitJSP("delete",id+"|"+type); 
}

function disableEnableTask(id,what)
{
  var type = confirm("Are you sure you want to " + what + " task?");

  if(type == false)
    return;

 submitJSP("disableEnable",id+"|"+what);
}

function showReportInfo(id)
{
  var info = reports[id].split("|");
  var report = JSON.parse(info[6]);
  var mail = JSON.parse(info[5]);
  var ih = "<label class='btn btn-default'><b>Report : </b>"+report.name+"</label></br></br>";
      ih += "<label class='btn btn-default'><b>Report Type : </b>"+report.reportType+"</label>&nbsp;&nbsp;";
      ih += "<label class='btn btn-default'><b>Report Format : </b>"+info[3]+"</label></br></br>";
  document.getElementById('repInfoBody').innerHTML = ih;
  $('#repInfo').fadeIn();
}


function showMailInfo(id)
{
  var info = reports[id].split("|");
  var mail = JSON.parse(info[5]);
  var ih = '<div class="input-group" style="width:96%;" ><span class="input-group-addon" id="basic-addon3">Subject </span><input type="text" placeholder="Enter mail subject." value="'+mail.subject+'" class="form-control" id="subjectid" aria-describedby="basic-addon3"></div></div><div class="input-group" style="width:96%;margin-top:2%;" ><span class="input-group-addon" id="basic-addon3">To </span><input type="text" placeholder="Enter recipients." class="form-control" id="emailtoid" aria-describedby="basic-addon3" value="'+mail.to+'"></div></br><font style="color:grey;font-size:12px;" >Add more than one recipient separated by (;). abc@gmail.com;xyz@gmail.com.... </font><div class="input-group" style="width:96%;margin-top:2%;" ><span class="input-group-addon" >Body </span><textarea  placeholder="Enter message." class="form-control" id="bodyid" aria-describedby="basic-addon3" >'+mail.body+'</textarea></div></br></br><center><a class="btn btn-success" title="Send"><span class="glyphicon glyphicon-send"></span></a>&nbsp;&nbsp;<a class="btn btn-danger" title="Reset"><span class="glyphicon glyphicon-refresh"></span></a></center>';
  document.getElementById('mailInfoBody').innerHTML = ih;
  $('#mailInfo').fadeIn();
}

function hideReportInfo()
{
  $('#repInfo').fadeOut();
}

function hideMailInfo()
{
  $('#mailInfo').fadeOut();
}

function sendMail()
{


}

function updateTask(index)
{
  window.location = "taskScheduler.jsp?task="+tasks[index][0]+"&product="+productType;  
}
