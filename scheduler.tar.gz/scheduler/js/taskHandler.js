const exec = require('child_process').exec;

(function()
{  
  function execute(taskid, command, taskName, taskType){   
    exec(command, function(error, stdout, stderr) {
       
    var fs = require('fs');
    var a = new Date();
    var file = process.env.NS_WDIR + "/webapps/scheduler/tmp/" + taskName.split(" ").join("_") + "_" + new Date().valueOf() ;
    if(error) 
       fs.writeFile(file + ".error", error , function (err) {
            if(err) console.log(err);
       });

    if(stderr)
       fs.writeFile(file + ".error", stderr, function (err) {
            if(err) console.log(err);
       });
    
    if(stdout)
       fs.writeFile(file + ".log", stdout , function (err) {
            if(err) console.log(err);
       });
    });
  }

  if(typeof exports != 'undefined')
  {
    if( typeof module !== 'undefined' && module.exports ) {
      exports = module.exports = execute;
    }
    exports.execute = execute;
  }
  else
    global.execute = execute;
}).call(global);





