/* File : taskScheduler.js
   Purpose : contains methods to create and manage schedule wizard.
   Author : Tuhin Das  */

var min = [];
var hour = [];
var scheduleObj ={};
var DAYS = ["MON","TUE","WED","THU","FRI","SAT","SUN"];
var DAYS1 = ["","MON","TUE","WED","THU","FRI","SAT","SUN"];
var productType = "NV";
(function()
{
   for(var a = 0; a < 60; a++)
   {
     if(a <= 9)
     {
       min.push("0" + a);
       hour.push("0"+a);
     }
     else
     {
       min.push("" + a);
       if(a < 24)
         hour.push(""+a);
     }
   }
})();



// method to create any html element.
function createE(type,att,innerHTML)
{
  var e = document.createElement(type);
  for(var a = 0; a < att.length; a++)
	  e.setAttribute(att[a][0],att[a][1]); // setting attributes
  e.innerHTML = innerHTML; 
  return e;
}

// method to create wizard steps
function createSteps(taskid)
{
  currentTask = list[taskid];
  var pr = document.getElementById("parent"); // container for wizard
  if(document.getElementById('wizard'))
      pr.removeChild(document.getElementById('wizard'));
  document.getElementById('task').style.display = "none";  // hiding prompt div.
  var wizard = createE('DIV',[['class','panel panel-default wizard'],['id','wizard']],'');
  var navList = createE('DIV',[['class','navList'],['id','navList']],'');
  wizard.appendChild(navList);
  for(var a = 0; a < list[taskid].steps; a++)
  {
	 // adding nav links for wizard.
	 if(a == 0)
	    navList.appendChild(createE('A',[['class','btn btn-warning home'],['id','nav-1'],['onclick','navAction(-1)']],"<span  style='margin-left:20%;margin-top:8px;margin-bottom:3px;' height='30px' width='30px' class='glyphicon glyphicon-home'></span>"));
     navList.appendChild(createE('A',[['active','false'],['name','navs'],['class','btn btn-default nav'],['id','nav'+a],['onclick','navAction('+a+')']],"<h4 style='margin-left:12px;margin-right:12px;' >Step " + (a+1)+"</h4>"));
	 // adding wizard steps.
     var step = createE('DIV',[['class','panel panel-info step'],['id','step'+a],['name','step']],'');
	 step.appendChild(createE('DIV',[['class','panel-heading stepTitle'],['id','stepTitle'+a]],''));
	 step.appendChild(createE('DIV',[['class','panel-body stepBody'],['id','stepbody'+a]],''));
	 wizard.appendChild(step);
  }
  pr.appendChild(wizard);
  // adding prev next links for wizard.
  var prevNext = createE('UL',[['class','pager prevNext']],'');
  var t1 = createE('LI',[[]],'');
  t1.appendChild(createE('A',[['id','prev'],['class','pn']],'Previous'));
  prevNext.appendChild(t1);
  var t1 = createE('LI',[[]],'');
  t1.appendChild(createE('A',[['id','next'],['class','pn']],'Next'));
  prevNext.appendChild(t1);
  wizard.appendChild(prevNext);
  loadData();
  initialAdjustment();
  setPrevNext(0);
  setPreviousValues();
}


// method to load step titles and body UI.
function loadData()
{
  var sD = currentTask.stepInfo;
  for(var a = 0; a < sD.length; a++ )
  {
    document.getElementById('stepTitle'+a).innerHTML = "<h4><label class='label label-default' style='padding-top:6px;padding-bottom:6px;' >"+currentTask.taskName.toUpperCase()+"</label>&nbsp;&nbsp;"+sD[a].title+"</h4>";
    if(sD[a].view)
      eval(sD[a].view+"("+a+")");
  }
}

// options to show on weekly , hourly or monthly.
function showFrequency(idx)
{
     var occtab = document.getElementById('occurence').children;
     for(var a = 0; a < occtab.length; a++)
     { 
       if(idx == a)
          occtab[a].setAttribute('class','active');
       else
          occtab[a].removeAttribute('class');
     }
     document.getElementById('htable').style.display = "none";
     document.getElementById('wtable').style.display = "none";
     document.getElementById('mtable').style.display = "none";
     if(idx == 0)
       document.getElementById('htable').style.display = "block";
     else if(idx == 1)
       document.getElementById('wtable').style.display = "block";
     else
       document.getElementById('mtable').style.display = "block";
}

var day = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
var number = ["First","Second","Third","Fourth"];
// creates time range view in step
function timeRange(step)
{
   var monthlyDesc = "E.g. Day 1 of Every 1 Month(s)\n"+
                     "Schedule is generated on the first day of every month\n"+
                     "E.g. Day 5 of Every 2 Month(s)\n"+
                     "Schedule is generated on the fifth day of every 2 months"
   var ih = "<ul class='nav nav-tabs' id='occurence' ><li role='presentation' class='active' style='cursor:pointer;' ><a onclick=showFrequency(0) >Hourly</a></li><li style='cursor:pointer;' role='presentation'><a onclick=showFrequency(1)>Weekly</a></li><li style='cursor:pointer;' role='presentation'><a onclick=showFrequency(2)>Monthly</a></li></ul>";

// htable -----
   ih +="</br></br><table id='htable' ><tr><td><div class='input-group'><span class='input-group-addon'><input type='radio' name='every' id='everyid' ></span><label class='form-control' >Every</label></div></td>";
   ih += "<td>&nbsp;&nbsp;</td>"; 
   ih += "<td><div class='input-group'><input  style='width:150px;float:left;padding-top:2%;' class='form-control' type='text' id='hhour'><span class='input-group-addon'>Hour(s)</span></div></td>";
   ih += "<td>&nbsp;&nbsp;</td>"; 
   ih += "<td><div class='input-group'><span class='input-group-addon'>with Starting OffSet of </span><input  style='width:100px;float:left;padding-top:2%;' class='form-control' type='text' id='everyHourOffset'><span class='input-group-addon'>Minute(s)</span></div></td>";
   ih += "</tr>";     
   ih += "<tr><td colspan ='100%'>&nbsp;</td> </tr>"; 
   ih += "<tr><td><div class='input-group'><span class='input-group-addon'><input type='radio' name='every' checked id='atid' ></span><label class='form-control' >Daily, at</label></div></td>";
   ih += "<td>&nbsp;&nbsp;</td>";
    ih += "<td><div class='input-group clockpicker' data-placement='right' data-align='top' data-autoclose='true' style='width:100px;'><input type='text' class='form-control' value='00:00' id='athour' disabled ><span class='input-group-addon'><span class='glyphicon glyphicon-time'></span></span></div></td></tr>";
   ih += "</table>";  

  // htable --------
  // wtable --------
   ih += "<table id='wtable' style='display :none;'  ><tr>";
   ih += "<td colspan='2'><div class='btn-group' data-toggle='buttons' id='chkWeekly'><label class='btn btn-default'><input type='radio' id='0' />Monday</label><label class='btn btn-default'><input type='radio' id='1' />Tuesday</label><label class='btn btn-default'><input type='radio' id='2' />Wednesday</label><label class='btn btn-default'><input type='radio' id='3' />Thursday</label><label class='btn btn-default'><input type='radio' id='4' />Friday</label><label class='btn btn-default'><input type='radio' id='5' />Saturday</label><label class='btn btn-default'><input type='radio' id='6' />Sunday</label></div></td></tr>";
   ih += "<tr><td colspan ='100%'>&nbsp;</td></tr>";
   ih += "<tr><td colspan=0 style='width:20%'><label style='padding-top:7%;' >Start Time : </label></td>";
   ih += "<td><div class='input-group clockpicker' data-placement='right' data-align='top' data-autoclose='true' style='width:100px;'><input type='text' class='form-control' value='00:00' id='whour' disabled><span class='input-group-addon'><span class='glyphicon glyphicon-time'></span></span></div>";
   ih += "</td></tr>";
   ih += "<table>";
  // wtable --------
  // mtable --------
   ih += "<table id='mtable' style='display:none;' ><tr><td><label style='padding-top:7px;' >&nbsp;Day&nbsp; </label></td><td colspan=2><input  style='width:150px;float:left;padding-top:2%;' class='form-control' type='text' id='mDay' title = '"+monthlyDesc+"'></td><td><label style='padding-top:7%;' >&nbsp;of&nbsp;every&nbsp;</label></td><td><div class='input-group'><input  style='width:150px;float:left;padding-top:2%;' class='form-control' type='text' id='mMonth' title = '"+monthlyDesc+"'><span class='input-group-addon' style='border-radius:4px;' >Month(s)</span><div></td></tr>";
   ih += "<tr style='display:none;' ><td><input type='radio' class='form-control' name='mR' style='width:12px;' ></td><td><label style='padding-top:7px;' >&nbsp;The&nbsp; </label><td><div class='btn-group'><button type='button' id='mNumber' class='btn btn-default dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>First<span class='caret'></span></button><ul class='dropdown-menu'>";
   for(var a =0; a < number.length; a++)
     ih += "<li><a onclick=setNum('mNumber','"+number[a]+"',"+(a+1)+") >"+number[a]+"</a></li>";
   ih += "<ul></div></td><td><div class='btn-group'><button type='button' id='mWeekday' class='btn btn-default dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Monday<span class='caret'></span></button><ul class='dropdown-menu'>";
   for(var a =0; a < day.length; a++)
     ih += "<li><a onclick=setNum('mWeekday','"+day[a]+"',"+(a+1)+") >"+day[a]+"</a></li>";
   ih += "</td><td><label style='padding-top:7%;' >&nbsp;of&nbsp;every&nbsp;</label></td><td><div class='input-group'><input  style='width:150px;float:left;padding-top:2%;' class='form-control' type='text' id='mMonthid'><span class='input-group-addon' style='border-radius:4px;' >Month(s)</span><div></td></tr>";
   ih += "<tr><td colspan ='100%'>&nbsp;</td> </tr>";
   ih +="<tr><td colspan=2 style='width:20%'><label style='padding-top:10%;' >Start Time : </label></td>";
   ih += "<td><div class='input-group clockpicker' data-placement='right' data-align='top' data-autoclose='true' style='width:100px;'><input type='text' class='form-control' value='00:00' id='shour' disabled><span class='input-group-addon'><span class='glyphicon glyphicon-time'></span></span>";
   ih += "</table>"; 
  // mtable -------- 
   ih += "</br><table ><tr><td>Schedule Expiry Date : ";
   ih += "<td>&nbsp;&nbsp;</td>";
   ih += "<td><div class='input-group'  style='width:180px;'><input  style='padding-top:2%;' class='form-control' type='text' id='edate'><span class='input-group-addon'><span class='glyphicon glyphicon-calendar'></span></span></div></td>";
   ih += "<td>&nbsp;&nbsp;</td>";
   ih += "<td><div class='input-group clockpicker' data-placement='right' data-align='top' data-autoclose='true' style='width:100px;'><input disabled type='text' class='form-control' value='00:00' id='ehour' ><span class='input-group-addon'><span class='glyphicon glyphicon-time'></span></span></div></td><td colspan='100%' ><textarea  placeholder='Enter task description' style='margin-left:40%;float:left;padding-top:2%;' class='form-control'  id='comments'></textarea></td></tr></table>";
   document.getElementById('stepbody'+step).innerHTML = ih;
   $('.clockpicker').clockpicker(); 
   $('#edate').datepicker({
          format: "dd/mm/yyyy"
   }); 
}

function setNum(id,value,att)
{
  document.getElementById(id).innerHTML = value;
  document.getElementById(id).setAttribute('num',att);
}

function setValue(e,value)
{
  if(e != "lastDay")
  {
    if(value.indexOf('Week') > -1 || value.indexOf('Month') > -1 || value.indexOf('Year') > -1|| value.indexOf('Day') > -1)
    {
      document.getElementById('ltime').style.visibility = "visible";
      document.getElementById('ltime1').style.visibility = "visible";
      if(value.indexOf('Week') > -1)
      {
        document.getElementById('lday').style.visibility = "visible";
        document.getElementById('lday1').style.visibility = "visible";
      }
      else
      {
        document.getElementById('lday').style.visibility = "hidden";
        document.getElementById('lday1').style.visibility = "hidden";
      }
    }
    else
    {
      document.getElementById('ltime').style.visibility = "hidden";
      document.getElementById('ltime1').style.visibility = "hidden";
      document.getElementById('lday').style.visibility = "hidden";
      document.getElementById('lday1').style.visibility = "hidden";
    }
  }
  document.getElementById(e).innerHTML = value.replace('$',' ');
}

// method to prompt for task selection
function promptTask()
{
  var pr = document.getElementById("parent"); // container for wizard
  var tsk = createE('DIV',[['class','alert alert-info tasks'],['role','alert'],['id','task']],'');
  tsk.appendChild(createE('H2',[['class','icon']],'Please select the task'));
  for(var a = 0; a < list.length; a++)
  {
	  var icon = createE('A',[['class','btn btn-success icon'],['id','icon'+a],['onclick',"createSteps('"+a+"')"]],'');
	  icon.innerHTML = "<img src='../images/"+list[a].icon+"' width='50px' height='50px'></br>"+list[a].taskName.toUpperCase();
	  tsk.appendChild(icon);
  }
  var icon = createE('A',[['class','btn btn-success icon'],['href',"taskList.jsp?product="+productType]],'');
  icon.innerHTML = "<img src='../images/homeredirect.png' width='30px' height='30px'></br>RETURN";
  tsk.appendChild(icon);
  pr.appendChild(tsk);
}

// method for handling click of navs
function navAction(index)
{
  //go to home
 if(index == -1)
 {
   if(productType == "NVSM" || productType == "NDE" || productType == "NS" || productType == "NC")
     window.location = "taskList.jsp?product="+productType;
   else
   {
     document.getElementById('wizard').style.display = "none";
     document.getElementById('task').style.display = "block";  // hiding prompt div.
   }
  }
  else
  {
    var steps = document.getElementsByName('step');
    var navs = document.getElementsByName('navs');
    if(navs[index].getAttribute('active') == 'false' && index != 0) return;
    for(var a = 0; a < steps.length; a++)
    {
       steps[a].style.zIndex = 1;
       navs[a].removeAttribute('class');
       if(navs[a].getAttribute('active') == 'true')
         navs[a].setAttribute('class','btn btn-primary nav');
       else
         navs[a].setAttribute('class','btn btn-default nav');
    }  
    document.getElementById('step' + index).style.zIndex = 2;
    document.getElementById('nav' + index).removeAttribute("class");
    document.getElementById('nav' + index).setAttribute("class","btn btn-info nav");
    if(index == 0)
      document.getElementById('prev').style.visibility = "hidden";
    else
      document.getElementById('prev').style.visibility = "visible";
  }
  setPrevNext(index);
}

// used to make initial adjustments to wizard.
function initialAdjustment()
{
  navAction(0);
}

function setPrevNext(index)
{
   var prev = document.getElementById('prev');
   var next = document.getElementById('next');
   prev.removeAttribute('onclick');
   next.removeAttribute('onclick');
   prev.setAttribute('onclick','goBackward('+(index-1)+')');
   if(index < currentTask.steps-1)
   {
     next.setAttribute('onclick','goForward('+(index+1)+')');
     next.innerHTML = 'Next';
   }
   else
   {
     next.setAttribute('onclick','save()');
     next.innerHTML = 'Finish';
   }
}

function goBackward(index)
{
  var steps = document.getElementsByName('step');
  if(index <0)
    return;
  if(index >= 0)
  {
    navAction(index);
  }
}

function goForward(index)
{ 
  if(currentTask.stepInfo[index].next)
  {
    for(var a = 0; a < currentTask.stepInfo[index].next.length; a++)
    {
      if(!eval(currentTask.stepInfo[index].next[a])) return;
    }
  }
  var steps = document.getElementsByName('step');
  var navs = document.getElementsByName('navs');
  if(index >= steps.length)
    return;
  if(index < steps.length)
  {
    navs[index].removeAttribute('active');
    navs[index].setAttribute('active','true');
    if(index == 1)
    {
      navs[index-1].removeAttribute('active');
      navs[index-1].setAttribute('active','true');
    }
    navAction(index); 
  }
}


// used to initialize the wizard
function initWizard(productTypeLocal)
{
    productType = productTypeLocal;
    promptTask();
    
    if(updateTask != undefined || updateTask != null) // for updating task.
    {
      for(var k = 0; k < list.length; k++)
      {
       if(list[k].taskName == updateTask.split("|")[2])
         createSteps(k);
      }    
    }

  //skipping task available task in case of NVSM.
  //directly we are opening step first (Step 1)
    if(productType == "NVSM" || productType == "NDE" || productType == "NS" || productType == "NC")
      createSteps(0);

}

// show alerts!
function showAlert(msg)
{
  document.getElementById('errMsg').innerHTML = msg;
  $('.alert-dismissible').fadeIn();
  $('.alert-dismissible').fadeOut(5000);
}

//validation
function setScheduleValue()
{
//for hourly
 if($('#occurence')[0].children[0].getAttribute('class') == 'active')
  {
   if($('#everyid')[0].checked)
    {
     if($('#hhour')[0].value == "")//if blank
     {
       showAlert("Please Enter the number of hours.");
       return false;
     }
     else if(isNaN($('#hhour')[0].value) ) //if not a number
     {
       showAlert("Please Enter valid number of hours.");
       return false;
     }
	 
	 if($('#everyHourOffset')[0].value == "")//if blank
     {
       showAlert("Please Enter the number of minutes.");
       return false;
     }
	 else if(isNaN(parseInt($('#everyHourOffset')[0].value) )) //if not a number
     {
       showAlert("Please Enter valid number of minutes.");
       return false;
     }
	 else if(parseInt($('#everyHourOffset')[0].value) > 59) //if minute is greater than 59
     {
       showAlert("Please Enter valid number of minutes.");
       return false;
     }
    }
  }
  else if($('#occurence')[0].children[2].getAttribute('class') == 'active') 
   {
     //if($('#dayid')[0].checked)
      //{
       if($('#mDay')[0].value == "")
        {
         showAlert("Please Enter the day number.");
         return false;
        }
       if($('#mMonth').value = "")
        {
         showAlert("Please Enter the month number.");
         return false;
        }
       /*}
     else
      {
        if($('#mMonthid').value = "")
        {
         showAlert("Please Enter the month number.");
         return false;
        }

      }*/
   }

  //for schedule expiry
   var a = new RegExp(/^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/);
   if(!a.test($('#edate')[0].value) && $('#edate')[0].value != "")
   {
     showAlert("Please Enter valid date");
     return false;
   }
   if($('#edate')[0].value != "")
     sch.expiryTime = $('#edate')[0].value +" "+ $('#ehour')[0].value+":00";
   else
     sch.expiryTime = "0";

  // for comments
  sch.comments = encodeURI($('#comments')[0].value.split("'").join("\'"));
    if(createCron())  
      return true;
    else
      return false; 
  }
  
sch = {};
// create cron string 
function createCron()
{
   var cronFormat = "";
   var sDateFormat = "";

   
   //for hourly scheduling
   try {
   if($('#occurence')[0].children[0].getAttribute('class') == 'active')
   {
     //checking for standard or custom hours n mins.
     if($('#everyid')[0].checked)
      {
        //cronFormat = "* * /"+$('#hhour')[0].value+" * * *";
        cronFormat = parseInt($('#everyHourOffset')[0].value)+" */"+$('#hhour')[0].value+" * * *";
        sDateFormat = "Hourly, Every "+$('#hhour')[0].value+" Hour(s) with Starting OffSet of "+$('#everyHourOffset')[0].value+" Minute(s)";
      }
     else
      {
        var time = $('#athour')[0].value.split(":");
        cronFormat = "0 "+parseInt(time[1])+" "+parseInt(time[0])+" * * *";
        sDateFormat = "Daily, at "+time[0]+":"+time[1]+"";
      }
   }
   else if($('#occurence')[0].children[1].getAttribute('class') == 'active')
   {
     var days = -1;
     var sdays = -1;
     var daysChecked = document.getElementById("chkWeekly").children;
     var n = 0;
     for(var a = 0; a < daysChecked.length; a++)     
     {
         if(daysChecked[a].getAttribute('class').indexOf('active') > -1)
         {
           n++;
           if(DAYS[a] == 'MON')
            days = 1;
           if(DAYS[a] == 'TUE')
            days = 2;
           if(DAYS[a] == 'WED')
            days = 3;
           if(DAYS[a] == 'THU')
            days = 4;
           if(DAYS[a] == 'FRI')
            days = 5;
           if(DAYS[a] == 'SAT')
            days = 6;
           if(DAYS[a] == 'SUN')
            days = 0;
           if(days != -1)
             sdays = a;
          // days += ((days == ") ? days : ("-" + days));
         }
     }
     if(n == 0)
     {
         showAlert("Select days of the week");
         return false;
     }
      var time = $('#whour')[0].value.split(":");
      cronFormat = "0 "+parseInt(time[1])+" "+parseInt(time[0])+" * * "+days;
      sDateFormat = "Weekly, "+DAYS[sdays]+" at "+time[0]+":"+time[1];
   }
   else
   {
      //var type = document.getElementsByName("mR"); 
      var time = $('#shour')[0].value.split(":");
      //if(type[0].checked)
      //{
         if(document.getElementById('mMonth').value == "")
         {
           showAlert("Enter number of months");
           return false;
         }
         cronFormat = document.getElementById("mDay").value+" */"+document.getElementById("mMonth").value+" *";
         sDateFormat = "Monthly, On day " + document.getElementById("mDay").value + " every " + document.getElementById("mMonth").value + " month(s)";
      /*}
      else
      {
         if(document.getElementById('mMonthid').value == "")
         {
           showAlert("Enter number of months");
           return false;
         }
         cronFormat = " 1/" +document.getElementById("mNumber").getAttribute('num')+" "+DAYS[parseInt(document.getElementById("mWeekday").getAttribute('num'))-1]+"#"+document.getElementById("mMonthid").value+" *";
         sDateFormat = "Monthly, " + document.getElementById("mNumber").innerHTML.split("<")[0] + " " + document.getElementById("mWeekday").innerHTML.split("<")[0] + " every " + document.getElementById("mMonthid").value + " month(s)";
      }*/
      // adding time in the format.
      cronFormat = "0 "+parseInt(time[1])+" "+parseInt(time[0]) +" "+ cronFormat;
      sDateFormat += " At " + $('#shour')[0].value;
   }
  }
   catch(e)
   {
      console.log(e);
      console.log(e.stack);
      showAlert("Error in creating cron");
      return false;
   }
   sch.cron = cronFormat;
   sch.sCron = sDateFormat;
   return true;
}

function save()
{
  var taskName = currentTask.taskName;
  if(productType == "NVSM" || productType == "NDE" || productType == "NS" || productType == "NC")
  {
    taskName = scheduleObj.reportType;
  }
 // var taskName = scheduleObj.reportType;
  scheduleObj.taskObj = { "cron" : sch.cron, "task" : taskName, "expiryTime" : sch.expiryTime, "sCron" : sch.sCron, "comments" : sch.comments};
  if(updateTask == undefined || updateTask == null)
    scheduleObj.taskid = -1;
  else
    scheduleObj.taskid = updateTask.split("|")[0]; // picking task id for updating.
  submitJSP("addTask",JSON.stringify(scheduleObj).split("'").join("\'\'"));
  
}



function setMail(step)
{
  var ih = '<div class="well well-lg" style="float:right;width:25%;height:80%;margin-right:5%;padding-top:0px;"><center><h4><label class="label label-primary">Hints...</label></h4></center><h4><label><input type= "button" class="btn btn-default" style="cursor:text;" value="ReportName = $reportname" onclick="pasteSelected(this);"></input></label></h4> <h4><label><input type="button" style="cursor:text;" class="btn btn-default" value="EndDate = $eddate" onclick="pasteSelected(this);"></input></label></h4> <h4><label><input type="button" style="cursor:text;" class="btn btn-default" value="StartDate = $sddate" onclick="pasteSelected(this);"></input></label></h4></div><div class="input-group" style="width:50%;" ><span class="input-group-addon" id="basic-addon3">Subject </span><input type="text" placeholder="Enter mail subject." class="form-control" id="subjectid" aria-describedby="basic-addon3"></div></div><div class="input-group" style="width:50%;margin-top:2%;" ><span class="input-group-addon" id="basic-addon3">To </span><input type="text" placeholder="Enter recipients." class="form-control" id="emailtoid" aria-describedby="basic-addon3"></div></br><font style="color:grey;font-size:12px;" >Add more than one recipient separated by (;). abc@gmail.com;xyz@gmail.com.... </font><div class="input-group" style="width:50%;margin-top:2%;" ><span class="input-group-addon" >Body </span><textarea  placeholder="Enter message." class="form-control" id="bodyid" aria-describedby="basic-addon3"></textarea></div>';
   document.getElementById('stepbody'+step).innerHTML = ih;  
}
function pasteSelected(obj)
{
  var selectedValue = obj.value;
  var temp = $("#bodyid").val();
  $("#bodyid").val(temp + selectedValue);
  $("#bodyid").focus();
}

function selectReport(id)
{
  document.getElementById('report').innerHTML = jsonData['standard'][id].name;
  document.getElementById('report').setAttribute('reportid',id);
}

function reportTimeRange(step)
{
  var ih = "<table><tr><td><span class='span span-default'>Report Type </span></td><td>&nbsp;<div class='btn-group' data-toggle='buttons'><label  class='btn btn-default active' onclick=setListValues('standard')><input type='radio' name='rType' checked />Standard</label><label id='rTO' class='btn btn-default' onclick=setListValues('custom')><input type='radio' name='rType' />Custom</label><label id='rTO' class='btn btn-default' onclick=setListValues('template')><input type='radio' name='rType' />Template</label></div></td></tr><tr><td colspan='100%'>&nbsp;</td></tr><tr><td><span class='span span-default'>Report </span></td><td><div class='dropdown'><button class='btn btn-default dropdown-toggle' type='button' id='report' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Select Report<span class='caret'></span></button><ul id='reportList' class='dropdown-menu' aria-labelledby='dropdownMenu1'>";
   for(var a = 0; a < reportGroups.length; a++)
   {
     ih += "<li class='dropdown-header'>"+reportGroups[a]+"</li>";
     for(var b = 0;b < jsonData['standard'].length; b++ )
     {
        if(jsonData['standard'][b].group == reportGroups[a])
          ih += "<li onclick = selectReport("+b+");  style='cursor:pointer;' ><a>"+jsonData['standard'][b].name+'</a></li>';
     }
   }
   ih += "</ul></div></td></tr><tr><td colspan='100%'>&nbsp;</td></tr>"; 
   ih += "<tr><td><span class='span span-default'>Report Format </span></td><td>&nbsp;<div class='btn-group' data-toggle='buttons'><label class='btn btn-default active'><input type='radio' name='rFormat' checked />XLS</label></div></td></tr></table>";
   document.getElementById('stepbody'+step).innerHTML = ih;
}

function selectTemplateReport(id)
{
  document.getElementById('report').innerHTML = jsonData['templatedatamodel'][id].name;
  document.getElementById('report').setAttribute('reportid',id);
}

function selectCustomReport(id)
{
  document.getElementById('report').innerHTML = jsonData['custom'][id].name;
  document.getElementById('report').setAttribute('reportid',id);
}

function setListValues(type)
{
 document.getElementById("report").innerHTML="Select Report<span class='caret'></span>";
  var ih = "";
  if(type == "template")
  {
    for(var a = 0; a < templateGroups.length; a++)
    {
      ih += "<li class='dropdown-header'>"+templateGroups[a]+"</li>";
      for(var b = 0;b < jsonData['templatedatamodel'].length; b++)
      {
        if(jsonData['templatedatamodel'][b].group == templateGroups[a])
          ih += "<li onclick = selectTemplateReport("+b+");  style='cursor:pointer;' ><a>"+jsonData['templatedatamodel'][b].name+'</a></li>';
      }
    }
  }
  else if(type == "custom")
  {
  }
  else
  {
    for(var a = 0; a < reportGroups.length; a++)
    {
     ih += "<li class='dropdown-header'>"+reportGroups[a]+"</li>";
     for(var b = 0;b < jsonData['standard'].length; b++ )
     {
        if(jsonData['standard'][b].group == reportGroups[a])
          ih += "<li onclick = selectReport("+b+");  style='cursor:pointer;' ><a>"+jsonData['standard'][b].name+'</a></li>';
     }
    }
  }
  document.getElementById('reportList').innerHTML = ih;
}

function enableDisableTimeOption()
{
  var timeType = document.getElementsByName("timeType");
  if(timeType[0].checked)
  {
    document.getElementById("sdate1").disabled = true;
    document.getElementById("edate1").disabled = true;
  }
  else
  {
    document.getElementById("sdate1").disabled = false;
    document.getElementById("edate1").disabled = false;
  }
  if(timeType[1].checked)
   document.getElementById("lastTime").disabled = true;
  else
   document.getElementById("lastTime").disabled = false;


}


function reportDataRange(step)
{
  var ih = "";
  ih += "<table><tr><td><input type='radio' name='timeType' checked onclick=enableDisableTimeOption() />&nbsp; &nbsp; Last &nbsp; &nbsp;</td><td><div class='dropdown'><button class='btn btn-default dropdown-toggle' type='button' id='lastTime' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Select time<span class='caret'></span></button><ul id='lastList' class='dropdown-menu' aria-labelledby='dropdownMenu1'><li   style='cursor:pointer;' onclick=setValue('lastTime','15$Minutes')><a>15 Minutes</a></li><li   style='cursor:pointer;'  onclick=setValue('lastTime','1$Hour')><a>1 Hour</a></li><li   style='cursor:pointer;'  onclick=setValue('lastTime','4$Hours')><a>4 Hours</a></li><li  onclick=setValue('lastTime','8$Hours')  style='cursor:pointer;' ><a>8 Hours</a></li><li   onclick=setValue('lastTime','12$Hours') style='cursor:pointer;' ><a>12 Hours</a></li><li    onclick=setValue('lastTime','16$Hours') style='cursor:pointer;' ><a>16 Hours</a></li><li   style='cursor:pointer;'  onclick=setValue('lastTime','20$Hours') ><a>20 Hours</a></li><li    onclick=setValue('lastTime','1$Day') style='cursor:pointer;' ><a>1 Day</a></li><li  onclick=setValue('lastTime','1$Week')  style='cursor:pointer;' ><a>1 Week</a></li><li  onclick=setValue('lastTime','1$Month')  style='cursor:pointer;' ><a>1 Month</a></li><li  onclick=setValue('lastTime','1$Year')  style='cursor:pointer;' ><a>1 Year</a></li></ul></div></td></tr><tr><td colspan='100%'>&nbsp;</td></tr><tr><td style='visibility:hidden' id='lday'><div class='input-group'><span class='input-group-addon'><input type='checkbox' name='selDay'  ></span><label class='form-control' >Select Day</label></div></td><td style='visibility:hidden' id='lday1' ><div class='dropdown'><button class='btn btn-default dropdown-toggle' type='button' id='lastDay' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Select<span class='caret'></span></button><ul id='dayList' class='dropdown-menu' aria-labelledby='dropdownMenu1'>";
  for(var a = 0; a < DAYS.length; a++)
    ih += "<li style='cursor:pointer;' onclick=setValue('lastDay','"+DAYS[a]+"') ><a>"+DAYS[a]+"</a></li>";
  ih += "</ul></div></td><td style='visibility:hidden' id='ltime' ><div class='input-group'><span class='input-group-addon'><input type='checkbox' id='selTime'  ></span><label class='form-control' >Select Time</label></div></td><td style='visibility:hidden' id='ltime1' ><div class='input-group clockpicker' data-placement='right' data-align='top' data-autoclose='true' style='width:100px;'><input type='text' class='form-control' value='00:00' id='selTimeVal' disabled ><span class='input-group-addon'><span class='glyphicon glyphicon-time'></span></span></div></td></tr><tr><td colspan='100%'>&nbsp;</td></tr>" ;
   ih += "<tr><td><input type='radio' name='timeType'  onclick=enableDisableTimeOption() />&nbsp; &nbsp; Start Time :</td>";
   ih += "<td><div class='input-group'  style='width:180px;'><input  style='padding-top:2%;' class='form-control' type='text' id='sdate1' disabled><span class='input-group-addon'><span class='glyphicon glyphicon-calendar'></span></span></div></td>";
   ih += "<td><div class='input-group clockpicker' data-placement='right' data-align='top' data-autoclose='true' style='width:100px;'><input disabled type='text' class='form-control' value='00:00' id='shour' ><span class='input-group-addon'><span class='glyphicon glyphicon-time'></span></span></div></td>";
  ih += "<td>&nbsp; &nbsp; End Time : </td>";
   ih += "<td><div class='input-group'  style='width:180px;'><input  style='padding-top:2%;' class='form-control' type='text' id='edate1' disabled><span class='input-group-addon'><span class='glyphicon glyphicon-calendar'></span></span></div></td>";
   ih += "<td>&nbsp;&nbsp;</td>";
   ih += "<td><div class='input-group clockpicker' data-placement='right' data-align='top' data-autoclose='true' style='width:100px;'><input disabled type='text' class='form-control' value='00:00' id='ehour1' ><span class='input-group-addon'><span class='glyphicon glyphicon-time'></span></span></div></td></tr><tr><td colspan='100%'>&nbsp;</td></tr>";
   ih += "<tr><td>Bucket Mode :</td><td><div class='dropdown'><button class='btn btn-default dropdown-toggle' type='button' id='bucketid' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Select Bucket<span class='caret'></span></button><ul id='bucketList' class='dropdown-menu' aria-labelledby='dropdownMenu1'><li onclick=setNum('bucketid','Hourly',1) ><a>Hourly</a></li><li onclick=setNum('bucketid','Daily',2)><a>Daily</a></li><li onclick=setNum('bucketid','Weekly',3)><a>Weekly</a></li><li onclick=setNum('bucketid','Monthly',4)><a>Monthly</a></li><li onclick=setNum('bucketid','Yearly',5)><a>Yearly</a></li></ul></div></td></tr>";/*<td>Channel :</td><td><div class='dropdown' style='display:none;' ><button class='btn btn-default dropdown-toggle' type='button' id='channel' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>All<span class='caret'></span></button><ul class='dropdown-menu' aria-labelledby='dropdownMenu1'><li><a>All</a></li><li><a>Dotcom</a></li><li><a>Mobile</a></li><li><a>Others</a></li></ul></div></td></tr>";*/

   ih += "</td></tr>"; 
  document.getElementById('stepbody'+step).innerHTML = ih;
  $('#sdate1').datepicker({
          format: "dd/mm/yyyy",
          autoclose: true
   });
  $('#edate1').datepicker({
          format: "dd/mm/yyyy",
          autoclose: true
   });
}

function setReport()
{
 //if report is not selected.
 if($('#report').html().indexOf('span') > -1)
 {
  showAlert("Select a report");
  return false; 
 }
 else
 {
   if($('[name="rType"]')[0].checked)
     scheduleObj.crqObj = jsonData.standard[document.getElementById('report').getAttribute('reportid')];
   else if($('[name="rType"]')[2].checked)
   {
     scheduleObj.crqObj = { "name" : jsonData.templatedatamodel[document.getElementById('report').getAttribute('reportid')].name };
   }
 } 
 //checking type 
 if($('[name="rType"]')[0].checked)
  scheduleObj.reportType = "Standard";
 else if($('[name="rType"]')[1].checked)
   scheduleObj.reportType = "Custom";  
 else
  scheduleObj.reportType = "Template";
 //checking format 
 if($('[name="rFormat"]')[0].checked)
  scheduleObj.format = "XLS";
 else
  scheduleObj.format = "PDF";
 return true;
}


function setDataTime()
{
 var startTime = "";
 var endTime = "";
 var a = new Date();
 //if last option selected
 if(document.getElementsByName('timeType')[0].checked)
 {
  if($('#lastTime').html().indexOf('<') > -1)
  {
     showAlert("Select last time.");
     return false;
  }
  var day = "";
  var time = "";
  if(document.getElementsByName('selDay')[0].checked)
  {
    if(document.getElementById('lastDay').innerHTML.indexOf("<") > -1)
    {
      showAlert("Select Day");
      return false;

    }
    day = document.getElementById('lastDay').innerHTML;
    
  }
  else
  {
    var d = new Date();
    var weekday = new Array(7);
    weekday[0] = "Sunday";
    weekday[1] = "Monday";
    weekday[2] = "Tuesday";
    weekday[3] = "Wednesday";
    weekday[4] = "Thursday";
    weekday[5] = "Friday";
    weekday[6] = "Saturday";

    day = DAYS1[d.getDay()];
     }
  if(document.getElementById('selTime').checked)
  {
    time = $('#selTimeVal')[0].value;
  }
  else
  {
    var d = new Date();
    time = d.getHours()+":"+d.getMinutes();
  }
  
  startTime = $('#lastTime').html().split("<")[0]+"$$"+day +"$$"+time;
  endTime =  0;
 }
 else
 {
  //if we leave blank.
  if($('#sdate1').val() == "" || $('#edate1').val()== "")
  {
   showAlert("Please Enter Date");
   return false;
  }
  startTime = $('#sdate1').val() +" "+$('#shour').val()+":00";
  endTime  = $('#edate1').val() +" "+$('#ehour1').val()+":00";
 }
 scheduleObj.dataTime = startTime +"&"+ endTime;
 if(document.getElementById('bucketid').innerHTML.indexOf('<') > -1)
 {
   showAlert("Select Bucket");
   return false;
 }
 scheduleObj.bucket = document.getElementById('bucketid').getAttribute('num');
 return true;
} 

function getMail()
{
 // not keeping mailing informations mandatory.
 if(scheduleObj.hasOwnProperty("reportType") && ($('#subjectid').val() == "" || $('#emailtoid').val() == "" ))
 {
  showAlert("For reports mailing information is mandatory");
  return false;
 }
 if($('#emailtoid').value != "") // if recipient(s)  entered.
 {
   if(!validateMultipleEmailsCommaSeparated($('#emailtoid'),';'))  return false;
 }
 scheduleObj.mail = { "subject" : $('#subjectid').val(), "to" : $('#emailtoid').val(), "body" : $('#bodyid').val()};

 if(productType == "NVSM" || productType == "NDE" || productType == "NS" || productType == "NC")
   viewReportScheduleSummary(); 
 else
   setReportSummary();
  
 return true;  
}

//function for email validation
function validateEmail(field)
{
  var regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;
  return (regex.test(field)) ? true : false;
}
function validateMultipleEmailsCommaSeparated(emailcntl, seperator)
{
  var value = emailcntl.val();
  if (value != '')
  {
    var result = value.split(seperator);
    for(var i = 0; i < result.length; i++) 
    {
     if (result[i] != '') 
     {
      if (!validateEmail(result[i])) 
      {
        emailcntl.focus();
        showAlert('Please check, `' + result[i] + '` email addresses not valid!');
        return false;
       }
      }
     }
    }
    return true;
}
                                                                                                                    
function showReportSummary(step)
{
  var ih = '<div class="well well-lg" style="width:100%;height:100%;padding-top:10px;overflow:auto;" id="summary" ></div>';
  document.getElementById('stepbody' + step).innerHTML = ih; 
}

function setReportSummary()
{
  var ih = "<label class='btn btn-default'><b>Report Name : </b>" +scheduleObj.crqObj.name+ "</label>";
  ih += "<label class='btn btn-default' style='margin-left:4px;' ><b>Report Type : </b>" +scheduleObj.reportType+ "</label>";
  ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Report Format : </b>" +scheduleObj.format+ "</label></br></br>";
  if(scheduleObj.dataTime.split('&')[1] == "0")
  {
    ih += "<label class='btn btn-default'><b>Report Duration : </b>Last " +scheduleObj.dataTime.split('&')[0].split('$$').join(" ")+ "</label>";
  }
  else
  {
    ih += "<label class='btn btn-default'><b>Report Start Time : </b>" +scheduleObj.dataTime.split('&')[0]+ "</label>";
    ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Report End Time : </b>" +scheduleObj.dataTime.split('&')[1]+ "</label>";
  }
  ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Schedule Expiry Time : </b>" +((sch.expiryTime == "0") ? "Not Set" : sch.expiryTime) + "</label></br></br>";
  ih += "<label class='btn btn-default'><b>Mail Subject : </b>" +((scheduleObj.mail.subject == "") ? " Not specified" : scheduleObj.mail.subject) + "</label></br></br>";
  ih += "<label class='btn btn-default'><b>Mail To : </b>" +((scheduleObj.mail.to == "") ? " Not specified" : scheduleObj.mail.to) + "</label></br></br>";
  ih += "<label class='btn btn-default'><b>Mail Body : </b>" +((scheduleObj.mail.body == "") ? " Not specified" : scheduleObj.mail.body)+ "</label>";
  document.getElementById('summary').innerHTML = ih;
}

function setTaskSummary()
{
  var ih = "<label class='btn btn-default'><b>Task : </b>Resource Sync</label></br></br>";
  ih += "<label class='btn btn-default' style='margin-left:4px;' ><b>Mode : </b>Pull</label></br></br>";
  ih += "<label class='btn btn-default' style='margin-left:4px;' ><b>Schedule Time : </b>"+sch.sCron+"</label></br></br>";
  ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Schedule Expiry Time : </b>" +((sch.expiryTime == "0") ? "Not Set" : sch.expiryTime) + "</label></br></br>";  
  document.getElementById('summary').innerHTML = ih; 
  return true;

}

function showFilters(step)
{
   var ih = "No filters available";
   
   document.getElementById('stepbody'+step).innerHTML = ih;

}

function appendZeroIfRequired(element)
{
    var temp = String(element);
    temp = temp.length > 1 ? temp : '0' + temp;
    return temp;
}

// for setting values in case modification of any task.
function setPreviousValues()
{
   console.log("setPreviousValues method called");
   if(updateTask == undefined || updateTask == null) return;
   var info = updateTask.split("|");
   // expiry date time
   if(parseInt(info[3]) > 0)
   {
	   //This code is for bug id 49981
      //var a = new Date(parseInt(info[3]));	 	  
      var a = info[3].split(" ")[0];
      var month = a.split("\/")[1];
      var day = a.split("\/")[0];
      var year = a.split("\/")[2];
      var date = appendZeroIfRequired(day) + "/" +appendZeroIfRequired(month) + "/" +  year;
      
      document.getElementById("edate").value = date;
      $("#edate").datepicker("remove");
      $('#edate').datepicker({
          format: "dd/mm/yyyy"
      });
	  
	  var time =  info[3].split(" ")[1].split(":");
      document.getElementById("ehour").value = time[0] + ":" + time[1]
	  //This code is for bug id 49981
     // if(a.toLocaleTimeString().indexOf("AM") > -1 && a.toLocaleTimeString().split(":")[0] == "12")
      // document.getElementById("ehour").value = "00:" + a.toLocaleTimeString().split(":")[1]
     // else
     //  document.getElementById("ehour").value = a.toLocaleTimeString().split(":")[0] + ":" + a.toLocaleTimeString().split(":")[1]
   }
   // occurence
   if(info[4].indexOf("Weekly") > -1)
   {  
     showFrequency(1);
     for(var x = 0; x < DAYS.length; x++)
     {
       if(DAYS[x] == info[4].split(",")[1].trim().substring(0,3))
         document.getElementById('chkWeekly').children[x].setAttribute("class","btn btn-default active");
     }
     document.getElementById('whour').value = info[4].split("at")[1].trim(); 
   }
   else if(info[4].indexOf("Hourly") > -1 || info[4].indexOf("Daily") > -1)
   {
     showFrequency(0);
     if(info[4].indexOf("Every") > -1)
     {
       document.getElementById("everyid").checked = true;
       document.getElementById("hhour").value = parseInt(info[4].split("Every")[1]);
	   var offSet = parseInt(info[4].split(" ")[8]);
	   if(isNaN(offSet))
	   {
		   console.log("Starting offset is not a number "+offSet);
		   offSet = 0;
	   }
	   document.getElementById("everyHourOffset").value = offSet;
     }
     else
     {
       document.getElementById("atid").checked = true;
       var temp = info[4].toLowerCase();
       document.getElementById("athour").value = temp.split("at")[1].trim();
     }
   }
   else
   {
     showFrequency(2);
     document.getElementById('mDay').value = parseInt(info[4].split('day')[1]);    
     document.getElementById('mMonth').value = parseInt(info[4].split('every')[1]);
     document.getElementById('shour').value = info[4].toLowerCase().split('at')[1].trim(); 
   }
   // task description
   document.getElementById("comments").value = decodeURI(info[7]);
  
   // if the task is  of report type filling other informations as well.
   if(updateReport == undefined || updateReport == null) return;
      
   // filling first step   
   var rInfo = updateReport.split("|");
   var mailInfo = JSON.parse(rInfo[5]);
   var crq = JSON.parse(rInfo[6]);

   var reportType = info[2];
   if(reportType == "Excel Report" || reportType == "Html Report" || reportType == "Word Report" || reportType.indexOf("Alert") > -1)
   {
     setPrevValueForAllReports(rInfo,reportType);
   }
   else
   {
     if(rInfo[2] == "Standard") // report type
       $('[name="rType"]')[0].click();
     else if(rInfo[2] == "Custom")
       $('[name="rType"]')[1].click();
     else
       $('[name="rType"]')[2].click();
     if(rInfo[3] != "XLS") // report format
        $('[name="rFormat"]')[1].click();
     for(var a = 0; a < $("#reportList")[0].children.length; a++) // report 
     {
      // if group labels then skip
      if($("#reportList")[0].children[a].children[0] == undefined || $("#reportList")[0].children[a].children[0] == null) continue;
      if($("#reportList")[0].children[a].children[0].innerHTML == crq.name)
        $("#reportList")[0].children[a].children[0].click();
     }        
  
     // DO : handle for filters later.
     // filling third step
    if(rInfo[4].split("&")[1] == 0) // if last time has been choosen
     {
       $('[name="timeType"]')[0].click();
       var tmp = rInfo[4].split("&")[0].split("$$");
       for(var a = 0; a < $("#lastList")[0].children.length; a++) // report 
       {
         if($("#lastList")[0].children[a].children[0].innerHTML == tmp[0] )
           $("#lastList")[0].children[a].children[0].click();
       }  
       var tmp1 = rInfo[4].toLowerCase();
       if(tmp1.indexOf("week") > -1) // for week setting day option.
       {
          document.getElementsByName("selDay")[0].checked = true;
          setValue("lastDay",tmp[1]);
          
       }
       if(tmp1.indexOf("month") > -1 || tmp1.indexOf("day") > -1 || tmp1.indexOf("week") > -1) // for month, week or day setting time option.  
       {
          document.getElementById("selTime").checked = true;
          document.getElementById("selTimeVal").value = tmp[2];
       }
     }
     else
     {
        $('[name="timeType"]')[1].click();
        // start time
       document.getElementById("sdate1").value = rInfo[4].split("&")[0].split(" ")[0];
       document.getElementById("shour").value = rInfo[4].split("&")[0].split(" ")[1];

       // end time
       document.getElementById("edate1").value = rInfo[4].split("&")[1].split(" ")[0];
       document.getElementById("ehour1").value = rInfo[4].split("&")[1].split(" ")[1];
     } 

     // buckets with id's
     var buckets = { "1" : "Hourly", "2" : "Daily", "3" : "Weekly", "4" : "Monthly", "5" : "Yearly" }    
  
     // selecting bucket
     for(var a = 0; a < $("#bucketList")[0].children.length; a++) // report 
     {
        // if group labels then skip
        if($("#bucketList")[0].children[a].children[0].innerHTML == buckets[rInfo[7]])
        $("#bucketList")[0].children[a].children[0].click();
     }
   }
   
   // filling step 5
   $("#subjectid")[0].value = mailInfo.subject;
   $("#emailtoid")[0].value = mailInfo.to;
   $("#bodyid").html(mailInfo.body);    

}
