/*
  Name : scheduleTasks.js
  Purpose : To initialize/ reinitialize  scheduling processes.
  Author : Tuhin Das
*/



// checking for modules if not available then install 

// list of modules required add new modules here in order to install if not present in the machine.
/*var modules = [
   "node-schedule",
   "pg",
   "fs",
   "nodemailer",
   "nodemailer-smtp-transport",
   "http",
   "msexcel-builder-colorfix",
];


function installModules()
{
   var exec = require('child_process').exec;
   for(var a = 0; a < modules.length; a++)
   {
      try
      { 
        // checking for module if exist or not.
        require(modules[a]);
      }
      catch(e)
      {
        // if module not found then install it
       exec("npm install " + modules[a], function(error, stdout, stderr) 
       {
         if(error)
         {
           log.schedulerLog("Failed to install " + modules[a]);
            return true;
         }
         else
           log.schedulerLog("Installed " + modules[a])
       }  
      }
   }
   return true;
}

*/

// On init() we schedule all the tasks present in table irrespective of their status scheduled or not. Assuming scheduler is initialized. But later only tasks having status not scheduled will be added in the scheduler. 

var fs = require('fs');
var configFilePath = __dirname + '/../../sys/NODEJS_INSTRUMENT';
var log = require('./executeReport.js');
var schedule = require('node-schedule');
var data = require('./taskCron.js');

try {
  //Checking if Instrument file exist.
  console.warn('configFilePath', configFilePath);
  if (fs.existsSync(configFilePath)) {
     var prefix_path = __dirname;
     console.warn("Downloading Latest Dependency of npmlog and netjsagent. npmlog is internal dependency of netjsagent. Path = " + prefix_path);
     var exec = require('child_process').exec, child;

     child = exec('npm  --prefix ' + prefix_path + ' install npmlog',
     function (error, stdout, stderr) {
       console.warn('stdout: ', stdout);
       console.warn('stderr: ' , stderr);
       if (error !== null) {
         console.error('Error in downloading dependency npmlog. Error -> ', error);
       } else { 
         console.warn("npm log downloaded successfully. Now checking for netjsagent.");
         child = exec('npm --prefix ' + prefix_path + ' install netjsagent', function (error, stdout, stderr) {
         console.warn('stdout: ', stdout);
         console.warn('stderr: ' , stderr);
         if (error !== null) {
           console.error('Error in downloading dependency netjsagent. Error -> ', error);
         } else {
           console.warn("netjsagent downloaded successfully. Now starting instrumentation.");
           var netjsagent = require('netjsagent').instrument({logLevel:'debug',BCILoggingMode : 'FILE'});
         }
       });
      }
     });
 
     //var netjsagent = require('netjsagent').instrument({logLevel:'debug',BCILoggingMode : 'FILE'});
  } else {
   console.warn('Disabling Instrumentation as intrumentation configuration file not available.');
  }
} catch (e) {
  console.error(e);
}

var path = "";
var ip,port,clientId,path,protocol;
// to initialize scheduling if reports fetching the list from db.
var init = function()
{
   // taking following values from cmd line args.
  /* if(process.argv.length < 6)
   {
       log.schedulerLog("Arguments missing :  node  filename<string>  ip<string>  port<string>  clientid<string> controllerName<string> ");
       return;
   }*/ 

   process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

   ip = process.argv[2];
   port = process.argv[3];
   clientId = process.argv[4];
   controller = process.argv[5];
   path = process.argv[5];
   protocol = process.argv[6];
   //log.schedulerLog("protocol   ====  "+protocol,1);
   // getting reports info (id and cronstring)
   data.getTaskList(ip,port,clientId,controller,false, "",protocol);
}
init();

// In case of any changes in the task table, changes are made in scheduling as well.
process.on('SIGUSR1', function() {
    log.schedulerLog("Looking for changes",1);
    data.getTaskList(ip,port,clientId,controller,true, "",protocol);
}); 

