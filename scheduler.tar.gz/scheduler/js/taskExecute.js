/*
  Name : taskExecute.js
  Purpose : Used to execute each task scheduled as a separate node process.
  Author : Tuhin Das
*/
var http = require('http');
var log = require('./executeReport.js');
var data = require('./taskCron.js');
var taskHandler = require('./taskHandler.js');
var init = function()
{
   // checking the type of task
   var taskType = process.argv[2]; 
   if(taskType == "rsync") 
   {
      var taskid = process.argv[3];
      var controller = process.argv[4];
      var cid = process.argv[5];
      isEnable(taskid,controller,cid);          
   }
   else if(taskType == "report" || taskType.indexOf("Report") > -1)
   {
      var taskid = process.argv[3];
      var machine = process.argv[4];
      var prt = process.argv[5];
      var cId = process.argv[6];
      var controller = process.argv[7];
      isReportEnable(taskid,machine,prt,cId,controller);
   }
   else if(taskType == "executeTest" || taskType.indexOf("executeTest") > -1)
   {
      var taskid = process.argv[3];
      var machine = process.argv[4];
      var prt = process.argv[5];
      var cId = process.argv[6];
      var controller = process.argv[7];
      var protocol = process.argv[8];
      var g = {"taskid": taskid,"ip":machine,"port":prt,"protocol":protocol};
      log.schedulerLog(JSON.stringify(g));
      try{
      http.get({
        host: machine,
        port : prt,
        path: '/nettest/rest/webapi/executeandscheduletest?filterCriteria='+JSON.stringify(g) + '&access_token=563e412ab7f5a282c15ae5de1732bfd1'
        }, function(response) {
        // append response.
        response.on('data', function(d) {
           log.schedulerLog("---data---");
        });
        response.on('end', function() {
           log.schedulerLog("---end---");
         }); 
        });
      }catch(e){}
   }
   else 
   {
     //Other type of tasks.
     var taskName = process.argv[2];
     var taskid = process.argv[3]; // ! important
     var taskType = process.argv[4]; // ! important
     var command = process.argv[5];
     taskHandler.execute(taskid, command, taskName, taskType);       
   }
}

init();
