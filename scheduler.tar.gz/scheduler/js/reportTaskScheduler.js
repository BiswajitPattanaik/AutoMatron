//using for generate report using template
/**
test=> select * from nvreporttable_controller_varun;
 id | taskid | reporttype | format | datatime | mailobj | crqobj | bucket | reporttime
----+--------+------------+--------+----------+---------+--------+--------+------------
(0 rows)

test=>
test=>
test=>
test=> select * from nvschedulertask_controller_varun;
 taskid | cronstring  | taskname  | expirytime |     schedule     | status | disable | comments
--------+-------------+-----------+------------+------------------+--------+---------+----------
      1 | 0 0 4 * * * | Reporting | 0          | Hourly, At 04:00 |        | enabled |
      2 | 0 0 0 * * * | Reporting | 0          | Hourly, At 00:00 |        | enabled |

**/
//Step 1
function viewReportByType(step) {
    var reportType = '<table style="width:50%">' +
        '<tr>' +
        '<td>Report Type:</td>' +
        '<td><div class="superclass btn-group" data-toggle="buttons">' +
        //'<label  class="btn btn-default active"><input type="radio" value = HTML name="rType" checked />HTML</label>' +
        '<label id="excelButtonID" class="btn btn-default active" onclick=\'getExcelTemplates();fillReportNameRptType("EXCEL")\'><input type="radio" value = EXCEL name="rType"  checked/>EXCEL</label>' +
        '<label id="customButtonID" class="btn btn-default" onclick =\'getTemplates();fillReportNameRptType("CUSTOM");\'><input type="radio" value = CUSTOM name="rType" id="test"/>CUSTOM</label>' +
        '<label id="alertDigestButtonID" class="btn btn-default" onclick =\'fillReportNameRptType("ALERT");\'><input type="radio" value = ALERT name="rType" />ALERT DIGEST REPORT</label></div></td>' +
        '</td></tr>' +
        '<tr> <td colspan="100%">&nbsp;&nbsp;  </td> </tr> ' +
        '<tr><td>Report Name:</td><td><input type="text" class="form-control" style="width:68%;display:inline;" id="reportNameID"> </input></td></tr> <tr> <td colspan="100%">&nbsp;&nbsp;  </td> </tr> ';

    var templateList = '<tr>' +
        '<td colspan="100%"><span style="padding-right: 10px;">' +
        '<input type="radio" name="metricOpt" value="Template" id="TemMetopt" onchange="metricOptAction(value)" checked="yes">Using Template </span>' +
        '<span id="FavMetOpt" style="display:none"><input type="radio" id="FavMetOption" name="metricOpt" value="Favourite" onchange="metricOptAction(value)"> Using Favourite ' +
        '</span><select id = "selTemplateListID" class="form-control" style="width:52%;display:inline;"></select>' +
        '</td>' +
        '</tr>' +
        '</table>';

    document.getElementById('stepbody' + step).innerHTML = reportType + templateList;
    getExcelTemplates();
    $("#reportNameID").val("ExcelReport");
}

function metricOptAction(value) {
    if (value == "Template")
        getTemplates();
    else if (value == "Favourite")
        getFavList();
}
var allTemplates = "";
var allFav = "";
var favList = [];
var favNodeRelPathList = [];

function getFavList() {
    if (allFav == "") {
        let productName = "netstorm";
        if (productType == "NDE" || productType == "ND")
            productName = "netdiagnostics";

        $.ajax({
            url: "/DashboardServer/web/ReportWebService/getFavDataList?testRun=" + testRun + "&productKey=" + productKey + "&useName=" + userName + "&product=" + productName + "&isMultiDc=false",
            async: false,
            success: function(detail) {
                if (detail == "" || detail == 'undefined' || detail == null)
                    return;

                var temp = detail.trim().split(",");
                var template = "<option value=''>Select Favourite</option>";
                var data = JSON.parse(detail);
                favList = [];
                favNodeRelPathList = [];
                console.log(data);
                for (let i = 2; i < data.length; i++) {
                    if (data[i]['favoriteTreeDTO'].length === 0) {
                        favList.push(data[i]['node']);
                        favNodeRelPathList.push(data[i]['nodeRelPath']);
                    }
                    let detailData = data[i];
                    getFavNodePath(detailData, favNodeRelPathList, favList);
                }
                console.log("1 ", favList)
                console.log("2 ", favNodeRelPathList)
                for (let i = 0; i < favList.length; i++) {
                    let favNamewithPath = '';

                    if (favNodeRelPathList[i] != undefined) {
                        favNamewithPath = favNodeRelPathList[i].substring(0,favNodeRelPathList[i].lastIndexOf('/'));
                    }
                    if (favNamewithPath != '') {
                        favNamewithPath = favList[i] + '{' + favNamewithPath + '}';
                    } else {
                        favNamewithPath = favList[i];
                    }
					template = template +"<option value='"+favNodeRelPathList[i] + ' *Fav'+"'>"+favNamewithPath+"</option>";

                }
    allFav = template;
    document.getElementById("selTemplateListID").innerHTML=template;
            }
        });
    }
    document.getElementById("selTemplateListID").innerHTML = allFav;
}

function getFavNodePath(detailData, favNodeRelPathList, favList) {
    if (detailData.favoriteTreeDTO != undefined) {
        for (let j = 0; j < detailData.favoriteTreeDTO.length; j++) {
            if (detailData.favoriteTreeDTO[j].nodeRelPath == undefined) {
                getFavNodePath(detailData.favoriteTreeDTO[j], favNodeRelPathList, favList);
            } else {
                this.favNodeRelPathList.push(detailData.favoriteTreeDTO[j].nodeRelPath);
                favNameWithPath = detailData.favoriteTreeDTO[j].nodeRelPath;
                let favName = detailData.favoriteTreeDTO[j].nodeRelPath.substring(favNameWithPath.lastIndexOf("/") + 1, favNameWithPath.length);
                favList.push(favName);
            }
        }
    } else {
        favNodeRelPathList.push(detailData.nodeRelPath);
        let favName = detailData.nodeRelPath;
        favList.push(favName);
    }
}

function getTemplates() {
    //showCustomRptOptions();
    if (allTemplates == "") {
        $.ajax({
            url: "../reports/getDataFromServer.jsp?request=template ",
            async: false,
            success: function(detail) {
                if (detail == "" || detail == 'undefined' || detail == null)
                    return;
                detail = detail.trim();
                detail = detail.replace("[", "");
                detail = detail.replace("]", "");
                var temp = detail.trim().split(",");
                var template = "<option value=''>Select Template</option>";
                var data = "";

                for (var i = 0; i < temp.length; i++) {
                    var templateName = temp[i];

                    template = template + "<option value='" + templateName + "'>" + templateName + "</option>";
                }
                allTemplates = template;
                document.getElementById("selTemplateListID").innerHTML = template;
            }
        });
    }
    document.getElementById("selTemplateListID").innerHTML = allTemplates;
    //fillRptTypeInScheduleObj("Word Report");
}

function fillReportNameRptType(rptType) {
    if (rptType == "EXCEL") {
        $("#reportNameID").val("ExcelReport");
        $("#FavMetOpt").hide();
		$("#TemMetopt").prop('checked', 'yes');
    } else if (rptType == "ALERT") {
        $("#reportNameID").val("AlertDigestReport");
        $("#FavMetOpt").hide();
		$("#TemMetopt").prop('checked', 'yes');
        $.ajax({
            url: "../reports/getDataFromServer.jsp?request=alertTemplatList",
            async: false,
            success: function(detail) {
                if (detail == "" || detail == 'undefined' || detail == null)
                    return;
                detail = detail.trim();
                detail = detail.replace("[", "");
                detail = detail.replace("]", "");
                var temp = detail.trim().split(",");
                var template = "";
                for (var i = 0; i < temp.length; i++) {
                    var templateName = temp[i];
                    var templateNameWithoutExtension = temp[i].split(".")[0];
                    template = template + "<option value='" + templateName + "'>" + templateNameWithoutExtension + "</option>";
                }
                document.getElementById("selTemplateListID").innerHTML = template;
            }
        });
    } else {
        $("#reportNameID").val("CustomReport");
        $("#FavMetOpt").show();
    }

}

/**function showCustomRptOptions()
{
   $("#customRptOptionsId").css("display","initial");
}**/
function valAndSetReportType() {
    //checking type //HTm/ word/ report
    //  scheduleObj.format = $('[name="rType"]').val();
    scheduleObj.format = $("input[name='rType']:checked").val();

    showComponentByRType(scheduleObj.format);

    var reportName = $('#reportNameID').val();
    if (reportName == "") {
        showAlert("Enter the report name");
        return;
    }
    var regex_report_name = new RegExp('^[a-zA-Z][a-zA-Z0-9_().{}\:\-]*$');
    if (!regex_report_name.test(reportName)) {
        showAlert("Please enter valid report name,must start with Alphabet.Allowed characters are alpha,numeric and following special characters:() {}  _ . space : -");
        document.getElementById("reportNameID").focus();
        return false;
    }

    //length check
    if (reportName.length > 128) {
        showAlert("Enter Report Name <= 128 characters.");
        document.getElementById("reportNameID").focus();
        return false;
    }

    if ($('#selTemplateListID').val() == "") {
        showAlert("Select template name from the list");
        return false;
    }

    //report Type
    pushInCRQ("name", $('#reportNameID').val()); //reportName prefix
    pushInCRQ("productKey", productKey);
    //scheduleObj.reportType = "Excel Report";//we should not set it as hard coded

    //setting
    pushInCRQ("templateName", $('#selTemplateListID').val()); //templateName selected from the combo box
    pushInCRQ("userName", userName); //user name for priviliages
	if($("#TemMetopt").prop('checked') == false)
	 pushInCRQ("metricOption", '4');
    else
	 pushInCRQ("metricOption", '2');
    return true;
}

function showComponentByRType(rtype) {
    if (rtype == "EXCEL") {
        $("#includeChartCompID").css("display", "none");

        $("#aggrCheckbox").css("display", "table-row");
        $("#aggrByOptions").css("display", "table-row");
        $("#spaceForFormat").css("display", "table-row");
        $("#formatCompID").css("display", "none");
        $("#formatCompIDAlert").css("display", "none");
        $("#hideOnAlert").css("display", "initial");
    } else if (scheduleObj.format == "ALERT") {

        $("#includeChartCompID").css("display", "none");
        $("#aggrCheckbox").css("display", "none");
        $("#aggrByOptions").css("display", "none");
        $("#spaceForFormat").css("display", "none");
        $("#formatCompID").css("display", "none");
        $("#formatCompIDAlert").css("display", "table-row");
        $("#hideOnAlert").css("display", "none");
    } else {
        $("#includeChartCompID").css("display", "initial");
        $("#aggrCheckbox").css("display", "none");
        $("#aggrByOptions").css("display", "none");
        $("#spaceForFormat").css("display", "none");
        $("#formatCompID").css("display", "table-row");
        $("#formatCompIDAlert").css("display", "none");
        $("#hideOnAlert").css("display", "initial")
    }
}
//step 2
var viewByOptionList = ["5 Second(s)", "10 Second(s)", "15 Second(s)", "30 Second(s)", "1 Minute(s)", "5 Minute(s)", "10 Minute(s)", "15 Minute(s)", "30 Minute(s)", "1 Hour(s)", "2 Hour(s)", "4 Hour(s)", "6 Hour(s)", "12 Hour(s)", "1 Day(s)", "2 Day(s)", "4 Day(s)", "1 Week(s)", "2 Week(s)", "3 Week(s)", "1 Month(s)", "2 Month(s)", "3 Month(s)", "1 Year(s)"];

function viewReportByPreset(step) {
    var formatOptions = '<td> Format:</td><td> <div class="subclass btn-group" data-toggle="buttons">' +
        '<label class="btn btn-default active" onclick="setWordFormat();" ><input type="radio" id="wordRptId" value = WORD  checked name = radformatType />WORD</label>' +
        '<label class="btn btn-default" onclick="setHtmlFormat();"><input type="radio" id="htmlRptId" value = HTML name = radformatType/>HTML</label></div></td>';

    var alertFormatOptions = '<td> Format:</td><td> <div class="subclass btn-group" data-toggle="buttons">' +
        '<label class="btn btn-default" onclick=\'setAlertDigestReportFormat("WORD");\'><input type="radio" id="wordRptId" value = WORD  checked name = radformatType />WORD</label>' +
        '<label class="btn btn-default active" onclick=\'setAlertDigestReportFormat("EXCEL");\'><input type="radio" id="excelRptId" value = EXCEL name = radformatType/>EXCEL</label>' +
        '<label class="btn btn-default" onclick=\'setAlertDigestReportFormat("PDF");\'><input type="radio" id="pdfRptId" value = PDF name = radformatType/>PDF</label></div></td>';

    var presetsForNS = "<li   style='cursor:pointer;' onclick=\"setLastTime('lastTime','Total$Run'); hideDateTimeOptions();\"><a>Total Run</a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$1$Hour'); hideDateTimeOptions();\"><a>Last 1 Hour  </a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$2$Hours'); hideDateTimeOptions();\"><a>Last 2 Hours  </a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$3$Hours'); hideDateTimeOptions();\"><a>Last 3 Hours </a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$4$Hours'); hideDateTimeOptions();\"><a>Last 4 Hours </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$8$Hours'); hideDateTimeOptions();\"  style='cursor:pointer;' ><a>Last 8 Hours </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$24$Hours'); hideDateTimeOptions();\"  style='cursor:pointer;' ><a>Last 24 Hours </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Custom'); showPresetOptions();\"  style='cursor:pointer;' ><a>Custom</a></li>";


    var presetsForND = "<li   style='cursor:pointer;' onclick=\"setLastTime('lastTime','Last$15$Minutes'); hideDateTimeOptions();\"><a>Last 15 Minutes</a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$1$Hour'); hideDateTimeOptions();\"><a>Last 1 Hour  </a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$2$Hours'); hideDateTimeOptions();\"><a>Last 2 Hours  </a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$3$Hours'); hideDateTimeOptions();\"><a>Last 3 Hours </a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$4$Hours'); hideDateTimeOptions();\"><a>Last 4 Hours </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$8$Hours'); hideDateTimeOptions();\"  style='cursor:pointer;' ><a>Last 8 Hours </a></li>" +
        "<li   onclick=\"setLastTime('lastTime','Last$12$Hours');  hideDateTimeOptions();\"style='cursor:pointer;' ><a>Last 12 Hours </a></li>" +
        "<li    onclick=\"setLastTime('lastTime','Last$16$Hours'); hideDateTimeOptions();\" style='cursor:pointer;' ><a>Last 16 Hours</a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$20$Hours'); hideDateTimeOptions();\"><a>Last 20 Hours</a></li>" +
        "<li   style='cursor:pointer;'  onclick=\"setLastTime('lastTime','Last$24$Hours'); hideDateTimeOptions();\"><a>Last 24 Hours</a></li>" +
        "<li    onclick=\"setLastTime('lastTime','Last$1$Day'); hideDateTimeOptions();\" + style='cursor:pointer;' ><a>Last 1 Day</a></li>" +
        "<li    onclick=\"setLastTime('lastTime','Last$2$Days'); hideDateTimeOptions();\" + style='cursor:pointer;' ><a>Last 2 Days</a></li>" +
        "<li    onclick=\"setLastTime('lastTime','Last$4$Days'); hideDateTimeOptions();\" + style='cursor:pointer;' ><a>Last 4 Days</a></li>" +
        "<li    onclick=\"setLastTime('lastTime','This$Week'); hideDateTimeOptions();\" + style='cursor:pointer;' ><a>This Week</a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$1$Week'); hideDateTimeOptions();\" style='cursor:pointer;'><a>Last 1 Weeks </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$2$Weeks'); hideDateTimeOptions();\" style='cursor:pointer;'><a>Last 2 Weeks </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$4$Weeks'); hideDateTimeOptions();\" style='cursor:pointer;'><a>Last 4 Weeks </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$7$Weeks'); hideDateTimeOptions();\" style='cursor:pointer;'><a>Last 7 Weeks </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','This$Month'); hideDateTimeOptions();\" style='cursor:pointer;'><a>This Month </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$1$Month'); hideDateTimeOptions();\" style='cursor:pointer;' ><a>Last 1 Month </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$2$Months'); hideDateTimeOptions();\" style='cursor:pointer;' ><a>Last 2 Months </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$4$Months'); hideDateTimeOptions();\" style='cursor:pointer;' ><a>Last 4 Months </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$6$Months'); hideDateTimeOptions();\" style='cursor:pointer;' ><a>Last 6 Months </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','This$Year'); hideDateTimeOptions();\" style='cursor:pointer;' ><a>This year</a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$1$Year'); hideDateTimeOptions();\" style='cursor:pointer;' ><a>Last 1 Year </a ></li>" +
        "<li  onclick=\"setLastTime('lastTime','Last$2$Years'); hideDateTimeOptions();\" style='cursor:pointer;' ><a>Last 2 Years </a></li>" +
        "<li  onclick=\"setLastTime('lastTime','Custom'); showPresetOptions();\" style='cursor:pointer;' ><a>Custom</a></li>";

    if (productType == "NS" || productType == "NC") presetOptions = presetsForNS;
    else presetOptions = presetsForND;

    var ih = '<table style="width:100%">' +
        '<tr>' +
        '<td style="padding-top:4px;width:13%;">Preset Option:&nbsp;&nbsp;</td><td style="width:10%;"><div class="dropdown"><button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" style="width:150px" ><span id="lastTime" style="font-size:14px">Select time  </span>&nbsp;<span class="caret" style="margin-left: 5"></span></button>' +
        '<ul id="lastList" class="dropdown-menu" aria-labelledby="ropdownMenu1" style="font-color:#cccccc">' + presetOptions +
        '</ul></div></td>' +
        '<td id="boundaryConditionID" style="width:5%;"></td>' +
        '<td  colspan ="4" style ="width:40%"><span id="hideOnAlert">View by:&nbsp; <select class="form-control" id = "Viewby" style=" display:inline !important;width:26%;font-size:15px;" disabled onchange="fillViewByValue(this.value)"></select>&nbsp;&nbsp;&nbsp;<select class="form-control" id = "ViewByValues" style=" display:inline !important;width:15%;font-size:15px;"disabled ></select> &nbsp;&nbsp;&nbsp;&nbsp;<span id = includeChartCompID><input type="checkbox" name="IncludeChart" value="false" id="includeChartId" >&nbsp;&nbsp;Include Chart</span></td>' +
        '</tr><tr> <td colspan="100%">&nbsp;&nbsp; </span> </td> </tr> ';

    ih += '<tr><td width="120px" style="padding-top:4px">Start Date/Time:</td><td width="178px" style="width:8%;"><div class="input-group"  style="width:180px;"><input  style="padding-top:2%;" class="form-control" type="text" id="startDate"><span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span></div></td><td width=100><div class="input-group clockpicker" style="width:100px;" data-autoclose="true" data-align="top" data-placement="left"><input id="startTime" class="form-control" type="text" value="00:00" disabled=""><span class="input-group-addon" id="sTime"><span class="glyphicon glyphicon-time"></span></span></div> </td><td width="14%" align="right" style="padding-top:4px" >End Date/Time:&nbsp;&nbsp;</td><td width="178px" style="width:8%;"> <div class="input-group" style="width:180px;"><input type="text" class="form-control"  id ="endDate" style ="display-inline"><span class="input-group-addon"><span class="glyphicon glyphicon-calendar"> </span></span></div></td></td><td>&nbsp;</td>  <td><div class="input-group clockpicker" style="width:100px;" data-autoclose="true" data-align="top" data-placement="left"><input id="endTime" class="form-control" type="text" value="00:00" disabled=""><span class="input-group-addon" id="eTime"><span class="glyphicon glyphicon-time"></span></span></div> </td> </tr> <tr><td colspan="100%">&nbsp;&nbsp;  </td> </tr>' +
        '<tr id="aggrCheckbox"><td colspan="4"><input type="checkbox" id = "aggEntireRpt" onclick="aggByValues();" ></input>&nbsp;&nbsp;Aggregated over the entire Report Time Period</td></tr> <tr> <td id ="spaceForFormat" colspan="100%">&nbsp;&nbsp;</td> </tr> ' +
        '<tr id ="aggrByOptions"><td colspan="8" >&nbsp;&nbsp;&nbsp&nbsp;&nbsp;Aggregated by:&nbsp;&nbsp;&nbsp;' +
        '<input type = number class="form-control" style="display:inline !important; width:7%;" id = "aggByXValue" min = "1" max = "24" value = "1">&nbsp;&nbsp;&nbsp;' +
        '<select class="form-control" style="display:inline !important; width:11.5%;padding-left:0px !important;" id = "aggByXUnit" onchange = "checkAggUnit(this)">' +
        '<option value="Minute">Minute(s)</option>' +
        '<option value="Hour">Hour(s)</option>' +
        '<option value="Day">Day(s)</option>' +
        '<option value="Week">Week(s)</option>' +
        '<option value="Month">Month(s)</option>' +

        '</select>&nbsp;&nbsp;&nbsp;<input type="checkbox" id="showLstWDID" disabled></input>&nbsp;Show Last week\'s data day-wise&nbsp;&nbsp;&nbsp;Show report in:&nbsp;&nbsp;' +

        '<select class="form-control" id = "reportView" style="width:11%;font-size:14px;padding-left:0px !important; display:inline !important">' +
        '<option value="columnView">Column</option>' +
        '<option value="tabView">Tab</option>' +
        '</select>&nbsp;view';

    ih += '<td></tr><tr id = formatCompIDAlert>' + alertFormatOptions + '</tr> ';
    ih += '<td></tr><tr id = formatCompID>' + formatOptions + '</tr> ';

    document.getElementById('stepbody' + step).innerHTML = ih;

    //function to call the datePicker for the Start End Date....
    /*    $('#startDate').datepicker({
              format: "mm/dd/yy"
       });
        $('#endDate').datepicker({
              format: "mm/dd/yy"
       });*/
    hideDateTimeOptions();
    aggByValues();
}

function setWordFormat() {
    scheduleObj.format = "WORD";
    scheduleObj.reportType = "Word Report";
}

function setHtmlFormat() {
    scheduleObj.format = "HTML";
    scheduleObj.reportType = "Html Report";
}

function setAlertDigestReportFormat(type) {
    scheduleObj.format = "ALERT";
    if (type == "PDF")
        scheduleObj.reportType = "Alert DigestPDF Report";
    else if (type == "WORD")
        scheduleObj.reportType = "Alert DigestWORD Report";
    else
        scheduleObj.reportType = "Alert DigestEXCEL Report";
}

function setLastTime(e, value) {
    showPresetOptions();
    var setTime = value.replace('$', ' ');
    var presetValue = setTime.replace('$', ' ');
    var boundaryValue = '';
    var presetValArr = value.split("$");
    if (presetValArr.length == 3)
        boundaryValue = value.split("$")[2];
    if (boundaryValue.indexOf("Week") >= 0 || boundaryValue.indexOf("Month") >= 0 || boundaryValue.indexOf("Year") >= 0) {
        $("#boundaryConditionID").attr("colspan", "2");
        boundaryValue = changeBoundaryValue(boundaryValue);
        $("#boundaryConditionID").html("<input type='checkbox' id='boundaryConditionCheckID' onchange='getDateTimeForPreset(\"" + presetValue + "\")'>&nbsp;&nbsp;Enforce " + boundaryValue + " boundary</input>");
        $("#boundaryConditionCheckID").prop("checked", true);
    } else {
        $("#boundaryConditionID").attr("colspan", "1");
        $("#boundaryConditionID").html('');
    }
    document.getElementById(e).innerHTML = setTime.replace('$', ' ');
    var presetValue = setTime.replace('$', ' ');
    getDateTimeForPreset(presetValue);
}

/*function getPhases(testRun, isPhaseRequired )
{
  var protocol = location.protocol;
  var host = location.hostname;
  var port = location.port;
  var urlBase = protocol+"//"+host+ ":"+port+"/";
  $.ajax({
        url: urlBase+"DashboardServer/web/ReportWebService/PhasesInfo?testRun="+testRun+"&isPhaseRequired="+isPhaseRequired,
        async: false,
        success : function(data)
        {
          
        }
  });

}*/

var testRunStartTime;
var presetJson;
/* Varribale used for validate the preset value is greater then test run or not*/
var durationTR = "";
var isTestRunning = "";

function getDateTimeForPreset(presetValue) {
    var protocol = location.protocol;
    var host = location.hostname;
    var port = location.port;
    var urlBase = protocol + "//" + host + ":" + port + "/";
    var boundaryCondition = $("#boundaryConditionCheckID").prop("checked");
    if (boundaryCondition == false) {
        presetValue = presetValueByBoundaryCondition(presetValue);
    }
    /*Do ajax call for test run duration*/
    if (durationTR == "")
        getBasicInfoForReports();

    if (isTestRunning == 'false') {
        console.log("Going to check valid preset value.")
        var isInvalid = calculateDuration(presetValue);
        if (isInvalid) {
            presetValue = "Total Run";
            $("#lastTime").text('Total Run');
        }
    }

    if (presetValue == "Total Run")
        presetValue = "whole scenario";

    var encoded_presetValue = encodeURIComponent(presetValue);

    var url = urlBase + "DashboardServer/web/graphTimeService/presetWinData?testRun=" + testRun + "&client_connection_key=" + userName + ":11127:1464328504748&userName=" + userName + "&selectedPreset=" + encoded_presetValue + "&isIncludeCurrentData=false&isRunning=false&eventDay=null&eventYear=null&isOnline=true&product=" + productType + "&productKey=" + productKey;
    //var url = urlBase+"DashboardServer/web/ReportWebService/datetimeforpreset?testRun="+testRun+"&valueoption="+presetValue+"&isTestRunning=true&productType=nvsm&timeFormat=Absolute";
    //do a ajax call here to calculate the time based on the presetValue

    $.ajax({
        url: url,
        async: false,
        beforeSend: function() {
            $("#loading").show();
        },
        success: function(data) {
            $("#loading").hide();
            presetJson = data;
            testRunStartTime = data.startDate + " " + data.startTime;
            var testRunEndTime = data.endDate + " " + data.endTime;

            var tRunSd = data.startDate;
            var tRunSt = data.startTime;

            var tRunEd = data.endDate;
            var tRunEt = data.endTime;

            populateDateTimeForPreset(presetValue, tRunSd, tRunSt, tRunEd, tRunEt);
            fillViewByOptions();
        }
    });
}

//function to reformate tha date
function reformatDate(dateStr) {
    dArr = dateStr.split("/"); // ex input "2010-01-18" "18/01/2010"
    var s = dArr[0] + "/" + dArr[1] + "/" + dArr[2].substring(2); //ex out: "18/01/10"
    return s;
}


function presetValueByBoundaryCondition(presetValue) {
    var newPresetValue;
    if (presetValue.indexOf("Week") >= 0) {
        var numberOfWeeks = presetValue.split(" ")[1];
        var numDays = 7 * parseInt(numberOfWeeks);
        newPresetValue = "Last " + numDays + " Days";
    } else if (presetValue.indexOf("Month") >= 0) {

        //find the current month m
        //find the number of days in the month m-1
        //then get the total number of days in that month multiplied by the number of month

        var numMonth = presetValue.split(" ")[1];
        var currMonth = new Date().getMonth();
        var currYear = new Date().getFullYear();
        if (currMonth == 0)
            currMonth = 11;
        else
            currMonth = currMonth - 1;

        var numDays = daysInMonth(currMonth, currYear);
        numDays = numDays * numMonth;
        newPresetValue = "Last " + numDays + " Days";
    } else {
        var numDays = "365";
        var currYear = new Date().getFullYear();
        if (isLeapYear(currYear)) {
            newPresetValue = "Last 366 Days";
        }
    }
    return newPresetValue;
}

function isLeapYear(year) {
    return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
}

function daysInMonth(month, year) {
    return new Date(year, month, 0).getDate();
}

function populateDateTimeForPreset(presetValue, tRunSd, tRunSt, tRunEd, tRunEt) {
    $("#startDate").val(tRunSd);
    $("#startTime").val(tRunSt);
    $("#endDate").val(tRunEd);
    $("#endTime").val(tRunEt);
    if (presetValue == 'Custom') {
        $("#startDate").removeAttr("disabled");
        $("#startTime").removeAttr("disabled");
        $("#endDate").removeAttr("disabled");
        $("#endTime").removeAttr("disabled");
        var startDate = reformatDate(tRunSd);
        var endDate = reformatDate(tRunEd);
        if (productType == "NDE" || productType == "ND") {
            $("#startTime").val("00:00");
            $("#startDate").val(tRunEd);
            startDate = reformatDate(tRunEd);
        }

        $("#startDate").val(startDate);
        $("#endDate").val(endDate);
        $('#startDate').datepicker({
            format: "mm/dd/yy"
        });
        $('#endDate').datepicker({
            format: "mm/dd/yy"
        });
    } else {
        $("#startDate").attr("disabled", "disabled");
        $("#startTime").attr("disabled", "disabled");
        $("#endDate").attr("disabled", "disabled");
        $("#endTime").attr("disabled", "disabled");
    }
}

function fillViewByOptions() {
    $("#Viewby").find('option').remove(); //remove the previous populated options if any
    $("#Viewby").removeAttr("disabled");
    // $("#Viewby").append("<option value='Auto'>Auto</option>");
    /*fill the viewBy Options*/
    for (var i = 0; i < presetJson.viewBy.length; i++) {
        //Below line commented for bug 36710
        //if(presetJson.viewBy[i] != "Day" && presetJson.viewBy[i] != "Week" && presetJson.viewBy[i] != "Month")

        if ($("#Viewby option[value=" + presetJson.viewBy[i] + "]").length == 0)
            $("#Viewby").append("<option value=" + presetJson.viewBy[i] + ">" + presetJson.viewBy[i] + "</option>");

    }

    /*Now select the best view by option from the list of option
      In case of Custom preset, there is no view by option, so we assume first viewBy option from the viewBy json, and in noncustom preset options, we have best viewBy json
    */
    var displayViewByOption = presetJson.selectedPreset == 'Custom' ? presetJson.viewBy[0] : presetJson.bestViewBy['viewBy'];

    $("#Viewby").val(displayViewByOption);
    fillViewByValue(displayViewByOption); //ViewBy value according to the view by optin
}

function fillViewByValue(viewByOption) {
    console.log("viewByOption is ", viewByOption);

    $("#ViewByValues").find("option").remove(); //remove the previous viewby values
    if (viewByOption == "Auto")
        $("#ViewByValues").attr("disabled", "disabled");
    else
        $("#ViewByValues").removeAttr("disabled");
    //Now fill the viewByValues in the dropdown according to the selected view by option

    var viewByValueArr = presetJson.viewByValue[viewByOption];

    for (var i = 0; i < viewByValueArr.length; i++) {
        var value = viewByValueArr[i].split(" ")[0];
        $("#ViewByValues").append("<option value=" + value + ">" + value + "</option>");
    }

    /*Now select the best view by value according to the selected preset
      In case of Custom preset, there is no view by option and value, so we assume first viewBy value from the viewBy value json, and in noncustom preset options, we have best viewBy json
    */
    var displayViewByValue = presetJson.selectedPreset == 'Custom' ? String(presetJson.viewByValue[viewByOption]).split(" ")[0] : String(presetJson.bestViewBy['viewByValue']).split(" ")[0];

    $("#ViewByValues").val(displayViewByValue);
}

function changeBoundaryValue(boundaryValue) {
    if (boundaryValue.lastIndexOf("s") >= 0)
        boundaryValue = boundaryValue.substring(0, boundaryValue.length - 1);
    return boundaryValue;
}

var excelTemplate = "";

function getExcelTemplates() {
    //hideCustomRptOptions();
    if (excelTemplate == "") {
        $.ajax({
            url: "../reports/getDataFromServer.jsp?request=excelTemplate",
            async: false,
            success: function(detail) {
                detail = detail.replace("[", "");
                detail = detail.replace("]", "");
                var temp = detail.trim().split(",");
                var template = "<option value=''>Select Template</option>";
                var data = "";
                for (var i = 0; i < temp.length; i++) {
                    var extension = temp[i].substring(temp[i].indexOf('.'), temp[i].length);
                    data = temp[i].replace(extension, "");
                    template = template + "<option value='" + data + "" + extension + "'>" + data + "</option>";
                }
                document.getElementById('selTemplateListID').innerHTML = template;
                excelTemplate = template;
            }
        });
    }
    document.getElementById("selTemplateListID").innerHTML = excelTemplate;
    //fillRptTypeInScheduleObj("Excel Report");
}

/**function hideCustomRptOptions()
{
   $("#customRptOptionsId").css("display","none");
}**/

//function to show the view options...
function showViewOption(obj) {

    var temp = obj.value;
    var valueOptions = "";
    if (temp != "Auto")
        $("#ViewByValues").removeAttr("disabled");
    else
        $("#ViewByValues").attr("disabled", "disabled");
    for (var i = 0; i < viewByOptionList.length; i++) {
        var viewByValue = viewByOptionList[i].split(" ")[0];
        var unit = viewByOptionList[i].split(" ")[1];
        if (temp == unit) {
            valueOptions += "<option value='" + viewByValue + "'>" + viewByValue + "</option>"
        }
        if (obj == unit) {
            valueOptions += "<option value='" + viewByValue + "'>" + viewByValue + "</option>"
        }
    }
    document.getElementById("ViewByValues").innerHTML = valueOptions;
}

function valAndSetReportPreset() {
    //Data time has two types of time range last and specified . In case of last time second index of datatime split by & should be 0.
    //var lastTime = document.getElementById('lastTime').innerHTML+"&0";
    var lastTime = document.getElementById('lastTime').innerHTML;
    var viewByParameter = document.getElementById('Viewby').value;
    lastTime = lastTime.trim();
    if (lastTime == "" || lastTime == "Select time") {
        showAlert("Select time option from the list");
        return false;
    }

    if ($("#aggEntireRpt").prop("checked") == false) {
        if ($("#aggByXUnit").val() == "") {
            showAlert("Select time unit from the list");
            return false;
        }

        if ($("#aggByXValue").val() == "") {
            showAlert("Select aggregated time value from the list");
            return false;
        }

        pushInCRQ("aggEntireRpt", $("#aggByXValue").val() + " " + $("#aggByXUnit").val() + " false")
    } else
        //pushInCRQ("aggEntireRpt", -1);
        pushInCRQ("aggEntireRpt", $("#aggByXValue").val() + " " + $("#aggByXUnit").val() + " true");
    if (lastTime == "Custom") {

        if ($("#startDate").val() == "" || $("#startTime").val() == "" || $("#endDate").val() == "" || $("#endTime").val() == "") {
            showAlert("Enter date and time");
            return;
        }
        if (validateDateAndTime(testRunStartTime, $("#startDate").val(), $("#endDate").val(), $("#startTime").val(), $("#endTime").val()) == false)
            return;
        pushInCRQ("startDate", $("#startDate").val());
        if ($("#startTime").val().split(":").length == 2)
            pushInCRQ("startTime", $("#startTime").val() + ":00");
        else
            pushInCRQ("startTime", $("#startTime").val());
        pushInCRQ("endDate", $("#endDate").val());
        if ($("#endTime").val().split(":").length == 2)
            pushInCRQ("endTime", $("#endTime").val() + ":00");
        else
            pushInCRQ("endTime", $("#endTime").val());
        scheduleObj.dataTime = $("#startDate").val() + " " + $("#startTime").val() + ":00" + "&" + $("#endDate").val() + " " + $("#endTime").val() + ":00";
    } else
        scheduleObj.dataTime = lastTime + "&0";

    pushInCRQ("reportView", $("#reportView").val());
    pushInCRQ("shwLstData", $("#showLstWDID").prop("checked"));
    var boundaryCondition = $("#boundaryConditionCheckID").prop("checked");
    if (boundaryCondition == undefined) {
        pushInCRQ("boundaryCondition", "NA");
    } else {
        pushInCRQ("boundaryCondition", boundaryCondition);
    }

    scheduleObj.format = $('.superclass > .btn.active').text() == "EXCEL" ? "EXCEL" : $('.subclass > .btn.active').text() == "WORD" ? "WORD" : "HTML";
    //If user goes with default selected (excel) in case of alert digest report 
    if ($('.superclass > .btn.active').text() == "ALERT DIGEST REPORT") {
        scheduleObj.format = "ALERT";
        if (scheduleObj.reportType == undefined)
            scheduleObj.reportType = "Alert DigestEXCEL Report";
    }
    console.log($('.superclass > .btn.active').text() == "CUSTOM")
    //If user goes with default selected in case of custom report
    if ($('.superclass > .btn.active').text() == "CUSTOM") {
        if (scheduleObj.reportType == undefined)
            scheduleObj.format = "WORD";
    }
    //include chart
    pushInCRQ("includeChart", $("#includeChartId").prop("checked"));

    pushInCRQ("lastTime", lastTime);

    if (scheduleObj.format == "EXCEL")
        scheduleObj.reportType = "Excel Report";
    else if (scheduleObj.format == "WORD")
        scheduleObj.reportType = "Word Report";
    /* else if(scheduleObj.format == "HTML")
       scheduleObj.reportType = "Html Report";*/

    if (viewByParameter == 'Auto') {
        pushInCRQ("viewBy", viewByParameter);
    } else {
        var viewByValue = document.getElementById('ViewByValues').value;
        pushInCRQ("viewBy", viewByParameter + "_" + viewByValue);
    }
    pushInCRQ("testRun", testRun);
    //scheduleObj.bucket = "true&&1 hour&&tabview";
    return true;

}

function validateDateAndTime(testRunStartDateTime, stDate, ndDate, stTime, ndTime) {
    var startDate = stDate + " " + stTime;
    var endDate = ndDate + " " + ndTime;
    startDate = new Date(startDate);
    endDate = new Date(endDate);
    var testRunDateTime = new Date(testRunStartDateTime);

    if (startDate >= endDate) {
        showAlert("Start date and time should not be greater than End date and time");
        return false;
    }

    var stTimeValid = /^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$/.test(stTime);

    if (!stTimeValid) {
        showAlert("Please enter the Start time in HH:MM:SS format");
        return false;
    }
    var ndTimeValid = /^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$/.test(ndTime);
    if (!ndTimeValid) {
        showAlert("Please enter the Start time in HH:MM:SS format");
        return false;
    }

    if (startDate < testRunDateTime || endDate < testRunDateTime) {
        showAlert("Start date and time and End date Time should be greater than TestRun Start date and time");
        return false;
    }
}

function validateTime(obj) {
    var timeValue = obj.value;
    if (timeValue == "" || timeValue.indexOf(":") < 0) {
        alert("Invalid Time format");
        return false;
    } else {
        var sHours = timeValue.split(':')[0];
        var sMinutes = timeValue.split(':')[1];
        var sSeconds = timeValue.split(':')[2];

        if (sHours == "" || isNaN(sHours) || parseInt(sHours) > 23) {
            alert("Invalid Time format");
            return false;
        } else if (parseInt(sHours) == 0)
            sHours = "00";
        else if (sHours < 10)
            sHours = "0" + sHours;

        if (sMinutes == "" || isNaN(sMinutes) || parseInt(sMinutes) > 59) {
            alert("Invalid Time format");
            return false;
        } else if (parseInt(sMinutes) == 0)
            sMinutes = "00";
        else if (sMinutes < 10)
            sMinutes = "0" + sMinutes;

        if (sSeconds == "" || isNaN(sSeconds) || parseInt(sSeconds) > 59) {
            alert("Invalid Time format");
            return false;
        } else if (parseInt(sSeconds) == 0)
            sMinutes = "00";
        else if (sSeconds < 10)
            sSeconds = "0" + sSeconds;


        obj.value = sHours + ":" + sMinutes + ":" + sSeconds;
    }

    return true;
}


function pushInCRQ(key, value) {
    if (scheduleObj.crqObj == undefined)
        scheduleObj.crqObj = {};

    var json = scheduleObj.crqObj;
    json[key] = value;
    console.log(JSON.stringify(json));
    scheduleObj.crqObj = json;
}
//step 3
//using schedule option - taskSchedule.js

//step 4
//using Mail option - taskSchedule.js

//Setp 5
function viewReportScheduleSummary() {
    var reportName = scheduleObj.crqObj.name;
    var boundaryCondition = scheduleObj.crqObj.boundaryCondition;
    var presetArr = scheduleObj.dataTime.split('&')[0].split('$$').join(" ");
    var boundaryValue = ''
    if (presetArr.length == 3)
        boundaryValue = reportDuration.split(" ")[2];

    boundaryValue = changeBoundaryValue(boundaryValue);
    if (boundaryCondition == "NA" || boundaryCondition == false)
        boundaryCondition = "Enforce " + boundaryValue + " boundary:OFF";
    else
        boundaryCondition = "Enforce " + boundaryValue + " boundary:ON";
    reportName = reportName.substring(reportName.indexOf('.'), reportName.length);
    var templateName = "";
    var name = scheduleObj.crqObj.templateName;
    var temp = name.indexOf('.');
    if (temp < 0) {
        templateName = scheduleObj.crqObj.templateName;
    } else {
        templateName = name.substring(0, name.indexOf('.'));
    }
    var ih = "<label class='btn btn-default'><b>Report Name : </b>" + reportName + "</label>";
    if (scheduleObj.format != "ALERT")
        ih += "<label class='btn btn-default' style='margin-left:4px;' ><b>Template Name : </b>" + templateName + "</label>";
    ih += "<label class='btn btn-default' style='margin-left:4px;' ><b>Report Type : </b>" + scheduleObj.reportType + "</label>";
    ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Report Format : </b>" + scheduleObj.format + "</label></br></br>";
    if (scheduleObj.dataTime.split('&')[1] == "0") {
        boundaryCondition = changeBoundaryValue(boundaryCondition);
        ih += "<label class='btn btn-default'><b>Report Duration : </b>" + scheduleObj.dataTime.split('&')[0].split('$$').join(" ") + " (" + boundaryCondition + ") " + "</label>";
    } else {
        var arrTemp = scheduleObj.dataTime.split('&');

        ih += "<label class='btn btn-default'><b>Report Start Date/Time : </b>" + arrTemp[0] + "</label>";
        ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Report End Date/Time : </b>" + arrTemp[1] + "</label>";
    }


    ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Schedule : </b>" + sch.sCron + "</label>";

    ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Schedule Expiry Time : </b>" + ((sch.expiryTime == "0") ? "Not Set" : sch.expiryTime) + "</label></br></br>";
    ih += "<label class='btn btn-default'><b>Mail To : </b>" + ((scheduleObj.mail.to == "") ? " Not specified" : scheduleObj.mail.to) + "</label>";
    ih += "<label class='btn btn-default' style='margin-left:4px;'><b>Mail Subject : </b>" + ((scheduleObj.mail.subject == "") ? " Not specified" : scheduleObj.mail.subject) + "</label></br></br>";
    ih += "<label class='btn btn-default'><b>Mail Body : </b>" + ((scheduleObj.mail.body == "") ? " Not specified" : scheduleObj.mail.body) + "</label>";
    document.getElementById('summary').innerHTML = ih;

}

//function to show the dateTimeOptions.....
function showPresetOptions() {
    document.getElementById("startDate").disabled = false;
    document.getElementById("endDate").disabled = false;
    $("#sTime").css("pointer-events", "initial");
    $("#eTime").css("pointer-events", "initial");
}

//function to hide the dateTimeOptions....
function hideDateTimeOptions() {
    document.getElementById("startDate").disabled = true;
    document.getElementById("endDate").disabled = true;
    $("#sTime").css("pointer-events", "none");
    $("#eTime").css("pointer-events", "none");
}

/*//function to call the datePicker method.....
 $(function(){ 
   $('#startDate').datepicker({
          format: "dd/mm/yyyy"
   });
}); */

//function to enable and disable the aggByValuesss
function aggByValues() {
    var aggByXUnit = $("#aggByXUnit").val();
    if (document.getElementById("aggEntireRpt").checked == true) {
        document.getElementById("aggByXUnit").disabled = true;
        document.getElementById("aggByXValue").disabled = true;
        document.getElementById("reportView").disabled = true;
        $("#reportView").val("tabView");
        if (aggByXUnit.indexOf("Week") >= 0)
            $("#showLstWDID").attr("disabled", "disabled");
    } else {
        document.getElementById("aggByXUnit").disabled = false;
        document.getElementById("aggByXValue").disabled = false;
        document.getElementById("reportView").disabled = false;
        if (aggByXUnit.indexOf("Week") >= 0)
            $("#showLstWDID").removeAttr("disabled");
    }
}

// function to set the aggValues by checking the aggUnit...
function checkAggUnit(unit) {
    $("#showLstWDID").attr("disabled", "disabled");
    $("#showLstWDID").prop("checked", false);
    if (unit.value == "Hour") {
        document.getElementById("aggByXValue").value = '1';
        document.getElementById("aggByXValue").max = '24';
    }
    if (unit.value == "Week") {
        document.getElementById("aggByXValue").value = '1';
        document.getElementById("aggByXValue").max = '3';
        $("#showLstWDID").removeAttr("disabled");
        $("#showLstWDID").prop("checked", true);
    }
    if (unit.value == "Day") {
        document.getElementById("aggByXValue").value = '1';
        document.getElementById("aggByXValue").max = '31';
    }
    if (unit.value == "Minute") {
        document.getElementById("aggByXValue").value = '1';
        document.getElementById("aggByXValue").max = '59';
    }

}



function setPrevValueForAllReports(rInfo, reportType) {
    var crq = JSON.parse(rInfo[6]);
    //step 1 -> template name selected
    if (reportType == "Html Report" || reportType == "Word Report") {
        $("#customButtonID").click();
        if (reportType == "Html Report") {
            $("#htmlRptId").click();
            setHtmlFormat();
        } else {
            $("#wordRptId").click();
            setWordFormat();
        }
    } else if (reportType.indexOf("Alert") > -1) {
        $("#alertDigestButtonID").click();

        if (reportType.indexOf("WORD") > -1) {
            $("#wordRptId").click();
            setAlertDigestReportFormat("WORD");
        } else if (reportType.indexOf("PDF") > -1) {
            setAlertDigestReportFormat("PDF");
            $("#pdfRptId").click();
        } else
            setAlertDigestReportFormat("EXCEL");
    }
    if (reportType == "Html Report" || reportType == "Word Report") {
        $("#customButtonID").click();
        if (reportType == "Html Report") {
            $("#htmlRptId").click();
            setHtmlFormat();
        } else {
            $("#wordRptId").click();
            setWordFormat();
        }
    }
    var templateName = crq.templateName;
	if(crq.metricOption!= undefined && crq.metricOption == "4")
	{
	getFavList();
	$("#FavMetOption").prop("checked",true);
	}
    $('#selTemplateListID').val(templateName);
    $("#reportNameID").val(crq.name);
    //{"reportView":"tabView","aggEntireRpt":"24 Hour","name":" OpenApiTemplate.xls","lastTime":"Last 4 Hours","templateName":" OpenApiTemplate.xls"}
    //step 2 - preset option
    var aggEntire = crq.aggEntireRpt;
    var temp = aggEntire.split(" ");
    $("#aggByXValue").val(temp[0]);
    $("#aggByXUnit").val(temp[1]);
    $("#reportView").val(crq.reportView);
    var boundaryCondition = crq.boundaryCondition;
    if (boundaryCondition != "NA") {
        var boundaryValue = (crq.lastTime).split(" ")[2];
        boundaryValue = changeBoundaryValue(boundaryValue);
        var presetValue = document.getElementById("lastTime").value;
        presetValue = presetValue.replace('$', ' ');
        presetValue = presetValue.replace('$', ' ');
        $("#boundaryConditionID").attr("colspan", "2");
        $("#boundaryConditionID").html("<input type='checkbox' id='boundaryConditionCheckID' onchange='getDateTimeForPreset(\"" + presetValue + "\")'>&nbsp;&nbsp;Enforce " + boundaryValue + " boundary</input>");
        $("#boundaryConditionCheckID").prop("checked", boundaryCondition);
    } else {
        $("#boundaryConditionID").html("");
    }
    var showLstDataValue = crq.shwLstData;

    if (showLstDataValue == undefined)
        showLstDataValue = false;

    if (showLstDataValue == true);
    $("#showLstWDID").removeAttr("disabled");

    if ($("#aggByXUnit").val() != "Week")
        $("#showLstWDID").attr("disabled", "disabled");

    $("#showLstWDID").prop("checked", showLstDataValue);
    if (temp[2] == "true") {
        $("#aggEntireRpt").attr("checked", "checked");
        $("#aggByXValue").attr("disabled", "disabled");
        $("#aggByXUnit").attr("disabled", "disabled");
        $("#reportView").attr("disabled", "disabled");
    } else {
        $("#aggEntireRpt").removeAttr("checked");
        $("#aggByXValue").removeAttr("disabled");
        $("#aggByXUnit").removeAttr("disabled");
        $("#reportView").removeAttr("disabled");
    }
    document.getElementById('lastTime').innerHTML = crq.lastTime;

    if (crq.includeChart == true) {
        document.getElementById("includeChartId").checked = true;
    }
    if (crq.lastTime == "Custom") {
        getDateTimeForPreset(crq.lastTime);
        $("#startDate").val(crq.startDate);
        var startTime = crq.startTime;
        //If time is in format HH:MM:SS:00
        if (startTime.split(":").length > 3) {
            var timearray = startTime.split(":");
            startTime = timearray[0] + ":" + timearray[1] + ":" + timearray[2];
        }
        $("#startTime").val(startTime);
        $("#endDate").val(crq.endDate);
        var endTime = crq.endTime;
        //If time is in format HH:MM:SS:00
        if (endTime.split(":").length > 3) {
            var timearray = endTime.split(":");
            endTime = timearray[0] + ":" + timearray[1] + ":" + timearray[2];
        }
        $("#endTime").val(endTime);

        //Set the custom date in datePicker calender
        $("#startDate").datepicker("remove");
        $("#endDate").datepicker("remove");
        $("#startDate").datepicker({
            format: "mm/dd/yy"
        });
        $('#endDate').datepicker({
            format: "mm/dd/yy"
        });

        $("#startDate").removeAttr("disabled");
        $("#startTime").removeAttr("disabled");
        $("#endDate").removeAttr("disabled");
        $("#endTime").removeAttr("disabled");
        var viewBy = crq.viewBy;
        var viewOption = viewBy.split("_");
        $("#Viewby").val(viewOption[0]);
        fillViewByValue($("#Viewby").val());

        $("#ViewByValues").val(viewOption[1]);

    } else {

        getDateTimeForPreset(crq.lastTime);
        var viewBy = crq.viewBy;
        var viewOption = viewBy.split("_");
        getDateTimeForPreset(crq.lastTime);

        $("#Viewby").val(viewOption[0]);
        fillViewByValue($("#Viewby").val());

        $("#ViewByValues").val(viewOption[1]);

        $("#startDate").attr("disabled", "disabled");
        $("#startTime").attr("disabled", "disabled");
        $("#endDate").attr("disabled", "disabled");
        $("#endTime").attr("disabled", "disabled");
    }
}


function getBasicInfoForReports() {
    $.ajax({
        async: false,
        url: "../../../DashboardServer/web/ReportWebService/getBasicInfoParam?testrun=" + testRun + "&productKey=" + productKey,
        beforeSend: function() {
            $("#loading").show();
        },
        success: function(data) {
            $("#loading").hide();
            data = data.trim();
            var paramInfo = data.split(',');
            durationTR = paramInfo[2];
            isTestRunning = paramInfo[4];
            console.log("durationTR  =  " + durationTR + "  ,isTestRunning = " + isTestRunning);
        }
    });
}

function calculateDuration(presetoption) {
    console.log("presetoption   " + presetoption);
    var value = presetoption.split(" ")[1];
    var unit = presetoption.split(" ")[2];
    var timeForPreset = getTimeInMillisecByUnit(unit, value);
    var durationTime = getTimeInMillisec(durationTR);
    console.log("timeForPreset   " + timeForPreset + "         durationTime    " + durationTime);
    if (parseInt(timeForPreset) > parseInt(durationTime)) {
        showAlert("Invalid preset value as preset value is exceeding total duration of test run.");
        return true;
    }
}

function getTimeInMillisec(time) {
    var arr = time.split(":");
    var hour = arr[0] * 60 * 60 * 1000;
    var min = arr[1] * 60 * 1000;
    var sec = arr[2] * 1000;

    return parseInt(hour) + parseInt(min) + parseInt(sec);;
}

function getTimeInMillisecByUnit(unit, viewByValue) {
    if (unit == undefined)
        return;

    if (unit.indexOf("Minute") != -1 || unit.indexOf("Minutes") != -1)
        viewByValue = viewByValue * 60 * 1000;

    else if (unit.indexOf("Hour") != -1 || unit.indexOf("Hours") != -1)
        viewByValue = viewByValue * 60 * 60 * 1000;

    else if (unit.indexOf("Day") != -1 || unit.indexOf("Days") != -1)
        viewByValue = viewByValue * 24 * 60 * 60 * 1000;

    else if (unit.indexOf("Week") != -1 || unit.indexOf("Weeks") != -1)
        viewByValue = viewByValue * 7 * 24 * 60 * 60 * 1000;

    else if (unit.indexOf("Month") != -1 || unit.indexOf("Months") != -1)
        viewByValue = viewByValue * 30 * 24 * 60 * 60 * 1000; //30 days hard coded,needs to be handled

    else if (unit.indexOf("Year") != -1 || unit.indexOf("Years") != -1)
        viewByValue = viewByValue * 365 * 24 * 60 * 60 * 1000; //365 days in a year hard coded,needed to be handled
    return viewByValue;
}