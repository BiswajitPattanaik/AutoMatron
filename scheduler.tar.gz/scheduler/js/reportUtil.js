/* Name : reportUtil.js
   Purpose : Contains function to be used by from both front end and back end for executing reports.
   Author : Tuhin Das
*/


//"use strict"; // for browser compatibility.

(function(){

//this is root (can be window in case of browser mode else global.)
var mode = "client";
var window = this;
(function(w) {
  var dateFormat = function() {
    var token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
    timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
    timezoneClip = /[^-+\dA-Z]/g,
    pad = function(val, len) {
      val = String(val);
      len = len || 2;
      while (val.length < len) val = "0" + val;
      return val;
    };

    // Regexes and supporting functions are cached through closure
    return function(date, mask, utc) {
      var dF = dateFormat;

      // You can't provide utc if you skip other args (use the "UTC:" mask prefix)
      if (arguments.length == 1 && Object.prototype.toString.call(date) == "[object String]" && !/\d/.test(date)) {
        mask = date;
        date = undefined;
      }

      // Passing date through Date applies Date.parse, if necessary
      date = date ? new Date(date) : new Date;
      if (isNaN(date)) throw SyntaxError("invalid date");

      mask = String(dF.masks[mask] || mask || dF.masks["default"]);

      // Allow setting the utc argument via the mask
      if (mask.slice(0, 4) == "UTC:") {
        mask = mask.slice(4);
        utc = true;
      }

      var _ = utc ? "getUTC" : "get",
      d = date[_ + "Date"](),
      D = date[_ + "Day"](),
      m = date[_ + "Month"](),
      y = date[_ + "FullYear"](),
      H = date[_ + "Hours"](),
      M = date[_ + "Minutes"](),
      s = date[_ + "Seconds"](),
      L = date[_ + "Milliseconds"](),
      o = utc ? 0 : date.getTimezoneOffset(),
      flags = {
        d: d,
        dd: pad(d),
        ddd: dF.i18n.dayNames[D],
        dddd: dF.i18n.dayNames[D + 7],
        m: m + 1,
        mm: pad(m + 1),
        mmm: dF.i18n.monthNames[m],
        mmmm: dF.i18n.monthNames[m + 12],
        yy: String(y).slice(2),
        yyyy: y,
        h: H % 12 || 12,
        hh: pad(H % 12 || 12),
        H: H,
        HH: pad(H),
        M: M,
        MM: pad(M),
        s: s,
        ss: pad(s),
        l: pad(L, 3),
        L: pad(L > 99 ? Math.round(L / 10) : L),
        t: H < 12 ? "a" : "p",
        tt: H < 12 ? "am" : "pm",
        T: H < 12 ? "A" : "P",
        TT: H < 12 ? "AM" : "PM",
        Z: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
        o: (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
        S: ["th", "st", "nd", "rd"][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10]
      };

      return mask.replace(token, function($0) {
        return $0 in flags ? flags[$0] : $0.slice(1, $0.length - 1);
      });
    };
  } ();

  // Some common format strings
  dateFormat.masks = {
    "default": "ddd mmm dd yyyy HH:MM:ss",
    shortDate: "m/d/yy",
    mediumDate: "mmm d, yyyy",
    longDate: "mmmm d, yyyy",
    fullDate: "dddd, mmmm d, yyyy",
    shortTime: "h:MM TT",
    mediumTime: "h:MM:ss TT",
    longTime: "h:MM:ss TT Z",
    isoDate: "yyyy-mm-dd",
    isoTime: "HH:MM:ss",
    isoDateTime: "yyyy-mm-dd'T'HH:MM:ss",
    isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'"
  };

  // Internationalization strings
  dateFormat.i18n = {
    dayNames: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    monthNames: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
  };

  // For convenience...
  Date.prototype.format = function(mask, utc) {
    return dateFormat(this, mask, utc);
  };
  w.dateFormat = dateFormat;
}(window));

//Helping classes.
// methods to calculate derived columns.

var SUM = function()
{
  var list = Array.prototype.slice.apply(arguments);
  var total = 0;
  var floatFlag = false;
  for(var i=0; i < list.length; i++)
  {
     if(!isNaN(list[i]))
    {
       if(list[i].toString().indexOf('.') != -1)
         floatFlag = true;
       total += parseFloat(list[i]);
    }
  }

  return floatFlag?parseFloat(parseFloat(total).toFixed(2)):(parseInt(total));
}

// header : used to determine look and feel cells.
var colObj = function(header,colspan,rowspan,value)
{
   this.header = header;
   this.colspan = colspan;
   this.rowspan = rowspan;
   this.value = value;
   return this;
}

// function to create object for columnHash.
var columnObj = function(columnName,type,countColumn,ignore,aggFunction, matrixType)
{
   this.columnName = columnName;
   this.type = type;
   this.countColumn = countColumn;
   this.ignore = ignore;
   this.aggFunction = aggFunction;
   this.matrixType = matrixType;
}

//method to fill filter list.

//TODO: pass number of possible row and columns.
//Note: In case date- columnid is applicable.
//matrix - columnid, rowid.
//date-matrix, all.
var CRGroup = function(rowid, columnid, bucketid, rtype, bucketCount)
{
  this.rowid = rowid;
  this.columnid = columnid;
  this.bucketid = bucketid;
  //TODO: have a flag for this.
  this.autoSequence = (selectedCRQ.columns[columnid].filterList.length > 0);
  this.hidden = false;
  //set hidden flag.
  if(selectedCRQ.columns[columnid].hidden)
    this.hidden = true;

  //create a hash for filterlist and their sequence.
  this.columnEnumSeq = {};
  this.rowEnumSeq = {};
  if(selectedCRQ.columns[columnid].filterList.length > 0)
  {
    var fl = selectedCRQ.columns[columnid].filterList;
    for(var z = 0; z < fl.length; z++)
    {
      this.columnEnumSeq[fl[z]] = z;
    }
  }
  if(rowid != -1)
  {
    if(selectedCRQ.rows[rowid].filterList.length > 0)
    {
      var fl = selectedCRQ.rows[rowid].filterList;
      for(var z = 0; z < fl.length; z++)
      {
        this.rowEnumSeq[fl[z]] = z;
      }
    }
  }
  this.numRow = 1;
  this.numCol = 1;
  if(rtype == "matrix" || rtype == "date-matrix")
  {
    if(selectedCRQ.columns[columnid].metadataFlag)
      this.numCol = selectedCRQ.columns[columnid].filterList.length;
    if(selectedCRQ.rows[rowid].filterList != undefined)
      this.numRow = selectedCRQ.rows[rowid].filterList.length;
  }
  else
  {
    this.numRow = bucketCount;
    if(selectedCRQ.columns[columnid].metadataFlag)
      this.numCol = selectedCRQ.columns[columnid].filterList.length;
  }
  this.derived = false;
  //if currend column is derived one then set derivedFlag true, for current group.
  if(selectedCRQ.columns[columnid].derived == true)
    this.derived = true;

  this.data = new Array(this.numRow);
  this.pctData = new Array(this.numRow);
  for(var z = 0; z < this.numRow; z++)
  {
    this.data[z] = new Array(this.numCol);
    for(var i = 0 ; i < this.data[z].length; i++)
      this.data[z][i] = 0;
    this.pctData[z] = new Array(this.numCol);
    for(var i = 0 ; i < this.pctData[z].length; i++)
      this.pctData[z][i] = 0;
  }
  this.rowTotal = new Array(this.numRow);
  for(var i = 0 ; i < this.rowTotal.length; i++)
    this.rowTotal[i] = NaN;
  this.columnTotal = new Array(this.numCol);
  for(var i = 0 ; i < this.columnTotal.length; i++)
  this.columnTotal[i] = NaN;
  return this;
}



//will be set by transformResult2.
var selectedCRQ = null;
var resultObj = null;
var CRGroupHash = null;
 global.CRQ_PARAMETERS = null;
// transforming result data into table for result table.
//countOnly flag.
var transformResult2 = function(CRQ, result, md)
{
   mode = md;
 //  if(mode == "server")
   //window = global;
   selectedCRQ = CRQ;
   resultObj = result;
   CRQ_PARAMETERS = {}; // resetting crq parameters.
   if(selectedCRQ.reportType == "fixed")
   {
      var result = sortFixedReportResult(resultObj.result);
      return createResultArray(selectedCRQ, result);
   }
  //FIXME: handle it properly.
  //Note: check for metadataflag, if enable then check if countflag is not enable then skip next data column. 
  for(var z = 0; z < selectedCRQ.columns.length; z++)
  {
    if(selectedCRQ.columns[z].metadataFlag == true && selectedCRQ.columns[z].countFlag == false && z < selectedCRQ.columns.length)
    {
      if(selectedCRQ.columns[z+1].metadataFlag == false && selectedCRQ.columns[z+1].countFlag)
      {
        //copy aggregate function to previous one and * that.
        if(!selectedCRQ.columns[z].function || !selectedCRQ.columns[z].function.name)
          selectedCRQ.columns[z].function =  selectedCRQ.columns[z+1].function;
        //remove the next column.
        selectedCRQ.columns.splice(z+1, 1);
        //Need not to update z.
      }
    }

  }

//  var tableData = createReportFormat();  // creating blank table in format.
  var hashForColumn = createResultFormat(resultObj.header); // creating hash table for all the columns.

  //fill filter list if not given.
  fillFilterList(selectedCRQ.columns);
  //fill filterList for derived columns.
  fillDerivedColFilterList();
  for(var z = 0; z < selectedCRQ.rows.length; z++)
  {
    //check if metadata flag is enable for this.
    //FIXME: handling for derived rows.
    if(selectedCRQ.rows[z].metadataFlag == true && selectedCRQ.rows[z].countOnly != true)
    {
      if(selectedCRQ.rows[z].filterList == undefined || selectedCRQ.rows[z].filterList.length == 0)
      {
        selectedCRQ.rows[z].filterList = [];
        if(selectedCRQ.rows[z].derived != true)
          sugIdx = selectedCRQ.rows[z].table.toUpperCase() + ":" + selectedCRQ.rows[z].column.toUpperCase(); 
        else
          sugIdx = "UNDEFINED";
         
        //take suggestion list as filter array.
        if(CRSugD[sugIdx] != undefined && window[CRSugD[sugIdx]] != null && window[CRSugD[sugIdx]].length != 0)
        {
          for(var y = 0; y < window[CRSugD[sugIdx]].length; y++)
          {
            selectedCRQ.rows[z].filterList.push(window[CRSugD[sugIdx]][y].name);
          } 
        }
      }
    }
  }
  CRGroupHash = createCRGroups();
  resultObj.CRGroupHash = CRGroupHash;
  populateResult(hashForColumn, CRGroupHash);
  //populate CRQ_PARAMETERS.
  if(resultObj.parameters)
  {
    for(var h in resultObj.parameters)
    {
      CRQ_PARAMETERS[h] = resultObj.parameters[h];
    }
  }
  populateDerivedColumn(CRQ_PARAMETERS);
  if(mode != "server")
   apply_front_end_filter(); 
  //if report is matrix type then sort on rows also.
  if(mode != "server" && selectedCRQ.reportType.indexOf('matrix') != -1)
     sortRowSeqNew();
  sortColSeq();
  updateEnumSeq();
 /* if(mode != "server") 
  {
    createTableHeader(resultObj.CRGroupHash);
    fillTableData();
  }
  else */
   if(selectedCRQ.reportType.toLowerCase() == "template")
       return resultObj;
   return createResultArray(selectedCRQ, resultObj);
}

var updateEnumSeq = function()
{
  for(var h in selectedCRQ.CRGroupHash)
  {
    var columnid = selectedCRQ.CRGroupHash[h].columnid;
    selectedCRQ.CRGroupHash[h].columnEnumSeq = {};
    if(selectedCRQ.columns[columnid].filterList.length > 0)
    {
      var fl = selectedCRQ.columns[columnid].filterList;
      for(var z = 0; z < fl.length; z++)
      {
        selectedCRQ.CRGroupHash[h].columnEnumSeq[fl[z]] = z;
      }
    }

    //update row enumSeq.
    var rowid = selectedCRQ.CRGroupHash[h].rowid;
    if(rowid == -1) continue;
    selectedCRQ.CRGroupHash[h].rowEnumSeq = {};
    if(selectedCRQ.rows[rowid].filterList.length > 0)
    {
      var fl = selectedCRQ.rows[rowid].filterList;
      for(var z = 0; z < fl.length; z++)
      {
        selectedCRQ.CRGroupHash[h].rowEnumSeq[fl[z]] = z;
      }
    }
  }
}


//This method will sort the group columns on basis of column Counts.
//And will update filterList according to that.
//Issue: there may be multiple CRSeq with that Column, we need to combine them and create a temp Array having columnTotal.
//And then sort them in group.
var sortColSeq = function()
{
  var crGroups = [];
  for(var z = 0; z < selectedCRQ.columns.length; z++)
  {
    //TODO: autoSequence flag should be enabled then only sort them.
    if(selectedCRQ.columns[z].filterList.length == 0)
      continue;

    crGroups = [];
    for(var cr in resultObj.CRGroupHash)
    {
      if(resultObj.CRGroupHash[cr].columnid == z)
        crGroups.push(resultObj.CRGroupHash[cr]);  
    }

    //create a temporary coltotal. 
    var columnTotal = new Array(selectedCRQ.columns[z].filterList.length); 
    for(var q= 0; q < columnTotal.length; q++)
    columnTotal[q] = 0;
    for(var y = 0; y < crGroups.length; y++)
    {
      for(var x = 0; x < selectedCRQ.columns[z].filterList.length; x++)
      {
        columnTotal[x] += crGroups[y].columnTotal[x];  
      }
    }
   
    //now create a temp array of object(prev seq, and total)
    var tmpArray = new Array(columnTotal.length);
    for(var y = 0; y < columnTotal.length; y++)
    {
      tmpArray[y] = {"count": columnTotal[y], "prevId": y};
    } 
   
    //sort this array on count.  
    tmpArray.sort(function(A, B){return (B.count - A.count);}); 
    
    //now it's time to sort all other ****. 
    for(var y = 0; y < crGroups.length; y++)
    {
      //create a copy of 2d array and filterList.
      crGroups[y].dupData = new Array(crGroups[y].numRow);
      crGroups[y].dupColumnTotal = new Array(crGroups[y].columnTotal.length);
      for(var t = 0; t < crGroups[y].numRow; t++)
      {
        crGroups[y].dupData[t] = new Array(crGroups[y].numCol);
        for(var q= 0; q <  crGroups[y].dupData[t].length; q++)
             crGroups[y].dupData[t][q] = 0;
      }
      //for first crgroup update filterlist for that column.
      if(y == 0)
      {
        selectedCRQ.columns[z].dupFilterList = new Array(selectedCRQ.columns[z].filterList.length);
        for(var t = 0; t < selectedCRQ.columns[z].filterList.length; t++)
          selectedCRQ.columns[z].dupFilterList[t] = selectedCRQ.columns[z].filterList[tmpArray[t].prevId];
        //update prev one.
        selectedCRQ.columns[z].filterList = selectedCRQ.columns[z].dupFilterList;
      }
     
      for(var n = 0; n < crGroups[y].numRow; n++)
      {
        for(var t = 0; t < crGroups[y].numCol/*column count*/; t++)       
        {
          if(n == 0)
            crGroups[y].dupColumnTotal[t] = crGroups[y].columnTotal[tmpArray[t].prevId];
          crGroups[y].dupData[n][t] = crGroups[y].data[n][tmpArray[t].prevId]; 
        }
      }
      //now reset old data.
      crGroups[y].data = crGroups[y].dupData;
      crGroups[y].columnTotal =  crGroups[y].dupColumnTotal;
    }
  }
}


var getDerivedFunction = function(expr)
{
  //get list of variables.
  var args = expr.match(/\$[0-9a-zA-Z.]+/g) ||[];
  //TODO: uniq this array.
  args = uniqueArray(args);
  var newArgList = [];
  for(var z = 0; z < args.length; z++)
  {
    //escape $.
    var colReg = new RegExp(args[z].replace('$', '\\$'), 'g');
    expr = expr.replace(colReg, 'var' + (z+1));
    newArgList.push('var' + (z+1));
  }
  var f = Function(newArgList.join(','), "return " + expr);
  return f;
}



//first get list of dependent column.
var populateDerivedColumn = function(CRQ_PARAMETERS)
{
  var crGroups = [];
  var colid;
  var SCc = selectedCRQ.columns;
  var crGroup;
  var depCRGroup = [];
  var depSubColIdx = [];  //both these arrary are parallel. //this will have sub col index.
  var depCol = []; //array having derived col.//Note: this can be sub column also.
  var derivedColFn;
  var derivedColIdx;
  var depColValues;
  for(var z = 1; z <= resultObj.totalDerivedCol; z++) 
  {
    crGroups = [];
    depCRGroup = [];
 
    derivedColIdx = -1;
    //get index of derived column. 
    //TODO: create hash for columns, to get index.
    for(var x = 0; x < SCc.length; x++)
    {
      if(SCc[x].table.toUpperCase() == "DERIVED" && (SCc[x].column.toUpperCase() == "DERIVED" + z))
      {
        derivedColIdx = x;
        break;
      }
    }
     
    if(derivedColIdx == -1) {
      continue;
    }

    //get all cgGroup Having this column.  
    //Note: compare rowid and bucketid also.
    var colName;
    for(h in resultObj.CRGroupHash)
    {
      colid = resultObj.CRGroupHash[h].columnid;
      colName = SCc[colid].column.toUpperCase(); 

      if(SCc[colid].table.toUpperCase() == "DERIVED" && (colName == "DERIVED" + z))
      {
        crGroup = resultObj.CRGroupHash[h];
      }
      else continue;
      
      //get dependent columns. 
      depCol = getDerivedDepCol(SCc[derivedColIdx].exp); 
      //get depCRGroup and actual column and subcolumn index if single column if sub column selected.  

      depCRGroup = [];
      depSubColIdx = [];
      var rowid, bucketid, dupColId;
      for(var m = 0; m < depCol.length; m++)
      {
        for(var crg in resultObj.CRGroupHash)
        {
          colid = resultObj.CRGroupHash[crg].columnid;
          rowid = resultObj.CRGroupHash[crg].rowid;
          bucketid = resultObj.CRGroupHash[crg].bucketid;
          dupColId = -1;
          if(depCol[m].split('.').length > 2)
            dupColId = depCol[m].split('.')[2]; 

          //compare rowid and bucketid also if valid.
          //FIXME: it;s better to make id required.
          if((SCc[colid].table.toUpperCase() == depCol[m].split('.')[0] && SCc[colid].column.toUpperCase() == depCol[m].split('.')[1]) && (rowid == -1 || rowid == crGroup.rowid) && (bucketid == -1 || bucketid == crGroup.bucketid) && (!SCc[colid].id || (SCc[colid].id == dupColId || SCc[colid].derived)))
          {
            depCRGroup.push(resultObj.CRGroupHash[crg]);
            depSubColIdx[m] = -1;
            //Now check for third argument.(sub col index.)
            //Note: this should happen only if metadata flag is false.
            var vector;
            if(depCol[m].split('.').length > 2)  //if third argument present.
            {
              //check this third argument in filter list of dependent CRGroup.
              vector = depCol[m].split('.')[2];
              for(var k = 0; k < SCc[colid].filterList.length; k++)
              {
                if(vector == SCc[colid].filterList[k]) 
                {
                  depSubColIdx[m] = k;
                  break;
                }
              }
            } 
          }
        }
      }
      
      //update this crGroup. 
      //get function for this dependent CRGroup.
      derivedColFn = getDerivedFunction(SCc[derivedColIdx].exp);
      //get number of rows in selected CRQ.
      for(var i = 0; i < crGroup.numRow; i++)      
      {
        for(var j = 0; j < crGroup.numCol; j++)
        {
          depColValues = [];
          for(var k = 0; k < depCRGroup.length; k++)
          {
            //now fill the data.
            if(depSubColIdx[k] != -1)
              depColValues.push(depCRGroup[k].data[i][depSubColIdx[k]]);
            else
              depColValues.push(depCRGroup[k].data[i][j]);
          }
          //here depColValues filled, then just derive the values. 
          try {
            crGroup.data[i][j] = parseFloat(derivedColFn.apply(global, depColValues)).toFixed(2); 
          }
          catch(e)
          {
            //FIXME: handle this case properly.
            crGroup.data[i][j] = 0;
          } 
          //update row total and column total. 
          if(isNaN(crGroup.data[i][j]) == false)
          {
            update_total_counters(crGroup, i, j, crGroup.data[i][j]);
          } 
          else 
            crGroup.data[i][j] = 0;
        }
      }
    } 
  }
}




var populateResult = function(hashForColumn,  crGroupHash)
{
  var dateid = -1, rowid, columnid, columnsname, dataid;
  var columnName = null, rowName = null; 
  var columnVectorName = null, rowVectorName = null;
  var result = resultObj.result;
  var rtype = selectedCRQ.reportType;
  var crGroup, crGroupKey;
  var rowCol, columnCol;
  for(var z = 0; z < result.length; z++)
  {
/*
    if(!hashForColumn.hasOwnProperty(z))
    {
      console.error("Some critical error occured.");
      return -1;
    }
*/

    rowid = columnid = dateid = dataid = -1;
    //reset all the ***.
    rowName = columnName = rowVectorName = columnVectorName = null; 
    for(var y = 0; y < result[0].length; y++)
    {
      //skip first column in case of matrix report.
      if(rtype == "matrix" && y == 0) continue;
      if(result[z][y] == null) continue;

      if(y == 0 && (rtype == "date" || rtype == "date-matrix")) 
      {
        dateid = result[z][0];
        if(rtype == "date")
        {
          rowid = dateid;
          continue;     
        }
        continue;
      }

      if(hashForColumn[y].ignore == true) continue;

      {
        dataid = y;
        //Note: In hashForColumn we will fill matrixType.(row|column)
        //Note: data will always be in next column so no need to save data value in any variable.
        if(hashForColumn[y].matrixType == "row")
        {
          if(rowName == null)
          {
            rowCol = y;
            rowName = hashForColumn[y].columnName;
            if(hashForColumn[y].type == "METADATA")
            {
              rowVectorName = result[z][y];
              dataid = hashForColumn[y].countColumn;
            }
          }
        }
        else {
          if(columnName == null)
          {
            columnCol = y;
            columnName = hashForColumn[y].columnName;
            if(hashForColumn[y].type == "METADATA")
            {
              columnVectorName = result[z][y];
              dataid = hashForColumn[y].countColumn;
            }
          }
        }
      }
      //Check if we get sufficient information to fill data.
      if(rtype == "date" && columnName != null)
      {
        //check for group.
        if(crGroupHash.hasOwnProperty(columnName))        
        {
          crGroup = crGroupHash[columnName]; 
          if(crGroup.derived == true)
            continue;

          //Note: We differentiating metadata and data by vectors. If null that means it's data only.
          if(columnVectorName != null)
          {
            //check for filterlist.
            columnid = crGroup.columnEnumSeq[columnVectorName]; 
            if(columnid == undefined) {
              //reset other data and continue.
              columnName = rowName = columnVectorName = rowVectorName = null;
              continue;
            }
          }
          else 
            columnid = 0;  //this is the only one column.
          rowid = dateid;
          //fill data.
          //Note: to avoid duplicate data.
          //TODO: move into a function
          if(crGroup.data[rowid][columnid] == 0)
          {
            crGroup.data[rowid][columnid] = parseFloat(result[z][dataid]).toFixed(2); 
            //TODO: handling for pct.
            if(!isNaN(crGroup.data[rowid][columnid]))
            {
              //Note: first check for aggregate function.
              update_total_counters(crGroup, rowid, columnid, result[z][dataid]);
            }
          }
        }
        //reset 
        columnName = rowName = columnVectorName = rowVectorName = null;
        continue;
      }
      else if((rtype == "matrix" || rtype == "date-matrix") && (columnName != null || rowCol != y) && rowName != null)
      {
        //get crGroup.  
        crGroupKey = rowName + ":" + columnName;       
        if(rtype == "date-matrix")
          crGroupKey = dateid + ":" + crGroupKey;
        //check for grGroup.
        if(crGroupHash.hasOwnProperty(crGroupKey))
        {
          crGroup = crGroupHash[crGroupKey];

          if(crGroup.derived == true)
            continue;

          if(columnVectorName != null)
          {
            //check for filterlist.
            columnid = crGroup.columnEnumSeq[columnVectorName]; 
            if(columnid == undefined) {
              //reset other data and continue.
              columnName = rowName = columnVectorName = rowVectorName = null;
              continue;
            }
          }
          else 
            columnid = 0;  //this is the only one column.

          //same way get rowid.
          if(rowVectorName != null)
          {
            //check for filterlist.
            rowid = crGroup.rowEnumSeq[rowVectorName]; 
            if(columnid == undefined) {
              //reset other data and continue.
              columnName = rowName = columnVectorName = rowVectorName = null;
              continue;
            }
          }
          else 
            rowid = 0;  //this is the only one column.

          if(rowid == undefined || rowid == null || columnid == undefined || columnid == null) 
            continue;
         
          //fill data.         
          if(crGroup.data[rowid][columnid] == 0)
          {
            crGroup.data[rowid][columnid] = parseFloat(result[z][dataid]).toFixed(2); 
            //TODO: handling for pct.
            if(!isNaN(crGroup.data[rowid][columnid]))
            {
              //Note: first check for aggregate function.
              update_total_counters(crGroup, rowid, columnid, (result[z][dataid]));
            }
          }
        }
        columnName = rowName = columnVectorName = rowVectorName = null;
        rowCol = columnCol = -1;
      } 
    }
  }    
}

var apply_front_end_filter = function()
{
  var cg = resultObj.CRGroupHash;
  var f_filter = get_front_end_filter(); //getting column filters.
  for(var z = 0; z < f_filter.length; z++)
  {
    f_filter[z].operator = f_filter[z].operator.replace("&gt;",">").replace("&lt;","<");
    //get all cr group having this operand.
    for(k in cg)
    {
      // taking the column group to apply col filter.
      if(k.indexOf(f_filter[z].column) > -1)
      {
         for(var a = 0; a < cg[k].data.length; a++)
         {
           if(cg[k].data[a] == undefined) continue;
           var valid = true;
           for(var b = 0; b < cg[k].data[a].length; b++)
           {
             if(f_filter[z].type == "int")
               valid = eval( parseInt(cg[k].data[a][b])+" "+f_filter[z].operator+" "+parseInt(f_filter[z].value));
             else if(f_filter[z].type == "float")
               valid = eval(parseFloat(cg[k].data[a][b]) +" "+f_filter[z].operator+" "+parseFloat(f_filter[z].value));
             else
               valid = eval(cg[k].data[a][b] +" "+f_filter[z].operator+" "+f_filter[z].value);
             if(!valid) // if any sub column is not valid complete row is ignored including rowtotal.
             {
               // clearing values not valid to the filters.
               cg[k].data[a] = undefined;
               cg[k].rowTotal[a] = undefined;
               if(selectedCRQ.rows[cg[k].rowid].filterList && selectedCRQ.rows[cg[k].rowid].filterList.length > 0)
                 selectedCRQ.rows[cg[k].rowid].filterList[a] = undefined; // removing the sub column from filterlist.
               for(m in cg)
               {
                   //checking for the value to be eliminated from all the crgroups.
                   if(cg[k].bucketid == cg[m].bucketid && cg[k].rowid == cg[m].rowid)
                   {
                      cg[m].data[a] = undefined;
                      cg[m].rowTotal[a] = undefined;
                   }
               }

               break;
             }
           }
         }
      }
    }
  }
  // removing undefined  values from all the cr groups.
  for(c in cg)
  {
    var rt = [];
    var dt = [];
    for(var a = 0; a < cg[c].data.length; a++)
    {
      if(cg[c].data[a] != undefined)
      {
        dt.push(cg[c].data[a]);
      }
      if(cg[c].rowTotal[a] != undefined)
        rt.push(cg[c].rowTotal[a]);
    }
    cg[c].data = dt;
    cg[c].rowTotal = rt;
    cg[c].numRow = cg[c].rowTotal.length;
    cg[c].numCol = cg[c].data[0].length;
    var crGroups = resultObj.CRGroupHash;
    var y = c;
    var aggFunc = "COUNT";
    if(selectedCRQ.columns[crGroups[y].columnid].function)
        aggFunc = selectedCRQ.columns[crGroups[y].columnid].function.name;
    crGroups[y].columnTotal = new Array(crGroups[y].numCol);
    crGroups[y].columnTotal.fill(NaN);
    for(var x = 0; x < crGroups[y].data.length; x++)
          {
            for(var l = 0; l < crGroups[y].data[x].length; l++)
            {
              //update column total.
              switch(aggFunc)
              {
                case "MIN":
                  crGroups[y].columnTotal[l] = MIN(crGroups[y].columnTotal[l], crGroups[y].data[x][l]);
                  break;
                case "MAX":
                  crGroups[y].columnTotal[l] = MAX(crGroups[y].columnTotal[l], crGroups[y].data[x][l]);
                  break;
                case "AVG":
                case "SUM":
                case "COUNT":
                default:
                  crGroups[y].columnTotal[l] = SUM(crGroups[y].columnTotal[l], crGroups[y].data[x][l]);
              }
            }
          }
     //If this was case of AVG then compute do the average at this point.
          if(aggFunc == "AVG")
          {
          for(var x = 0; x < crGroups[y].numCol; x++)
          {
            crGroups[y].columnTotal[x] = parseFloat(crGroups[y].columnTotal[x]/crGroups[y].numRow).toFixed(2);
          }
          }

  }
  for(var a = 0; a < selectedCRQ.rows.length;a++)
  {
    if(!selectedCRQ.rows[a].metadataFlag) continue;
    var fl = [];
    for(var b = 0; b < selectedCRQ.rows[a].filterList.length; b++)
    {
        if(selectedCRQ.rows[a].filterList[b] != undefined)
          fl.push(selectedCRQ.rows[a].filterList[b]);
    }
    selectedCRQ.rows[a].filterList = fl;
  }
}

var AVERAGE = function()
{
  var list = Array.prototype.slice.apply(arguments);
  var total = 0;
  var validEntry = 0;
  var floatFlag = false; 
  for(var i=0; i < list.length; i++)
  {
    if(!isNaN(list[i]))
    {
      if(list[i].toString().indexOf('.') != -1)
        floatFlag = true;
      total += parseFloat(list[i]);
      validEntry++;
    }
  }
 
  total = floatFlag?parseFloat((parseFloat(total).toFixed(2))):(parseInt(total));
  
  return validEntry > 0?total/validEntry:0;
}

var MAX = function()
{
   var list = Array.prototype.slice.apply(arguments);
   var max = 0;
   for(var i=1;i < list.length; i++)
   {
     if(!isNaN(list[i]))
     {
       if(max < list[i])
         max = list[i];
     }
   }
   return max;
}

var MIN = function()
{
   var list = Array.prototype.slice.apply(arguments);
   var min = Number.MAX_SAFE_INTEGER;
   for(var i=1;i < list.length; i++)
   { 
     if(!isNaN(list[i]))
     {
       if(min > list[i])
         min = list[i];
     }
   }
   return min;
}


//FIXME: handle average properly.
var update_total_counters = function(crGroup, rowid, columnid, value)
{
 
  //check for agg function.
  var colAggFunction = "COUNT";
  var colid;
  if(crGroup.columnid != -1)
  {
    colid = crGroup.columnid;
    if(selectedCRQ.columns[colid].function && selectedCRQ.columns[colid].function.name)
      colAggFunction = selectedCRQ.columns[colid].function.name;
  }

  switch(colAggFunction)
  {
    case "MAX":
      if(!isNaN(crGroup.rowTotal[rowid]))
        crGroup.rowTotal[rowid] = MAX(crGroup.rowTotal[rowid], value);    
      else
        crGroup.rowTotal[rowid] = value;
      if(!isNaN(crGroup.columnTotal[columnid])) 
        crGroup.columnTotal[columnid] = MAX(crGroup.columnTotal[columnid], value);
      else
        crGroup.columnTotal[columnid] = value;
      break;
    case "MIN":
      if(!isNaN(crGroup.rowTotal[rowid]))
        crGroup.rowTotal[rowid] = MIN(crGroup.rowTotal[rowid], value);    
      else 
        crGroup.rowTotal[rowid] = value;
      if(!isNaN(crGroup.columnTotal[columnid]))
        crGroup.columnTotal[columnid] = MIN(crGroup.columnTotal[columnid], value);
      else
        crGroup.columnTotal[columnid] = value;
      break;
    case "AVG":
      if(!isNaN(crGroup.rowTotal[rowid]))
        crGroup.rowTotal[rowid] = AVERAGE(crGroup.rowTotal[rowid], value);    
      else 
        crGroup.rowTotal[rowid] = value;
      if(!isNaN(crGroup.columnTotal[columnid]))
        crGroup.columnTotal[columnid] = AVERAGE(crGroup.columnTotal[columnid], value);
      else 
        crGroup.columnTotal[columnid] = value;
      break;
    case "SUM":
    case "COUNT":
    default:
      if(!isNaN(crGroup.rowTotal[rowid]))
        crGroup.rowTotal[rowid] = SUM(crGroup.rowTotal[rowid], value);    
      else 
        crGroup.rowTotal[rowid] = value;
      if(!isNaN(crGroup.columnTotal[columnid]))
        crGroup.columnTotal[columnid] = SUM(crGroup.columnTotal[columnid], value);
      else
        crGroup.columnTotal[columnid] = value;
  }
}

//TODO: make it generic for row and column.
var fillFilterList = function(columns)
{
  var sugIdx;
  //TODO: create a function for filling filterList.
  //Note: this loop wil 
  for(var z = 0; z < columns.length; z++)
  {
    //check if metadata flag is enable for this.
    //FIXME: handling for derived columns.
    //TODO: in case of derived column, If there is column having enums then metadataFlag will be set.
    if(columns[z].metadataFlag == true && columns[z].countOnly != true)
    {
      if(columns[z].filterList == undefined || columns[z].filterList.length == 0)
      {
        columns[z].filterList = [];
        if(columns[z].derived != true)
          sugIdx = columns[z].table.toUpperCase() + ":" + columns[z].column.toUpperCase(); 
        else
        {
          sugIdx = "UNKNOWN";
        }
        //take suggestion list as filter array.
        if(CRSugD[sugIdx] != undefined && window[CRSugD[sugIdx]] != null && window[CRSugD[sugIdx]].length != 0)
        {
          for(var y = 0; y < window[CRSugD[sugIdx]].length; y++)
          {
            columns[z].filterList.push(window[CRSugD[sugIdx]][y].name);
          } 
        }
      }
    }
  }
}

var fillDerivedColFilterList = function()
{
  //get all the derived columns and sort them into increasing order.
  var derivedCol = {};
  var totalDerivedCol = 0;
  var sCc = selectedCRQ.columns;
  var did;
  //fill derived Col seq.
  var derivedColSeq = {}; //this is the actual seq in crq.
  //TODO: in case of derived table name wiill be derived and column name derived1
  for(var z = 0; z < sCc.length; z++)
  {
    if(sCc[z].table.toUpperCase() == "DERIVED" && sCc[z].column.toUpperCase().indexOf("DERIVED") != -1)
    {
      did = parseInt(sCc[z].column.substr("DERIVED".length)); 
      if(isNaN(did) == false && did > totalDerivedCol)
      {
        totalDerivedCol = did;
        derivedColSeq[did] = z;
      }
    }
  }

  resultObj.totalDerivedCol = totalDerivedCol;
 
  //traverse all the deried col and fill their filter list.
  var x;
  var depColSeq;
  var depCol; //array  of dependent column.
  for(var m = 1; m < totalDerivedCol + 1; m++)
  {
    //get actaul seq.
    x = derivedColSeq[m];
    if(x === undefined) continue;

    //if metadataflag is on.
    if(sCc[x].metadataFlag != true) continue;

    //get dep col.
    depCol = getDerivedDepCol(sCc[x].exp); 
    //now check if we have filterlist in any shit.
    var numField;
    for(var z = 0; z < depCol.length; z++)
    {
      //get depCol.
      numField = depCol[z].toString().split('.').length;
      if(numField < 2) {
        continue;
      }
      depColSeq = -1;
      for(var k = 0; k  < sCc.length; k++) 
      {
        if(numField == 2)
        {
          if(sCc[k].table.toUpperCase() == depCol[z].split('.')[0].toUpperCase() && sCc[k].column.toUpperCase() == depCol[z].split('.')[1].toUpperCase())
         {
           depColSeq = k;
           break;
         }
       }
       else {
          //In case of same db column , we wil differentiate by id.
          if(sCc[k].table.toUpperCase() == depCol[z].split('.')[0].toUpperCase() && sCc[k].column.toUpperCase() == depCol[z].split('.')[1].toUpperCase() && sCc[k].column.id == depCol[z].split('.')[2])
         {
           depColSeq = k;
           break;
         }

       }
      }
      //Failed to get seq.
      if(depColSeq == -1) continue;

      //check if filterlist present for this. 
      if(sCc[depColSeq].filterList !== undefined && sCc[depColSeq].filterList.length > 0)
      {
        sCc[x].filterList = sCc[depColSeq].filterList.slice(); 
        break;
      }      
    }
  }
}

var getDerivedDepCol = function(expr)
{
  var args = expr.match(/\$[0-9a-zA-Z.]+/g) ||[];
  args = uniqueArray(args);
  var newArgList = [];
  for(var z = 0; z < args.length; z++)
  {
    args[z] = args[z].replace("$","");
    newArgList.push(args[z]);
  }
  return newArgList;
}


var createResultFormat = function(resultHeader)
{
  var ignore = false;
  var countColumn;
  var columnHash = {};
  //Ignore next column of metadata column of type column.
  for(var z = 0; z < resultHeader.length; z++)
  {
    countColumn = z;
    //In case of metadata column it should be next column.
    if(resultHeader[z].columnType == "METADATA")
      countColumn = z+1;
    columnHash[z] = new columnObj(resultHeader[z].columnName, resultHeader[z].columnType, countColumn, ignore, resultHeader[z].aggFunction, resultHeader[z].matrixType);    

    //reset ignore.
    ignore = false;

    //If matrixtype column and column type metadata then enable ignore true.
    if(resultHeader[z].matrixType == "column" && resultHeader[z].columnType == "METADATA")
      ignore = true;
  }
  return columnHash;
}



//Now complete report will be sub divided in sub groups.
//Each group will have it's own graph.
//Sorting will be on each group.
//
//Number of groups:
//Date Report: num of columns.
//Matrix Report: Num of Rows X Num of Columns.
//Date-Matrix: Total Bucket * Number of Rows * Number of Column.
var createCRGroups = function()
{
  var CRGroupHash = {};
  var key;
  //This is number of data buckets.
  //Applicable only for data and date-matrix report.
  var bucketCount = Math.ceil(parseFloat(((selectedCRQ.queryArg.endTime) - (selectedCRQ.queryArg.startTime)) / parseInt(selectedCRQ.queryArg.bucketHrs * 3600)));
  if(selectedCRQ.reportType == "date")
  {
    for(var z = 0; z < selectedCRQ.columns.length; z++)
    {
      //if totalCountColumn then ignore it.  
      //TODO: check if we should create an entry for totalCountColumn
      if(selectedCRQ.columns[z].totalCountColumn == true)
        continue;
      key = selectedCRQ.columns[z].table.toUpperCase() + "." + selectedCRQ.columns[z].column.toUpperCase();
      if(selectedCRQ.columns[z].hasOwnProperty('id')) // for same db columns.
        key += "."+selectedCRQ.columns[z].id;       
      CRGroupHash[key] = new CRGroup(-1, z, -1, "date", bucketCount);
    }
  }
  else if(selectedCRQ.reportType == "matrix")
  {
    //In this case there will numRow*numCol groups. 
    //key format will be: RowName:ColumnName
    for(var z = 0; z < selectedCRQ.rows.length; z++)
    {
      for(var y = 0; y < selectedCRQ.columns.length; y++)
      {
        if(selectedCRQ.columns[y].totalCountColumn == true)
          continue;
  
        //TODO: For derived column take Derived as table name.
        key = selectedCRQ.rows[z].table.toUpperCase()+ "." + selectedCRQ.rows[z].column.toUpperCase() + 
            ":" +
            selectedCRQ.columns[y].table.toUpperCase() + "." + selectedCRQ.columns[y].column.toUpperCase();
        if(!selectedCRQ.columns[y].derived && selectedCRQ.columns[y].hasOwnProperty('id'))
           key += "."+selectedCRQ.columns[y].id;
        CRGroupHash[key] = new CRGroup(z, y, -1, "matrix", bucketCount);

      }
    }
  }
  else if(selectedCRQ.reportType == "date-matrix")
  {
    for(var z = 0; z < bucketCount; z++)
    {
      for(var y = 0; y < selectedCRQ.rows.length; y++)
      {
        for(var x = 0; x < selectedCRQ.columns.length; x++)
        {
          if(selectedCRQ.columns[x].totalCountColumn == true)
            continue;
  
          //TODO: For derived column take Derived as table name.
          key = z + ":" + selectedCRQ.rows[y].table.toUpperCase()+ "." + selectedCRQ.rows[y].column.toUpperCase() + 
            ":" +
            selectedCRQ.columns[x].table.toUpperCase() + "." + selectedCRQ.columns[x].column.toUpperCase();
          if(!selectedCRQ.columns[x].derived && selectedCRQ.columns[x].hasOwnProperty('id'))
             key += "."+selectedCRQ.columns[x].id;
          CRGroupHash[key] = new CRGroup(y, x, z, "date-matrix", bucketCount);

        }
      }
    }
  }
  return CRGroupHash; 
}


// creating 2D result array for xcel workbook.
var createResultArray = function(selectedCRQ, resultObj)
{
  
  var sc = selectedCRQ; 
  var cg = null;
  var result = [];  
  if(sc.reportType != "fixed"){
    cg = resultObj.CRGroupHash;
  // filling column and sub-column headers.
  result[0] = [];
  result[1] = [];
  if(sc.reportType.indexOf("date") > -1)
     result[0].push(new colObj(true,1,2,"Date/Time"));
  if(sc.reportType.indexOf("matrix") > -1)
  {
     //In case of storeid column we may have multiple columns for row headers so updating.
    if(selectedCRQ.rows[0].attributes)
    {
      if(selectedCRQ.rows[0].attributes.length > 0)
        result[0].push(new colObj(true,selectedCRQ.rows[0].attributes.length,2,""));
    }
    else
        result[0].push(new colObj(true,2,2,""));
  }
  
  for(var a = 0; a < sc.columns.length; a++)
  {
     if(sc.columns[a].hidden) // if column is hidden then skipping it.
       continue;
     // adjusting colspan and row span for data and metadata column and sub columns.
     var colspan = (sc.columns[a].metadataFlag) ? ((sc.columns[a].filterList.length > 1) ? sc.columns[a].filterList.length+1 : 1) : 1;
     var rowspan = (sc.columns[a].metadataFlag) ? 1 : 2;
     result[0].push(new colObj(true,colspan,rowspan,sc.columns[a].name));
     if(sc.columns[a].metadataFlag)
     {
        for(var b = 0; b < colspan; b++)
        {
          if( colspan != 1 && b == colspan - 1)
            result[1].push(new colObj(true,1,1,"Row Total"));
          else
          {
            result[1].push(new colObj(true,1,1,sc.columns[a].filterList[b]));
          }
        }
     }
  }
  // for date and date matrix report getting date format and row count. 
  var bucketCount = Math.ceil(parseFloat(((sc.queryArg.endTime/1000) - (sc.queryArg.startTime/1000)) / parseInt(sc.queryArg.bucketHrs * 3600)));
  var dtFormat = "d mmm";
  if(sc.queryArg.bucketHrs == 1)
     dtFormat = "dd/mm/yy, HH:00";
  }
  // filling data rows acc. to report type.
  if(sc.reportType == "date") // for date report
  {
    var ct = [new colObj(true,1,1,"Column Total")];
   // for(var v = bucketCount-1; v >= 0; v--)
    for(var v = 0; v < bucketCount; v++)
    {
        var row = [];
        var now = new Date(parseInt(selectedCRQ.queryArg.startTime) + v * selectedCRQ.queryArg.bucketHrs * 3600000);
        row.push(new colObj(true,1,1,window.dateFormat(now, dtFormat))); 
        for(var b = 0; b < sc.columns.length; b++)
        {
          if(selectedCRQ.columns[b].hidden == true)
            continue;

          if(selectedCRQ.columns[b].totalCountFlag == true)
            continue;

          var key = (sc.columns[b].table +"."+ sc.columns[b].column).toUpperCase();
          if(!sc.columns[b].derived)
                key += "." + sc.columns[b].id;
          for(var n = 0; n < cg[key].data[v].length; n++)
          {
            if(sc.columns[b].dataType == "float")
             row.push(new colObj(false,1,1,parseFloat(cg[key].data[v][n])));
            else
             row.push(new colObj(false,1,1,parseInt(cg[key].data[v][n])));
          }
          if(sc.columns[b].metadataFlag)
          {
               if(isNaN(cg[key].rowTotal[v]))
                 row.push(new colObj(false,1,1,0));
               else
                 row.push(new colObj(false,1,1,cg[key].rowTotal[v]));
          }
          if(v == 0)
          {
            var tot = 0;
            for(var m =0; m < cg[key].columnTotal.length; m++)
            {
              if(!isNaN(cg[key].columnTotal[m]))
              tot += parseInt(cg[key].columnTotal[m]);
              ct.push(new colObj(false,1,1,cg[key].columnTotal[m]));
            }
            ct.push(new colObj(false,1,1,tot));
          }
            
        }
        result.push(row);
    }
    result.push(ct); 
  }
  else if(sc.reportType == "matrix") // for matrix report
  {
     // using a loop for rows but expecting only one row for each matrix or date - matrix report.
     for(var a = 0; a < sc.rows.length; a++)
     {
       var crGroupKey = (sc.rows[a].table +"."+ sc.rows[a].column).toUpperCase();
       if(sc.rows[a].metadataFlag)
       {

         for(var b = -1; b < sc.rows[a].filterList.length; b++)
         {
           var row = [];
           // currently using attributes only in case of stores. can be used for all rows later.
           if(sc.rows[a].attributes)
           {
             if(b == -1)
             {
               for(var c = 0;c < selectedCRQ.rows[a].attributes.length;c++)
                 row.push(new colObj(true,1,1,selectedCRQ.rows[a].attributes[c].name));
               for(var x = 0; x < sc.columns.length; x++)
               {
                 if(sc.columns[x].hidden) continue;
                 // creating crGroup name.
                 var key = crGroupKey +":"+(sc.columns[x].table +"."+ sc.columns[x].column).toUpperCase();
                 if(!sc.columns[x].hasOwnProperty("derived"))
                    key += "." + sc.columns[x].id;
                  
                 for(var f = 0; f < cg[key].columnTotal.length; f++)
                 {
                    row.push(new colObj(false,1,1,(isNaN(cg[key].columnTotal[f])) ? 0 : cg[key].columnTotal[f]));  // adding column total.
                 }
               }
             }
             else
             {
                for(var d = 0;d < selectedCRQ.rows[a].attributes.length;d++)
                {
                  try {
                         row.push(new colObj(true,1,1,CompleteStoreInfo[selectedCRQ.rows[a].filterList[b]][selectedCRQ.rows[a].attributes[d].dbname.toUpperCase()]));
                  }
                  catch(e) {
                         row.push(new colObj(true,1,1,"-"));
                  }
                }
               for(var x = 0; x < sc.columns.length; x++)
               {
                  if(sc.columns[x].hidden) continue;
                // creating crGroup name.
                 var key = crGroupKey +":"+(sc.columns[x].table +"."+ sc.columns[x].column).toUpperCase();
                 if(!sc.columns[x].derived)
                    key += "." + sc.columns[x].id;


                 for(var f = 0; f < cg[key].data[b].length; f++)
                 {
                   if(sc.columns[x].dataType == "float") 
                      row.push(new colObj(false,1,1,parseFloat(cg[key].data[b][f])));  // adding column data.
                   else
                      row.push(new colObj(false,1,1,parseInt(cg[key].data[b][f])));
                 }
               }
             }               
           } // in case of no attributes.
           else
           {
              if(b == -1)
              {
                 row.push(new colObj(true,1,1,selectedCRQ.rows[a].name));
                 row.push(new colObj(true,1,1,"Column Total"));
                 for(var e = 0; e < sc.columns.length; e++)
                 {
                 if(sc.columns[e].hidden)  continue;
                 // creating crGroup name.
                 var key = crGroupKey +":"+(sc.columns[e].table +"."+ sc.columns[e].column).toUpperCase();
                 if(!sc.columns[e].derived)
                    key += "." + sc.columns[e].id;


                  for(var f = 0; f < cg[key].columnTotal.length; f++)
                  {
                    row.push(new colObj(false,1,1,cg[key].columnTotal[f]));  // adding column total.
                  }
                 }
              }
              else
              {
                 row.push(new colObj(true,2,1,sc.rows[a].filterList[b]));
                 for(var e = 0; e < sc.columns.length; e++)
                 {
                   if( sc.columns[e].hidden) continue;
                   // creating crGroup name.
                   var key = crGroupKey +":"+(sc.columns[e].table +"."+ sc.columns[e].column).toUpperCase();
                   if(!sc.columns[e].derived)
                    key += "." + sc.columns[e].id;


                   for(var f = 0; f < cg[key].data[b].length; f++)
                   {
                     if(sc.columns[e].dataType == "float")
                        row.push(new colObj(false,1,1,parseFloat(cg[key].data[b][f])));
                     else
                        row.push(new colObj(false,1,1,parseInt(cg[key].data[b][f]))); 
                   }
                 }
              }
           }
           result.push(row);   
         }
       }
       else
       {
         var row = [];
         row.push(new colObj(true,2,1,sc.rows[a].name));  
          
       }
     }
  }
  else if(selectedCRQ.reportType == "date-matrix")
  {
    result = [];
    // filling headers.
    result[0] = [];
    result[1] = [];
    result[2] = [];
    var colspan = (selectedCRQ.rows[0].metadataFlag) ? ((selectedCRQ.rows[0].attributes) ? selectedCRQ.rows[0].attributes.length : 2) : 1;
    result[0].push(new colObj(true,colspan,3,""));
    for(var a = 0; a < sc.columns.length; a++)
    {
      if(sc.columns[a].hidden) continue;
      if(sc.columns[a].metadataFlag)
      {
          result[0].push(new colObj(true,bucketCount*sc.columns[a].filterList.length,1,sc.columns[a].name));  
          for(var b= 0; b < sc.columns[a].filterList.length;b++)
          {
             result[1].push(new colObj(true,bucketCount,1,sc.columns[a].filterList[b]));
             for(var c = 0; c < bucketCount; c++)
             {
               var now = new Date(parseInt(selectedCRQ.queryArg.startTime) + c * selectedCRQ.queryArg.bucketHrs * 3600000);
               result[2].push(new colObj(true,1,1,window.dateFormat(now, dtFormat)));
             }
          }
      }
      else
      {
         result[0].push(new colObj(true,bucketCount,2,sc.columns[a].name));
         for(var b = 0; b < bucketCount; b++)
         {
             var now = new Date(parseInt(selectedCRQ.queryArg.startTime) + b * selectedCRQ.queryArg.bucketHrs * 3600000);
             result[2].push(new colObj(true,1,1,window.dateFormat(now, dtFormat)));
         }
      }     
    }
    // filling later rows.
    //***Fix look and feel issues.
    for(var a = 0; a < sc.rows.length; a++)
    {
          if(sc.rows[a].metadataFlag)
	  {
		for(var b = -1; b < sc.rows[a].filterList.length; b++)
		{
			var row = [];
			if(b == -1)
		        {
			  if(sc.rows[a].attributes && sc.rows[a].attributes.length > 0 && sc.rows[a].column.toUpperCase() == "STOREID")
			  {
				// for attributes.
				for(var f = 0; f < sc.rows[a].attributes.length; f++)
				  row.push(new colObj(true,1,1,sc.rows[a].attributes[f].name));
			  }
			  else
                            row.push(new colObj(true,2,1,sc.rows[a].name));
		        }
			else
			{
		           if(sc.rows[a].attributes && sc.rows[a].attributes.length > 0  && sc.rows[a].column.toUpperCase() == "STOREID")
			   {
			       // for attributes.
                               for(var f = 0; f < sc.rows[a].attributes.length; f++)
			       {
                                  row.push(new colObj(true,1,1,CompleteStoreInfo[sc.rows[a].filterList[b]][sc.rows[a].attributes[f].dbname.toUpperCase()]));
			       }
			   }
			   else
			   {
                              row.push(new colObj(true,1,1,""));
			      row.push(new colObj(true,1,1,sc.rows[a].filterList[b]));
			   }
			   for(c = 0; c < sc.columns.length; c++)
		           {
			      if(sc.columns[c].hidden) continue;
			      // key without bucket count.
	                      var key =  (sc.rows[a].table +"."+ sc.rows[a].column + ":" + sc.columns[c].table + "." + sc.columns[c].column).toUpperCase();
                              if(!sc.columns[c].derived)
                                 key += "." + sc.columns[c].id;
	                      if(sc.columns[c].metadataFlag) 
		              {  
                                 for(var d = 0; d < sc.columns[c].filterList.length; d++)
				 {
			            for(var e = 0; e < bucketCount; e++)
			            {
			               var ckey = e +":"+ key;
                                       if(sc.columns[c].dataType == "float")
                                         row.push(new colObj(false,1,1,parseFloat(cg[ckey].data[b][d])));
                                       else
                                         row.push(new colObj(false,1,1,parseInt(cg[ckey].data[b][d])));
			            }
		                 }
			      }
		              else
	                      {
                                  for(var d = 0; d < bucketCount; d++)
			          {
		                      var ckey = d +":"+ key;
                                      if(sc.columns[c].dataType == "float")
                                        row.push(new colObj(false,1,1,parseFloat(cg[ckey].data[b][0])));
                                      else
                                        row.push(new colObj(false,1,1,parseInt(cg[ckey].data[b][0])));
			          }
			      }
	                   }
	                }
                         result.push(row);
		     }
		  }
		  else
		  {
                          var key =  (sc.rows[a].table +"."+ sc.rows[a].column + ":" + sc.columns[c].table + "." + sc.columns[c].column).toUpperCase();
                          if(!sc.columns[c].derived)
                              key += "." + sc.columns[c].id;
                          var row = [];
			  row.push(new colObj(true,2,1,sc.rows[a].name));   
                          for(var d = 0; d < bucketCount; d++)
                          {
                                 var ckey = d +":"+ key;
                                 if(sc.columns[c].dataType == "float")
                                   row.push(new colObj(false,1,1,parseFloat(cg[ckey].data[0][0])));
                                 else
                                   row.push(new colObj(false,1,1,parseInt(cg[ckey].data[0][0])));
                          }        
                          result.push(row); 
		  }
			  
	  }
  }
  else if(selectedCRQ.reportType == "fixed")
  {
     var rst = [];
     var result = resultObj; 
     for(var z = 0; z < result.length; z++)
     {
        for(var y = 0; y < result[z].length; y++)
        {
           if(result[z][y] == null)
              result[z][y] = 0;
        }
     }
      // filling header rows.
      rst[0] = [];
      for(var a = 0; a < sc.columnDetails.length; a++)
      {
       if(sc.columnDetails[a].name.toUpperCase() != "STORES")
          rst[0].push(new colObj(true,1,1,sc.columnDetails[a].name));
       else  // if the column is stores then showing its attributes also.
       {
        if(sc.columnDetails[a].attributes != undefined && sc.columnDetails[a].attributes.length > 0)
        {
          for(var b = 0; b < sc.columnDetails[a].attributes.length; b++)
             rst[0].push(new colObj(true,1,1,sc.columnDetails[a].attributes[b].name));
        }
        else
             rst[0].push(new colObj(true,1,1,sc.columnDetails[a].name));
       }
      }
      
      
      // filling later rows. 
      for(var a = 0; a < result.length+1; a++)
      {
        var row = [];
        if(a == result.length)
        {
          for(var x = 0; x < sc.columnDetails.length; x++)
          {
            if(x == 0 && sc.columnDetails[x].type == "metadata")
            {
              if(sc.columnDetails[x].attributes)
                  row.push(new colObj(true,sc.columnDetails[x].attributes.length,1,"Column Total"));
              else
                  row.push(new colObj(true,1,1,"Column Total"));

            }
            else if(x != 0 && sc.columnDetails[x].type == "metadata")
              row.push(new colObj(true,1,1,""));
            else
            {
               var total = 0;
               for(var c = 0; c < result.length; c++)
               {
                   if(sc.columnDetails[x].dataType == "int")
                      total += parseInt(result[c][x]);
                   else if(sc.columnDetails[x].dataType == "float")
                      total += parseFloat(result[c][x]);

               }
               if(sc.columnDetails[x].function && sc.columnDetails[x].function.name == "AVG")
                 row.push(new colObj(false,1,1,(total == 0) ? "0.00" :  parseFloat(total/result.length).toFixed(2)));
               else
                 row.push(new colObj(false,1,1,Math.round(total),[["class","tableCell"]]));
               //row.push(new colObj(false,1,1,total));

            }
          }
          rst.push(row);
          continue;
        }
        for(var b = 0; b < result[a].length; b++)
        {
          var header = false;
          if(sc.columnDetails[b].type == "metadata") header = true;
          if(sc.columnDetails[b].attributes != undefined && sc.columnDetails[b].attributes.length > 0)
          {
            for(var c = 0; c < sc.columnDetails[b].attributes.length; c++)
            {
             try { 
               row.push(new colObj(header,1,1,CompleteStoreInfo[result[a][b]][sc.columnDetails[b].attributes[c].dbname.toUpperCase()]));
             }
             catch(e)
             {
               row.push(new colObj(header,1,1,"-"));
             }
            }
          }
          else
          {
            if(sc.columnDetails[b].dataType == "float")
              row.push(new colObj(header,1,1,parseFloat(result[a][b]).toFixed(2)));
            else if(sc.columnDetails[b].dataType == "int")
              row.push(new colObj(header,1,1,parseInt(result[a][b])));
            else
            {
              if(sc.columnDetails[b].key && CRSugD[sc.columnDetails[b].key.toUpperCase()])
              {
                var val = (MDHash[CRSugD[sc.columnDetails[b].key.toUpperCase()]][result[a][b]] == undefined) ? result[a][b] : MDHash[CRSugD[sc.columnDetails[b].key.toUpperCase()]][result[a][b]];
                row.push(new colObj(header,1,1,val));
              }
              else
                row.push(new colObj(header,1,1,result[a][b]));
            }
          }
             //row.push(new colObj(header,1,1,result[a][b]));
        } 
        rst.push(row);
      } 
      return rst;
  }
  
  return result;
}


/*Array.prototype.fill = function(num) {
  for(var a = 0; a < this.length; a++)
      this[a] = num;
}*/


function sortRowSeqNew()
{
  var crGroups = [];

  var rowFilterObjHash;
  rowFilterObjHash = getRowFilterObj();
  var rfo;
  var ColCRgroup = null; //CRGroup having sorting column.
  var tmpArray;
  var crGroups = [];
  for(var z = 0; z < selectedCRQ.rows.length; z++)
  {
    //TODO: autoSequence flag should be enabled then only sort them.
    if(selectedCRQ.rows[z].filterList.length == 0)
      continue;

    if(selectedCRQ.rows[z].autoSequence == false)
      continue;

    ColCRgroup = null;
    crGroups = [];
    //create a temporary coltotal. 
    //Note: we should do it before autosequencing columns.

    //get the crGroup having 

   rfo = rowFilterObjHash[z];
    for(var h in resultObj.CRGroupHash)
    {
      if(z == resultObj.CRGroupHash[h].rowid)
      {
        crGroups.push(resultObj.CRGroupHash[h]);
        if(rfo.column == resultObj.CRGroupHash[h].columnid)
        {
          ColCRGroup = resultObj.CRGroupHash[h];
        }
      }
    }


    //FIXME: check if ColCRGroup set or not.
    if(ColCRGroup == null || crGroups.length == 0)
      return;

    //now sort ColCRGroup on rowTotal.
    //FIXME: handle it for other cases.
    var rowTotal = new Array(ColCRGroup.rowTotal.length);

    for(var y = 0; y < rowTotal.length; y++)
      rowTotal[y] = ColCRGroup.rowTotal[y];

     var tmpArray = new Array(rowTotal.length);
    for(var y = 0; y < rowTotal.length; y++)
      tmpArray[y] = {'count': rowTotal[y], "prevId": y};

    //sort this array on count.  
    //FIXME: handle for Aggregate Function Min.
    if(rfo.type == "top")
      tmpArray.sort(function(A, B){if(isNaN(B.count) || B.count <= 0) return -1; else if(isNaN(A.count) || A.count <= 0) return 1; return (B.count - A.count);});
    else
      tmpArray.sort(function(A, B){if(isNaN(B.count) || B.count <= 0) return -1; else if(isNaN(A.count) || A.count <= 0) return 1; return (A.count - B.count);});

    //now it's time to sort all other ****. 
    for(var y = 0; y < crGroups.length; y++)
    {
      //change filterlist seq.
      if(y == 0)
      {
        selectedCRQ.rows[z].dupFilterList = new Array(selectedCRQ.rows[z].filterList.length);
        for(var t = 0; t < selectedCRQ.rows[z].filterList.length; t++)
        {
          selectedCRQ.rows[z].dupFilterList[t] = selectedCRQ.rows[z].filterList[tmpArray[t].prevId];
        }
  selectedCRQ.rows[z].filterList = selectedCRQ.rows[z].dupFilterList;
        selectedCRQ.rows[z].dupFilterList = undefined;
        if(!isNaN(rfo.count) && rfo.count != -1)
          selectedCRQ.rows[z].filterList.splice(rfo.count);
      }
      //now alter data. 
      crGroups[y].dupData = new Array(crGroups[y].numRow);
      for(var t = 0; t < crGroups[y].numRow; t++)
      {
        crGroups[y].dupData[t] = crGroups[y].data[tmpArray[t].prevId];
      }
      crGroups[y].data = crGroups[y].dupData;
      crGroups[y].dupData = undefined;

      //check if count is given then take only that much of counts. 
      if(!isNaN(rfo.count) && rfo.count != -1)
      {
        rfo.count = parseInt(rfo.count);
        //splice rest of the data.
        if(rfo.count < crGroups[y].data.length)
        {
          crGroups[y].data.splice(rfo.count);
          //update row Total.
          crGroups[y].numRow = parseInt(rfo.count);
          var aggFunc = "COUNT";
if(selectedCRQ.columns[crGroups[y].columnid].function && selectedCRQ.columns[crGroups[y].columnid].function.name)
            aggFunc = selectedCRQ.columns[crGroups[y].columnid].function.name;

          //update count total.
          //reset all column total.
          crGroups[y].columnTotal = new Array(crGroups[y].numCol);
          crGroups[y].columnTotal.fill(NaN);
          for(var x = 0; x < crGroups[y].data.length; x++)
          {
            for(var l = 0; l < crGroups[y].data[x].length; l++)
            {
              //update column total.
              switch(aggFunc)
              {
                case "MIN":
                  crGroups[y].columnTotal[l] = MIN(crGroups[y].columnTotal[l], crGroups[y].data[x][l]);
                  break;
                case "MAX":
                  crGroups[y].columnTotal[l] = MAX(crGroups[y].columnTotal[l], crGroups[y].data[x][l]);
                  break;
                case "AVG":
                case "SUM":
                case "COUNT":
                default:
                  crGroups[y].columnTotal[l] = SUM(crGroups[y].columnTotal[l], crGroups[y].data[x][l]);
              }
            }
          }
 //If this was case of AVG then compute do the average at this point.
          if(aggFunc == "AVG")
          {
          for(var x = 0; x < crGroups[y].numCol; x++)
          {
            crGroups[y].columnTotal[x] = parseFloat(crGroups[y].columnTotal[x]/crGroups[y].numRow).toFixed(2);
          }
          }
        }
      }
    }
  }
}

function uniqueArray(A)
{       
  var u = {}, a = [];
  for(var i = 0, l = A.length; i < l; ++i)
  {
    if(u.hasOwnProperty(A[i]))
    {
      continue;
    }
    a.push(A[i]); 
    u[A[i]] = 1
  }
  return a;
}

//function to process template report.
// In case of template report we will have multiple results.
// So need to process all the results for filling xls templates.
var processTemplateResult = function processTemplateResult(results, mode)
{
  var res = [];
  results = eval(results);
  if(results == null || results == undefined) return [];
  for(var a = 0; a < results.length; a++) 
  {
    var indRes = [];
    results[a] = eval(results[a]);
    if(results[a].errorString != null)
    {
        res.push([]);
        continue;
    }
    // in  case of fixed report. 
    if(results[a].reportType == "fixed")
    {
      var indRes = [];
      for(var b = 0; b < results[a].result.length; b++)
      {
         var resRows = {};
         for(var c = 0; c < results[a].columnDetails.length; c++)
         {
          if(!results[a].columnDetails[c].attributes)
            resRows[results[a].columnDetails[c].name] = results[a].result[b][c];
          else
          {
             // if column attributes are present then setting the attributes as properties of each cell object.
             // also assumption is attributes will be present on in case of store id so handling acc to that only.

             // picking attributes and its values acc to the id from store metadata list CompleteStoreInfo.
             for(var x = 0; x < results[a].columnDetails[c].attributes.length; x++)
             {
                // in case of store id info not available putting "-" on other attributes except store id.
                if(CompleteStoreInfo[results[a].result[b][c]] == undefined)
                {
                   if(results[a].columnDetails[c].attributes[x].dbname == "STR_ID")
                     resRows[results[a].columnDetails[c].attributes[x].name] = results[a].result[b][c];
                   else
                     resRows[results[a].columnDetails[c].attributes[x].name] = "-";
                }
                else
                   resRows[results[a].columnDetails[c].attributes[x].name] = CompleteStoreInfo[results[a].result[b][c]][results[a].columnDetails[c].attributes[x].dbname.toUpperCase()];
                      
             }
          }

         }
         indRes.push(resRows);
      }
      //for sorting
      if(results[a].topBottomFilter != null)
      {
        var colName = results[a].topBottomFilter.name;
         // get column name from column id.
          /**
         for(var q = 0; q < results[a].columns.length; q++)
         {
            if(parseInt(results[a].topBottomFilter.columnid) == results[a].columns[q].id )
              colName = results[a].columns[q].name;
         }**/
         var top = (results[a].topBottomFilter.top == true) ? true : false;
         var count = parseInt(results[a].topBottomFilter.count);

         // applying top/bottom filter and sorting result acc to that.
         if(top) // in case of top n cols.
           indRes = indRes.sort(
             function(A,B){
                if(isNaN(A[colName]) || B[colName] <= 0) return -1;
                else if(isNaN(A[colName]) || A[colName] <= 0) return 1;
                return (B[colName] - A[colName]);
             }
           );
		   else // in case of bottom n cols.
           indRes = indRes.sort(
             function(A,B){
                if(isNaN(A[colName]) || B[colName] <= 0) return -1;
                else if(isNaN(A[colName]) || A[colName] <= 0) return 1;
                return (A[colName] - B[colName]);
             }
           );
        // fetching the required num of rows from the result.
        indRes.splice(count);
      }
      res.push(indRes); 
    } 
    else
    {
      
      var bucketCount = Math.ceil(parseFloat(((results[a].queryArg.endTime/1000) - (results[a].queryArg.startTime/1000)) / parseInt(results[a].queryArg.bucketHrs * 3600)));
      var dtFormat = "d mmm";
      if(results[a].queryArg.bucketHrs == 1)
       dtFormat = "dd/mm/yy, HH:00"; 
    
      // transforming each result.
      var result = transformResult2(results[a],results[a],mode);
      if(result.length == 0) continue;
      // parsing crqObj columns
      //var rowCount = (results[a].reportType.indexOf("matrix") > -1) ? results[a].rows[0].filterList.length : results[a].result.length;
      var rowCount = (results[a].reportType.indexOf("matrix") > -1) ? results[a].rows[0].filterList.length : bucketCount;
      for(var c =0; c < rowCount; c++)
      {
        var resRow = {};
        // if date type report then first col of every row will have date and time.
        if(results[a].reportType == "date")
        {
          var now = new Date(parseInt(results[a].queryArg.startTime) * 1000 + 1388534400000  + c * results[a].queryArg.bucketHrs * 3600000);
          resRow["Date/Time"] = window.dateFormat(now, dtFormat);  // adding date time as first col.
        }
      
        // if matrix type report then we are assuming there will be one row.
        // TODO : handling for date-matrix report.
        if(results[a].reportType == "matrix")
        {
          if(results[a].rows[0].metadataFlag)
          {
            // checking for row attributes in case of stores.
            if(results[a].rows[0].attributes)
            {
               for(var n = 0;n < results[a].rows[0].attributes.length; n++)
               {
                  // in case of store id info not available putting "-" on other attributes except store id.
                 if(CompleteStoreInfo[results[a].rows[0].filterList[c]] == undefined)
                 {
                   if(results[a].rows[0].attributes[n].dbname == "STR_ID")
                     resRow[results[a].rows[0].attributes[n].name] = results[a].rows[0].filterList[c];
                   else
                     resRow[results[a].rows[0].attributes[n].name] = "-";
                 }
                 else
                   resRow[results[a].rows[0].attributes[n].name] = CompleteStoreInfo[results[a].rows[0].filterList[c]][results[a].rows[0].attributes[n].dbname.toUpperCase()];
               }
            }
            else
               resRow[results[a].rows[0].name] = results[a].rows[0].filterList[c];
          }
          else
          {
            resRow[results[a].rows[0].name] = results[a].rows[0].name;
          }
        }
        for(var b =0; b < results[a].columns.length; b++)
        { 
          if(results[a].columns[b].hidden) continue;
          // creating key for CRGroupHash.
          var key  =  results[a].columns[b].table + "." + results[a].columns[b].column;
          if(results[a].columns[b].table != "derived")
            key += "." + results[a].columns[b].id;
          if(results[a].reportType == "matrix")
              key = results[a].rows[0].table + "." + results[a].rows[0].column + ":" + key;
          //TODO : handle filterlist of columns.
          // checking for filterlist in columns.
          if(results[a].columns[b].filterList.length > 0)
          {
           for(var p = 0; p < results[a].columns[b].filterList.length; p++)
             resRow[results[a].columns[b].name + "_" +results[a].columns[b].filterList[p]] = results[a].CRGroupHash[key.toUpperCase()].data[c][p];
          }
          else
           resRow[results[a].columns[b].name] = results[a].CRGroupHash[key.toUpperCase()].data[c][0];
        }
        indRes.push(resRow);     
      }
      // check if matrix type report and any top bottom filter applied.
      // assumption : only row is used for matrix type reports.
      if(results[a].reportType == "matrix" && results[a].rows[0].topBottomFilter != null)
      {
         var colName = "";
         // using columnBy flag to decide whether to use index or id to pick column for sorting.
         if(results[a].rows[0].topBottomFilter.columnBy != undefined || results[a].rows[0].topBottomFilter.columnBy == "index")
         {  
           colName = results[a].columns[parseInt(results[a].rows[0].topBottomFilter.columnid)].name;
           if(results[a].columns[parseInt(results[a].rows[0].topBottomFilter.columnid)].filterList.length > 0)
             colName += "_" + results[a].columns[parseInt(results[a].rows[0].topBottomFilter.columnid)].filterList[0];
         }
         // get column name from column id.
         else
         {
           for(var q = 0; q < results[a].columns.length; q++)
           {
            if(parseInt(results[a].rows[0].topBottomFilter.columnid) == results[a].columns[q].id ) 
            {
              colName = results[a].columns[q].name;
              // sorting using first element of filterlist.
              if(results[a].columns[q].filterList.length > 0)
                colName += "_" + results[a].columns[q].filterList[0];
            }
           }
         }
         var top = (results[a].rows[0].topBottomFilter.topBottom == "top") ? true : false;
         var count = parseInt(results[a].rows[0].topBottomFilter.count);
         // applying top/bottom filter and sorting result acc to that.
         if(top) // in case of top n cols.
           indRes = indRes.sort(
             function(A,B){
                if(isNaN(A[colName]) || B[colName] <= 0) return -1;
                else if(isNaN(A[colName]) || A[colName] <= 0) return 1;
                return (B[colName] - A[colName]);
             }
           );
         else // in case of bottom n cols.
           indRes = indRes.sort(
             function(A,B){
                if(isNaN(A[colName]) || B[colName] <= 0) return -1;
                else if(isNaN(A[colName]) || A[colName] <= 0) return 1;
                return (A[colName] - B[colName]);
             }
           );
        // fetching the required num of rows from the result.
        indRes.splice(count); 
        // tmpArray.sort(function(A, B){if(isNaN(B.count) || B.count <= 0) return -1; else if(isNaN(A.count) || A.count <= 0) return 1; return (B.count - A.count);}); 

      }     
      res.push(indRes);
    }
  }
  return res; 
 }


//export transformResult2 method.
if(typeof exports != 'undefined')
{
  if( typeof module !== 'undefined' && module.exports ) {
      exports = module.exports = { "transformResult2" : transformResult2, "processTemplateResult":processTemplateResult};
    }
   exports = { "transformResult2" : transformResult2, "processTemplateResult":processTemplateResult};
}
else
{
  window = { "transformResult2" : transformResult2, "processTemplateResult":processTemplateResult};
}

}).call(typeof global != "undefined" ? global : window);





